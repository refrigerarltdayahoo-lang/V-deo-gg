# Roteiro do exemplo 1: A Portaria

Você é o porteiro no turno da noite. O morador do 804 interfona e proíbe qualquer subida, "nem se for eu". Minutos depois, ele mesmo aparece na porta de vidro pedindo para entrar.

- Composição no Remotion: `Ep01` (arquivo `src/Ep01.tsx`, cenário `src/Portaria.tsx`).
- Configuração de áudio: `episodios/portaria01.json`.
- Vozes: 23 arquivos, `L01.mp3` a `L23.mp3`, na pasta `vozes/portaria01/`, na ordem da tabela abaixo.
- Duração com as nossas vozes: cerca de 117 segundos. Com as suas vozes a duração muda, porque o tempo de cada fala é medido pelo comando `prep`.

## Elenco

| Personagem | Cor da legenda | Voz que usamos (exemplo) |
|---|---|---|
| Você (o porteiro) | branco | Leo |
| Seu Álvaro no interfone | azul claro | Andre |
| O homem da porta | laranja | Andre (a mesma voz do interfone, de propósito) |
| Entregador | lilás | Kevin |

Os nomes de voz são predefinições do serviço que usamos. Qualquer voz masculina brasileira serve. O importante é manter a mesma voz para o interfone e para o homem da porta: a dúvida do episódio depende disso.

## Falas para gerar

A coluna "Texto para a voz" é o que você envia ao gerador de voz. Ela pode ser diferente da legenda: número vai sempre por extenso. A direção entre colchetes é uma sugestão nossa, em inglês, e vai só no começo da fala. Ajuste ao seu gosto.

O efeito de interfone e o de voz atrás do vidro são aplicados pelo comando `prep`. Gere todas as vozes limpas, sem efeito.

| Arquivo | Quem | Texto para a voz | Direção sugerida | Efeito aplicado no prep |
|---|---|---|---|---|
| L01 | Você | Portaria, boa noite. | [calm, tired] | |
| L02 | Interfone | Hoje não deixa ninguém subir pro meu apartamento. | [low, tense] | interfone |
| L03 | Você | Tudo bem, seu Álvaro. Ninguém sobe. | [calm] | |
| L04 | Interfone | Ninguém. Nem se for eu. | [cold, slow] | interfone |
| L05 | Você | ...Nem se for ele? | [confused, quiet] | |
| L06 | Você | A luz do oitavo tá piscando. | [uneasy] | |
| L07 | Entregador | Entrega pro quinhentos e dois! Deixo aqui? | [cheerful, loud] | vidro |
| L08 | Você | Pode deixar. | [calm] | |
| L09 | Homem da porta | Boa noite! Esqueci a chave. Abre pra mim? | [friendly, smiling] | vidro |
| L10 | Você | Seu Álvaro...? O senhor acabou de me ligar lá de cima. | [confused] | |
| L11 | Homem da porta | Eu? Tô chegando do trabalho agora, rapaz. | [friendly, surprised] | vidro |
| L12 | Interfone | Ele chegou, né? Não olha muito pra ele. Não abre. | [whispering, urgent] | interfone |
| L13 | Homem da porta | Com quem você tá falando? | [curious, calm] | vidro |
| L14 | Você | A câmera... não tem ninguém na câmera. | [scared, quiet] | |
| L15 | Interfone | Ele vai dizer que tá chovendo. Olha pro chão. | [whispering, tense] | interfone |
| L16 | Homem da porta | Abre. Tá chovendo. | [calm, insistent] | vidro |
| L17 | Você | Não tá chovendo... | [scared, whispering] | |
| L18 | Você | Ele não tá em casa...? Então quem tá no oitocentos e quatro? | [scared] | |
| L19 | Interfone | Não lê o grupo. Escuta só a mim. | [cold, firm] | interfone |
| L20 | Homem da porta | Rapaz. Quem tá na minha casa? | [serious, low] | vidro |
| L21 | Você | ...Eu já atendi. | [scared, quiet] | |
| L22 | Interfone | Tô descendo. Não abre pra ele. | [cold, calm] | interfone |
| L23 | Homem da porta | Abre! Ele tá descendo! Abre essa porta! | [desperate, shouting] | vidro |

Na legenda, as falas L07 e L18 aparecem com o número em algarismos ("502" e "804"). Só o texto enviado à voz vai por extenso.

## Textos que aparecem na tela (sem voz)

Grupo do condomínio, "Cond. Jardim das Acácias":

1. Dona Neide 302: quem tá arrastando móvel uma hora dessas???
2. Síndico: Pessoal, respeitem o horário de silêncio.
3. Dona Neide 302: tem alguém andando no teto do meu apto
4. Síndico: É o vento, Dona Neide.
5. Dona Neide 302: o seu Álvaro do 804 não tinha viajado?
6. Síndico: Viajou. Volta dia 20.

Conversa com a mãe:

1. Mãe: Filho, já jantou? Teu tio disse que aí de noite é tranquilo 🙏
2. Você: Tranquilo, mãe 😴
3. Mãe: Filho, teu tio mandou avisar: se o 804 interfonar de noite, NÃO ATENDE.

## Tela de voto

- Opção A: ABRIR (pro homem da porta)
- Opção B: ESPERAR (o elevador chegar)
- Rodapé: A mais votada decide a PARTE 2

## Por que o voto divide

Há prova contra os dois lados. Contra o homem da porta: ele não aparece na câmera da entrada e está molhado sem chuva. Contra a voz do interfone: o grupo diz que o morador viajou e a mãe manda não atender o 804.
