# Roteiro do exemplo 2: Jonas, parte 1 (A Tempestade)

Você é um marinheiro no barco que saiu de Jope. A tempestade chega de repente e o passageiro que dormia no porão diz que a culpa é dele. Baseado em Jonas 1:4-13.

- Composição no Remotion: `Jonas01` (arquivo `src/Jonas01.tsx`, cenário `src/Navio.tsx`).
- Configuração de áudio: `episodios/jonas01.json`.
- Vozes: 19 arquivos, `J01.mp3` a `J19.mp3`, na pasta `vozes/jonas01/`, na ordem da tabela abaixo.
- Duração com as nossas vozes: cerca de 72 segundos. Com as suas vozes a duração muda, porque o tempo de cada fala é medido pelo comando `prep`.

## Como o episódio trata o texto bíblico

O espectador é uma testemunha anônima, não o personagem bíblico. A história acontece como está no texto. As falas dos personagens bíblicos são paráfrases, com o versículo anotado; as reações da testemunha são dramatização. As duas opções do voto são coisas que os marinheiros de fato cogitaram no texto.

## Elenco

| Personagem | Cor da legenda | Voz que usamos (exemplo) |
|---|---|---|
| Você (marinheiro jovem) | branco | Leo |
| Capitão | amarelo | Marcus |
| Outro marinheiro | verde | Kevin |
| Jonas | azul claro | Julian |

Os nomes de voz são predefinições do serviço que usamos. Qualquer conjunto de vozes brasileiras bem diferentes entre si serve.

## Falas para gerar

A direção entre colchetes é uma sugestão nossa, em inglês, e vai só no começo da fala. O efeito de porão é aplicado pelo comando `prep`. Gere todas as vozes limpas, sem efeito.

| Arquivo | Quem | Texto para a voz | Direção sugerida | Fonte | Efeito aplicado no prep |
|---|---|---|---|---|---|
| J01 | Capitão | Segura a vela! O vento virou! | [shouting over a storm] | dramatização (1:4) | |
| J02 | Você | De onde veio isso? O céu tava limpo! | [scared, shouting] | dramatização | |
| J03 | Marinheiro | O barco vai partir no meio! | [panicked, shouting] | 1:4 | |
| J04 | Capitão | Joga a carga no mar! Tudo! | [commanding, shouting] | 1:5 | |
| J05 | Marinheiro | Cada um clama pro seu deus! Agora! | [desperate, shouting] | 1:5 | |
| J06 | Você | Cadê o passageiro? O que subiu em Jope? | [urgent] | dramatização (1:3 e 1:5) | |
| J07 | Marinheiro | Desceu pro porão! | [shouting] | 1:5 | |
| J08 | Você | ...Ele tá dormindo? | [astonished, quiet] | 1:5 | porão |
| J09 | Capitão | Como você consegue dormir? Levanta e clama ao teu Deus! | [angry, urgent] | 1:6 | porão |
| J10 | Marinheiro | Vamos tirar a sorte. Alguém aqui trouxe essa desgraça. | [tense, firm] | 1:7 | |
| J11 | Capitão | Quem é você? De onde você vem? | [stern] | 1:8 | |
| J12 | Jonas | Sou hebreu. Eu adoro o Senhor, o Deus do céu, que fez o mar e a terra. | [calm, heavy] | 1:9 | |
| J13 | Jonas | E eu tô fugindo dele. | [ashamed, quiet] | 1:10 | |
| J14 | Marinheiro | O que foi que você fez?! | [horrified] | 1:10 | |
| J15 | Capitão | O que a gente faz com você pro mar acalmar? | [tense, urgent] | 1:11 | |
| J16 | Jonas | Me joguem no mar. Aí ele acalma. Eu sei que a culpa é minha. | [resigned, calm] | 1:12 | |
| J17 | Você | Jogar um homem no mar...? | [shocked, quiet] | dramatização | |
| J18 | Marinheiro | Vamos remar! Ainda dá pra voltar pra terra! | [determined, shouting] | 1:13 | |
| J19 | Capitão | Decidam logo! O barco não aguenta mais! | [desperate, shouting] | dramatização | |

## Textos que aparecem na tela (sem voz)

- Depois do sorteio: A SORTE CAIU EM JONAS. (1:7)
- Etiqueta fixa no alto à direita: 📖 JONAS 1

## Tela de voto

- Opção A: JOGAR (Jonas no mar, como ele pediu)
- Opção B: REMAR (tentar voltar pra terra)
- Rodapé: Na PARTE 2: o que a Bíblia conta

## Abertura sugerida para a parte 2

"NA BÍBLIA: eles remaram com toda a força e não conseguiram (Jonas 1:13). Então oraram e lançaram Jonas ao mar. E o mar parou (1:14 e 1:15)."
