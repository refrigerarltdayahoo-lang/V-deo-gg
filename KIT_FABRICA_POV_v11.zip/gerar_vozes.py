# Vozes automaticas da Fabrica POV pelo ElevenLabs. So usa a biblioteca padrao do Python 3 (nada de pip).
#
# No Windows o comando e "py" (ou "python"); no Mac, "python3". Todos rodam a partir da pasta do kit.
#
#   PY gerar_vozes.py chave                     confere a chave e mostra os creditos da conta (nao gasta credito)
#   PY gerar_vozes.py receitas                  lista as vozes prontas do kit (vozes/receitas.json)
#   PY gerar_vozes.py elenco                    mostra as vozes ja salvas para usar nos episodios (vozes/elenco.json)
#   PY gerar_vozes.py minhas-vozes              lista as vozes da sua conta no ElevenLabs
#   PY gerar_vozes.py amostras NOME [RECEITA ou "descricao em ingles"]
#                                               cria 3 amostras de uma voz nova em vozes/amostras/ (gasta um pouco de credito)
#   PY gerar_vozes.py salvar NOME N             guarda a amostra N como voz da sua conta (ocupa 1 vaga) e poe no elenco
#   PY gerar_vozes.py usar NOME VOICE_ID        poe no elenco uma voz que ja existe na sua conta
#   PY gerar_vozes.py falas episodios/EP.json   confere a lista de falas e mostra quanto vai gastar (nao gasta nada)
#   PY gerar_vozes.py falas episodios/EP.json --sim [--refazer L03,L07] [--todas]
#                                               gera as falas que faltam e salva os MP3 com os nomes que o ep_audio.py espera
#
# A chave fica no arquivo .env da pasta do kit, numa linha assim:  ELEVENLABS_API_KEY=sua_chave
# A lista de falas de um episodio fica em episodios/EP_falas.json (mesmo nome do arquivo do episodio, com _falas).
# API usada (documentacao oficial do ElevenLabs): POST /v1/text-to-speech/{voice_id} com o cabecalho xi-api-key,
# POST /v1/text-to-voice/design e POST /v1/text-to-voice (Voice Design), GET /v1/user/subscription e GET /v2/voices.
import base64, datetime, json, os, re, shutil, socket, ssl, sys, time, urllib.error, urllib.parse, urllib.request

for _fluxo in (sys.stdout, sys.stderr):
    try:
        _fluxo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

NO_WINDOWS = os.name == "nt"
PY = ("py" if shutil.which("py") else "python") if NO_WINDOWS else "python3"
FAB = os.path.dirname(os.path.abspath(__file__))
# A variavel ELEVENLABS_API_BASE so serve para teste (um servidor falso no proprio computador). Sem ela, usa o oficial.
BASE = os.environ.get("ELEVENLABS_API_BASE", "https://api.elevenlabs.io").rstrip("/")
MODELO_PADRAO = "eleven_v4"
# Se a conta nao aceitar um modelo, tenta o proximo. Os dois primeiros entendem a direcao entre colchetes no comeco
# da fala ([whispering], [calm]); o eleven_multilingual_v2 nao entende, entao a direcao e tirada do texto.
MODELOS_RESERVA = ["eleven_v4", "eleven_v3", "eleven_multilingual_v2"]
MODELOS_COM_DIRECAO = ("eleven_v4", "eleven_v3")
MODELO_DESIGN = "eleven_ttv_v3"
MODELOS_DESIGN_RESERVA = ["eleven_ttv_v3", "eleven_multilingual_ttv_v2"]
FORMATO = "mp3_44100_128"  # o padrao da API, liberado no plano gratis
USO = (f"Uso: {PY} gerar_vozes.py chave | receitas | elenco | minhas-vozes | amostras NOME [RECEITA] | "
       f"salvar NOME N | usar NOME VOICE_ID | falas episodios/EP.json [--sim] [--refazer L03,L07] [--todas]")


def para(msg):
    print("\nNÃO FOI POSSÍVEL CONTINUAR\n" + msg + "\n")
    sys.exit(1)


def aspas(arg):
    arg = str(arg)
    return f'"{arg}"' if (" " in arg or not arg) else arg


def kit(*partes):
    return os.path.normpath(os.path.join(FAB, *partes))


def le_json(caminho, padrao=None):
    if not os.path.isfile(caminho):
        if padrao is not None:
            return padrao
        para(f"Arquivo não encontrado: {caminho}")
    try:
        with open(caminho, encoding="utf-8-sig") as f:
            return json.load(f)
    except UnicodeDecodeError:
        para(f"O arquivo {caminho} não está em UTF-8. Abra no editor, salve como UTF-8 e rode de novo.")
    except json.JSONDecodeError as e:
        para(f"O arquivo {caminho} tem um erro de formato na linha {e.lineno}, coluna {e.colno}: {e.msg}.\n"
             "Confira vírgulas, aspas e colchetes perto desse ponto.")


def grava_json(caminho, dados):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, caminho)


# ---------------------------------------------------------------- chave

def le_chave(obrigatoria=True):
    chave = os.environ.get("ELEVENLABS_API_KEY", "").strip()
    env = kit(".env")
    if not chave and os.path.isfile(env):
        with open(env, encoding="utf-8-sig", errors="replace") as f:
            for linha in f:
                linha = linha.strip()
                if linha.startswith("export "):
                    linha = linha[7:].strip()
                if linha.startswith("ELEVENLABS_API_KEY") and "=" in linha:
                    chave = linha.split("=", 1)[1].strip().strip('"').strip("'").strip()
                    break
    if not chave:
        if not obrigatoria:
            return ""
        para("Falta a chave do ElevenLabs.\n"
             f"Crie o arquivo .env na pasta do kit ({kit('.env')}) com uma linha assim:\n"
             "  ELEVENLABS_API_KEY=cole_a_sua_chave_aqui\n"
             "A chave fica no site do ElevenLabs: menu Developers, aba API Keys, botão Create API Key.")
    if " " in chave or len(chave) < 20:
        para("A chave do arquivo .env parece incompleta (curta demais ou com espaço no meio).\n"
             "Copie de novo no site do ElevenLabs, inteira, e troque a linha ELEVENLABS_API_KEY= do arquivo .env.")
    return chave


def mascara(chave):
    return chave[:4] + "..." + chave[-2:] if len(chave) > 8 else "..."


# ---------------------------------------------------------------- HTTP

class ErroAPI(Exception):
    def __init__(self, http, corpo):
        self.http = http
        self.code = self.tipo = self.msg = self.param = self.pedido = self.status = ""
        texto = corpo.decode("utf-8", errors="replace") if isinstance(corpo, bytes) else str(corpo or "")
        try:
            d = json.loads(texto).get("detail", texto)
        except (ValueError, AttributeError):
            d = texto
        if isinstance(d, dict):
            self.code = str(d.get("code") or d.get("status") or "")
            self.status = str(d.get("status") or "")  # campo antigo, mas ainda traz invalid_api_key, quota_exceeded etc.
            self.tipo = str(d.get("type") or "")
            self.msg = str(d.get("message") or "")
            self.param = str(d.get("param") or "")
            self.pedido = str(d.get("request_id") or "")
        elif isinstance(d, list):  # erro de validacao (422): lista de problemas
            partes = []
            for item in d:
                if isinstance(item, dict):
                    onde = ".".join(str(x) for x in item.get("loc", []) if x != "body")
                    partes.append(f"{onde}: {item.get('msg', '')}".strip(": "))
                    self.param = self.param or onde
            self.code, self.msg = "validation_error", "; ".join(partes)
        else:
            self.msg = texto[:300]
        super().__init__(f"HTTP {http} {self.code} {self.msg}")

    def fala_de(self, *palavras):
        alvo = f"{self.code} {self.status} {self.tipo} {self.msg} {self.param}".lower()
        return any(p in alvo for p in palavras)


def contexto_ssl():
    ctx = ssl.create_default_context()
    try:  # se o certifi estiver instalado (alguns Pythons do Mac precisam), usa os certificados dele
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass
    return ctx


CTX = contexto_ssl()


def pede(chave, metodo, caminho, corpo=None, consulta=None, audio=False, tempo=120):
    url = BASE + caminho + ("?" + urllib.parse.urlencode(consulta) if consulta else "")
    dados = json.dumps(corpo).encode("utf-8") if corpo is not None else None
    espera = 3
    for tentativa in range(5):
        req = urllib.request.Request(url, data=dados, method=metodo)
        req.add_header("xi-api-key", chave)
        req.add_header("Accept", "audio/mpeg" if audio else "application/json")
        req.add_header("User-Agent", "fabrica-pov-kit/1.0")
        if dados is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=tempo, context=CTX if url.startswith("https") else None) as r:
                return r.read(), r.headers.get("Content-Type", "")
        except urllib.error.HTTPError as e:
            erro = ErroAPI(e.code, e.read())
            ocupado = e.code in (429, 500, 502, 503, 504) and not erro.fala_de("quota", "credit")
            if ocupado and tentativa < 4:
                print(f"  (o ElevenLabs pediu para esperar; tento de novo em {espera} s)")
                time.sleep(espera)
                espera *= 2
                continue
            raise erro
        except urllib.error.URLError as e:
            motivo = str(getattr(e, "reason", e))
            if "CERTIFICATE_VERIFY_FAILED" in motivo:
                para("O Python não conseguiu conferir o certificado de segurança do site do ElevenLabs.\n"
                     "No Mac com Python baixado do python.org, abra a pasta Aplicativos > Python 3.x e dê dois cliques em\n"
                     "\"Install Certificates.command\". Com o Python do Homebrew isso não acontece.")
            if tentativa < 2:
                time.sleep(espera)
                continue
            para(f"Sem conexão com o ElevenLabs ({motivo}).\nConfira a internet e rode de novo.")
        except (socket.timeout, TimeoutError):
            if tentativa < 1:
                continue
            para("O ElevenLabs demorou demais para responder. Espere um minuto e rode de novo.\n"
                 "As falas que já foram salvas não são geradas outra vez.")
    para("O ElevenLabs continua ocupado. Espere alguns minutos e rode de novo.")


def explica(erro, fazendo):
    # Mensagem em portugues simples para cada erro conhecido da API (codigos da pagina de erros do ElevenLabs).
    http = erro.http
    if erro.fala_de("unusual"):
        txt = ("O ElevenLabs bloqueou o uso grátis desta conta por \"atividade incomum\".\n"
               "Isso acontece com VPN, proxy ou várias contas grátis no mesmo computador. Desligue a VPN e tente de novo;\n"
               "se continuar, só um plano pago do ElevenLabs libera.")
    elif erro.fala_de("quota_exceeded") or (http == 401 and erro.fala_de("quota")):
        txt = "Acabaram os créditos do mês na sua conta do ElevenLabs. Espere a renovação do mês ou mude de plano no site."
    elif erro.fala_de("insufficient_permissions", "missing_permissions"):
        txt = ("A chave não tem permissão para " + fazendo + ".\n"
               "No site do ElevenLabs, crie uma chave nova (menu Developers, aba API Keys) com a opção Restrict Key desligada,\n"
               "ou com acesso a Text to Speech, Voices e User, e troque a linha do arquivo .env.")
    elif http == 401 or erro.fala_de("invalid_api_key", "missing_api_key"):
        txt = ("A chave do ElevenLabs não foi aceita.\n"
               "Copie a chave de novo no site (menu Developers, aba API Keys), inteira, e troque a linha\n"
               "ELEVENLABS_API_KEY= do arquivo .env. Se você apagou a chave no site, crie outra.")
    elif http == 402 or erro.fala_de("insufficient_credits"):
        txt = "Não há créditos suficientes na sua conta do ElevenLabs para isso. Espere a renovação do mês ou mude de plano no site."
    elif http == 429:
        txt = "O ElevenLabs está ocupado ou o limite de pedidos foi atingido. Espere um minuto e rode de novo."
    elif http >= 500:
        txt = "O ElevenLabs está com instabilidade. Espere alguns minutos e rode de novo."
    elif erro.fala_de("voice_access_denied", "library", "free_users", "subscription_required", "paid_plan", "feature_not_available"):
        txt = ("A sua conta não pode usar essa voz pela API.\n"
               "No plano grátis, as vozes da biblioteca do ElevenLabs (Voice Library) não funcionam pela API.\n"
               "Use uma voz criada pelo kit (comandos amostras e salvar) ou assine um plano pago do ElevenLabs.")
    elif http == 404 or erro.fala_de("voice_not_found"):
        txt = "Essa voz não existe na sua conta (pode ter sido apagada). Crie de novo com os comandos amostras e salvar."
    elif erro.fala_de("voice") and erro.fala_de("limit", "slots", "maximum"):
        txt = ("Sua conta já usa todas as vagas de voz (no plano grátis são 3).\n"
               "Reaproveite uma voz do elenco, ou apague no site uma voz que não usa (menu Voices, My Voices) e tente de novo.")
    elif erro.fala_de("text_too_long"):
        txt = "A fala é longa demais para um pedido só. Divida em duas falas."
    else:
        txt = f"O ElevenLabs recusou o pedido ao {fazendo} (erro {http}): {erro.code} {erro.msg}".strip()
    if erro.pedido:
        txt += f"\n(código do pedido no ElevenLabs, para o suporte deles: {erro.pedido})"
    return txt


def erro_de_modelo(erro):
    return erro.http in (400, 403, 422) and erro.fala_de("model")


def erro_de_ajuste(erro):
    return erro.http in (400, 422) and erro.fala_de("stability", "voice_settings")


# ---------------------------------------------------------------- elenco e receitas

ELENCO = kit("vozes", "elenco.json")
RECEITAS = kit("vozes", "receitas.json")
AMOSTRAS = kit("vozes", "amostras")


def elenco():
    return le_json(ELENCO, {"vozes": {}}).setdefault("vozes", {})


def grava_elenco(vozes):
    grava_json(ELENCO, {"sobre": "Vozes da sua conta do ElevenLabs que o kit usa. Criado pelo gerar_vozes.py.", "vozes": vozes})


def receitas():
    return le_json(RECEITAS, {"receitas": {}}).get("receitas", {})


def nome_valido(nome):
    if not re.fullmatch(r"[A-Za-z0-9_\-]{2,40}", nome):
        para(f"Nome de voz inválido: {nome}\nUse só letras sem acento, números, _ ou -, como rapaz ou mulher_jovem.")
    return nome


def parece_id(valor):
    return bool(re.fullmatch(r"[A-Za-z0-9]{16,40}", valor or ""))


def cmd_receitas():
    rs = receitas()
    if not rs:
        para(f"Não achei as receitas de voz em {RECEITAS}.")
    print("Vozes prontas do kit (cada uma vira uma voz na sua conta com: amostras NOME e depois salvar NOME N):\n")
    for nome, r in rs.items():
        print(f"  {nome:15s} {r.get('titulo', '')}")
        if r.get("uso"):
            print(f"  {'':15s} serve para: {r['uso']}")
    print("\nTambém dá para criar qualquer outra voz com uma descrição em inglês:\n"
          f"  {PY} gerar_vozes.py amostras capitao \"Brazilian man in his sixties, deep raspy voice, native Brazilian Portuguese\"")


def cmd_elenco():
    vozes = elenco()
    if not vozes:
        print("O elenco está vazio. Crie vozes com os comandos amostras e salvar (veja: receitas).")
        return
    print("Vozes do elenco (nome, voice_id, origem):")
    for nome, v in vozes.items():
        print(f"  {nome:15s} {v.get('voice_id', ''):24s} {v.get('origem', '')}")


# ---------------------------------------------------------------- comandos que falam com a API

def cmd_chave():
    chave = le_chave()
    try:
        corpo, _ = pede(chave, "GET", "/v1/user/subscription")
    except ErroAPI as e:
        if e.fala_de("insufficient_permissions", "missing_permissions"):
            print(f"A chave ({mascara(chave)}) foi aceita, mas não tem permissão para ler os créditos da conta.\n"
                  "Para gerar vozes ela precisa de acesso a Text to Speech e a Voices. Se der erro de permissão depois,\n"
                  "crie uma chave nova com Restrict Key desligado.")
            return
        para(explica(e, "conferir a chave"))
    d = json.loads(corpo.decode("utf-8", errors="replace") or "{}")
    usados, limite = d.get("character_count", 0), d.get("character_limit", 0)
    print(f"Chave aceita ({mascara(chave)}). Plano: {d.get('tier', '?')}.")
    if limite:
        print(f"Créditos usados neste mês: {usados} de {limite} (sobram {max(0, limite - usados)}).")
    if d.get("voice_limit"):
        print(f"Vagas de voz própria: {d.get('voice_slots_used', 0)} de {d.get('voice_limit')} em uso.")
    renova = d.get("next_character_count_reset_unix")
    if renova:
        print("Os créditos renovam em " + datetime.datetime.fromtimestamp(renova).strftime("%d/%m/%Y") + ".")


def creditos(chave):
    # Consulta rapida e silenciosa, so para mostrar quanto sobra. Se falhar, nao atrapalha nada.
    req = urllib.request.Request(BASE + "/v1/user/subscription", headers={"xi-api-key": chave, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15, context=CTX if BASE.startswith("https") else None) as r:
            d = json.loads(r.read().decode("utf-8", errors="replace") or "{}")
        return max(0, d.get("character_limit", 0) - d.get("character_count", 0))
    except Exception:
        return None


def cmd_minhas_vozes():
    chave = le_chave()
    vozes, token = [], None
    for _ in range(10):
        consulta = {"page_size": 100}
        if token:
            consulta["next_page_token"] = token
        try:
            corpo, _ = pede(chave, "GET", "/v2/voices", consulta=consulta)
        except ErroAPI as e:
            para(explica(e, "listar as vozes da conta"))
        d = json.loads(corpo.decode("utf-8", errors="replace") or "{}")
        vozes += d.get("voices", [])
        token = d.get("next_page_token")
        if not d.get("has_more") or not token:
            break
    if not vozes:
        print("Nenhuma voz na sua conta ainda. Crie com os comandos amostras e salvar.")
        return
    print("Vozes da sua conta (nome, voice_id, tipo):")
    for v in vozes:
        print(f"  {v.get('name', '')[:40]:40s} {v.get('voice_id', ''):24s} {v.get('category', '')}")
    print("\nNo plano grátis, a API só usa as vozes que você mesmo criou (tipo generated ou cloned).\n"
          f"Para pôr uma delas no elenco: {PY} gerar_vozes.py usar NOME VOICE_ID")


def texto_padrao_amostra():
    return ("Oi, tudo bem? Essa é uma amostra da minha voz para a sua série. Eu posso falar com calma, "
            "posso ficar nervoso, posso sussurrar e posso gritar quando a história pedir. Escuta e vê se combina.")


def cmd_amostras(nome, alvo):
    nome = nome_valido(nome)
    rs = receitas()
    alvo = alvo or nome
    if alvo in rs:
        r = rs[alvo]
        descricao, texto, semente, origem = r["descricao"], r.get("texto") or texto_padrao_amostra(), r.get("semente"), f"receita {alvo}"
    elif len(alvo) >= 20:
        descricao, texto, semente, origem = alvo, texto_padrao_amostra(), None, "descrição própria"
    else:
        para(f"Não conheço a receita \"{alvo}\". Receitas do kit: {', '.join(rs) or 'nenhuma'}.\n"
             f"Ou passe uma descrição em inglês com pelo menos 20 letras, entre aspas.")
    if not 100 <= len(texto) <= 1000:
        para("O texto da amostra precisa ter entre 100 e 1000 letras.")
    chave = le_chave()
    corpo = {"voice_description": descricao, "text": texto}
    if semente is not None:
        corpo["seed"] = int(semente)
    resposta = None
    for modelo in MODELOS_DESIGN_RESERVA:
        corpo["model_id"] = modelo
        try:
            resposta, _ = pede(chave, "POST", "/v1/text-to-voice/design", corpo, consulta={"output_format": FORMATO}, tempo=240)
            break
        except ErroAPI as e:
            if erro_de_modelo(e) and modelo != MODELOS_DESIGN_RESERVA[-1]:
                print(f"  (o modelo {modelo} não está disponível na sua conta; tento o próximo)")
                continue
            para(explica(e, "criar as amostras de voz"))
    d = json.loads(resposta.decode("utf-8", errors="replace") or "{}")
    previas = d.get("previews", [])
    if not previas:
        para("O ElevenLabs não devolveu nenhuma amostra. Rode de novo daqui a pouco.")
    os.makedirs(AMOSTRAS, exist_ok=True)
    salvas = []
    for i, p in enumerate(previas, start=1):
        arq = os.path.join(AMOSTRAS, f"{nome}_{i}.mp3")
        with open(arq, "wb") as f:
            f.write(base64.b64decode(p.get("audio_base_64", "")))
        salvas.append({"n": i, "arquivo": os.path.relpath(arq, FAB), "generated_voice_id": p.get("generated_voice_id")})
    grava_json(os.path.join(AMOSTRAS, f"{nome}.json"),
               {"nome": nome, "descricao": descricao, "origem": origem, "modelo": corpo["model_id"],
                "criado_em": datetime.datetime.now().isoformat(timespec="seconds"), "amostras": salvas})
    print(f"{len(salvas)} amostras da voz \"{nome}\" salvas em {os.path.relpath(AMOSTRAS, FAB)}:")
    for s in salvas:
        print(f"  {s['n']}: {s['arquivo']}")
    print(f"\nOuça e escolha uma. Para guardar a amostra 1, por exemplo: {PY} gerar_vozes.py salvar {nome} 1")


def cmd_salvar(nome, n):
    nome = nome_valido(nome)
    info = le_json(os.path.join(AMOSTRAS, f"{nome}.json"), {})
    if not info:
        para(f"Não achei amostras da voz \"{nome}\". Rode antes: {PY} gerar_vozes.py amostras {nome}")
    escolha = next((a for a in info.get("amostras", []) if str(a.get("n")) == str(n)), None)
    if not escolha:
        para(f"A voz \"{nome}\" tem as amostras {', '.join(str(a['n']) for a in info.get('amostras', []))}. Escolha uma delas.")
    chave = le_chave()
    corpo = {"voice_name": f"Fabrica POV {nome}", "voice_description": info["descricao"][:1000],
             "generated_voice_id": escolha["generated_voice_id"]}
    try:
        resposta, _ = pede(chave, "POST", "/v1/text-to-voice", corpo, tempo=120)
    except ErroAPI as e:
        if e.http in (400, 404, 422) and e.fala_de("generated_voice_id", "not found", "expired"):
            para(f"A amostra expirou no ElevenLabs. Crie amostras novas: {PY} gerar_vozes.py amostras {nome}")
        para(explica(e, "salvar a voz na sua conta"))
    voice_id = json.loads(resposta.decode("utf-8", errors="replace") or "{}").get("voice_id")
    if not voice_id:
        para("O ElevenLabs não devolveu o número da voz. Confira no site, em My Voices, e use o comando usar.")
    vozes = elenco()
    vozes[nome] = {"voice_id": voice_id, "origem": f"{info.get('origem', '')}, amostra {n}",
                   "criada_em": datetime.date.today().isoformat()}
    grava_elenco(vozes)
    print(f"Voz \"{nome}\" salva na sua conta (voice_id {voice_id}) e no elenco do kit.")


def cmd_usar(nome, voice_id):
    nome = nome_valido(nome)
    if not parece_id(voice_id):
        para(f"Isso não parece um voice_id do ElevenLabs: {voice_id}\nNo site: My Voices, botão de três pontos da voz, Copy voice ID.")
    vozes = elenco()
    vozes[nome] = {"voice_id": voice_id, "origem": "voz que já estava na conta", "criada_em": datetime.date.today().isoformat()}
    grava_elenco(vozes)
    print(f"Voz \"{nome}\" posta no elenco com o voice_id {voice_id}.")


# ---------------------------------------------------------------- falas de um episodio

def tira_direcao(texto):
    return re.sub(r"^\s*(\[[^\]]*\]\s*)+", "", texto).strip()


def carrega_episodio(cfg_arg):
    if not os.path.isfile(cfg_arg):
        para(f"Arquivo do episódio não encontrado: {cfg_arg}\nRode o comando de dentro da pasta do kit.")
    cfg = le_json(cfg_arg)
    for campo in ("nome", "voz_dir", "prefixo", "arq", "slots"):
        if campo not in cfg:
            para(f"O arquivo {cfg_arg} não tem o campo \"{campo}\".")
    voz_dir = os.path.normpath(cfg["voz_dir"]) if os.path.isabs(cfg["voz_dir"]) else kit(cfg["voz_dir"])
    esperados = [f"{cfg['prefixo']}{n:02d}" for n in cfg["arq"][:len(cfg["slots"])]]
    base, _ = os.path.splitext(cfg_arg)
    falas_arq = cfg.get("falas") or base + "_falas.json"
    if not os.path.isabs(falas_arq) and not os.path.isfile(falas_arq):
        falas_arq = kit(falas_arq) if os.path.isfile(kit(falas_arq)) else falas_arq
    if not os.path.isfile(falas_arq):
        para(f"Falta a lista de falas do episódio: {falas_arq}\n"
             "Ela tem, para cada arquivo de voz, quem fala e o texto. Veja o exemplo episodios/portaria01_falas.json.")
    return cfg, voz_dir, esperados, falas_arq, le_json(falas_arq)


def cmd_falas(cfg_arg, opcoes):
    cfg, voz_dir, esperados, falas_arq, F = carrega_episodio(cfg_arg)
    falas = F.get("falas", [])
    mapa = F.get("elenco", {})
    vozes = elenco()
    problemas, avisos, por_arquivo, sem_voz = [], [], {}, {}
    for i, fala in enumerate(falas, start=1):
        arq, quem, texto = str(fala.get("arquivo", "")).strip(), str(fala.get("quem", "")).strip(), str(fala.get("texto", "")).strip()
        if not arq or not texto:
            problemas.append(f"a fala {i} da lista está sem \"arquivo\" ou sem \"texto\"")
            continue
        if arq in por_arquivo:
            problemas.append(f"o arquivo {arq} aparece duas vezes na lista")
        voz = str(fala.get("voz") or mapa.get(quem, "")).strip()
        if not voz:
            problemas.append(f"{arq}: \"{quem}\" não está no \"elenco\" da lista de falas")
            voice_id = ""
        elif voz in vozes:
            voice_id = vozes[voz]["voice_id"]
        elif parece_id(voz):
            voice_id = voz
        else:
            voice_id = ""
            sem_voz.setdefault(voz, set()).add(quem)
        if re.search(r"\d", tira_direcao(texto)):
            avisos.append(f"{arq}: tem número em algarismo. Escreva por extenso (\"oitocentos e quatro\", não \"804\").")
        meio = tira_direcao(texto)
        if "[" in meio:
            avisos.append(f"{arq}: tem direção entre colchetes no meio da fala. Deixe só no começo.")
        por_arquivo[arq] = {"quem": quem, "voz": voz, "voice_id": voice_id, "texto": texto}
    for voz, quems in sem_voz.items():
        problemas.append(f"a voz \"{voz}\" ({', '.join(sorted(quems))}) ainda não está no elenco. Crie com: {PY} gerar_vozes.py amostras {voz}")
    faltam_na_lista = [a for a in esperados if a not in por_arquivo]
    sobram = [a for a in por_arquivo if a not in esperados]
    if faltam_na_lista:
        problemas.append("o episódio espera estes arquivos que não estão na lista de falas: " + ", ".join(faltam_na_lista))
    if sobram:
        avisos.append("estas falas da lista não são usadas pelo episódio (confira \"arq\" e \"slots\"): " + ", ".join(sobram))

    refazer = set()
    if "--refazer" in opcoes:
        i = opcoes.index("--refazer")
        if i + 1 >= len(opcoes):
            para("Depois de --refazer, escreva os arquivos separados por vírgula, por exemplo: --refazer L03,L07")
        refazer = {x.strip() for x in opcoes[i + 1].split(",") if x.strip()}
        desconhecidos = refazer - set(esperados)
        if desconhecidos:
            para("Estes arquivos não existem no episódio: " + ", ".join(sorted(desconhecidos)))
    todas = "--todas" in opcoes
    gerar, pular = [], []
    for a in esperados:
        if a not in por_arquivo:
            continue
        existe = os.path.isfile(os.path.join(voz_dir, a + ".mp3"))
        (gerar if (todas or a in refazer or not existe) else pular).append(a)
    letras = sum(len(por_arquivo[a]["texto"]) for a in gerar)

    print(f"Episódio {cfg['nome']}: {len(esperados)} falas, pasta {os.path.relpath(voz_dir, FAB)}")
    print(f"Lista de falas: {os.path.relpath(falas_arq, FAB) if os.path.isabs(falas_arq) else falas_arq}")
    papeis = {}
    for a in esperados:
        if a in por_arquivo:
            papeis.setdefault(por_arquivo[a]["quem"], por_arquivo[a]["voz"])
    print("Vozes: " + "; ".join(f"{q} = {v or '?'}" for q, v in papeis.items()))
    print(f"Para gerar agora: {len(gerar)} falas, {letras} letras" + (f" (já existem e ficam como estão: {len(pular)})" if pular else ""))
    for a in avisos:
        print("AVISO: " + a)
    if problemas:
        para("Corrija antes de gerar:\n  " + "\n  ".join(problemas))
    if not gerar:
        print(f"\nTodas as falas já existem. Para gerar de novo uma fala: --refazer L03. Próximo passo: {PY} ep_audio.py {aspas(cfg_arg)} prep")
        return
    modelo = F.get("modelo") or MODELO_PADRAO
    if "--sim" not in opcoes:
        chave = le_chave(obrigatoria=False)
        sobra = creditos(chave) if chave else None
        print(f"\nModelo: {modelo}. Cada letra costuma gastar 1 crédito (o preço exato depende do modelo e do plano).")
        if sobra is not None:
            print(f"Créditos que sobram na sua conta: {sobra}.")
        print(f"Nada foi gerado ainda. Para gerar: {PY} gerar_vozes.py falas {aspas(cfg_arg)} --sim"
              + (" --refazer " + ",".join(sorted(refazer)) if refazer else "") + (" --todas" if todas else ""))
        return

    chave = le_chave()
    os.makedirs(voz_dir, exist_ok=True)
    estab = F.get("estabilidade", 0.3)
    modelos = [modelo] + [m for m in MODELOS_RESERVA if m != modelo]
    usar_ajuste = estab is not None
    feitas = 0
    for a in gerar:
        info = por_arquivo[a]
        while True:
            m = modelos[0]
            texto = info["texto"] if m in MODELOS_COM_DIRECAO else tira_direcao(info["texto"])
            corpo = {"text": texto, "model_id": m}
            if usar_ajuste:
                corpo["voice_settings"] = {"stability": float(estab)}
            try:
                audio, tipo = pede(chave, "POST", f"/v1/text-to-speech/{info['voice_id']}", corpo,
                                   consulta={"output_format": FORMATO}, audio=True, tempo=180)
                break
            except ErroAPI as e:
                if usar_ajuste and erro_de_ajuste(e):
                    usar_ajuste = False
                    print("  (a conta não aceitou o ajuste de estabilidade; sigo com o ajuste da própria voz)")
                    continue
                if erro_de_modelo(e) and len(modelos) > 1:
                    print(f"  (o modelo {m} não está disponível na sua conta; sigo com {modelos[1]})")
                    modelos.pop(0)
                    continue
                print(f"\n{feitas} de {len(gerar)} falas foram salvas antes do erro.")
                para(explica(e, f"gerar a fala {a}"))
        if "json" in tipo.lower() or not audio or audio[:1] == b"{":
            para(f"O ElevenLabs não devolveu áudio para a fala {a}. Rode de novo daqui a pouco.")
        destino = os.path.join(voz_dir, a + ".mp3")
        tmp = destino + ".parcial"
        with open(tmp, "wb") as f:
            f.write(audio)
        try:
            os.replace(tmp, destino)
        except PermissionError:
            os.remove(tmp)
            para(f"Não consegui gravar {destino}. Se ele estiver aberto num player, feche e rode de novo.")
        feitas += 1
        print(f"  {a} ok ({info['quem']}, {len(audio) // 1024} KB)")
    print(f"\n{feitas} falas salvas em {os.path.relpath(voz_dir, FAB)} com o modelo {modelos[0]}.")
    print(f"Próximo passo: {PY} ep_audio.py {aspas(cfg_arg)} prep")


# ---------------------------------------------------------------- entrada

def main():
    a = sys.argv[1:]
    if not a:
        para(USO)
    c = a[0]
    if c == "chave":
        cmd_chave()
    elif c == "receitas":
        cmd_receitas()
    elif c == "elenco":
        cmd_elenco()
    elif c == "minhas-vozes":
        cmd_minhas_vozes()
    elif c == "amostras" and len(a) >= 2:
        cmd_amostras(a[1], a[2] if len(a) > 2 else "")
    elif c == "salvar" and len(a) == 3:
        cmd_salvar(a[1], a[2])
    elif c == "usar" and len(a) == 3:
        cmd_usar(a[1], a[2])
    elif c == "falas" and len(a) >= 2:
        cmd_falas(a[1], a[2:])
    else:
        para(USO)


if __name__ == "__main__":
    main()
