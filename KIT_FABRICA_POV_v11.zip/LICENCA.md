# Licença de uso do kit Fábrica POV

Versão de 14 de novembro de 2026. Ao comprar e usar o kit, você concorda com os termos abaixo.

## 1. O que você pode fazer

- Usar o kit em quantos computadores seus quiser, para produzir os seus próprios vídeos.
- Alterar o código, os cenários e os roteiros para o seu uso.
- Publicar e monetizar os vídeos que você produzir com o kit, em qualquer plataforma. Os vídeos que você faz são seus.

## 2. O que você não pode fazer

- Revender, sublicenciar, alugar ou redistribuir o kit, inteiro ou em partes, com ou sem alterações.
- Publicar o código do kit em repositório público, grupo, fórum ou qualquer outro lugar de acesso aberto.
- Compartilhar o acesso à compra ou os arquivos do kit com terceiros.
- Vender um produto concorrente feito a partir do código do kit.

## 3. Episódios de exemplo

Os dois episódios de exemplo (a portaria e o barco na tempestade), com os seus roteiros, existem para estudo e teste. Use como ponto de partida para criar as suas próprias histórias.

## 4. Componentes de terceiros

O kit depende de programas e bibliotecas que têm licenças próprias. Elas não fazem parte desta licença e cabe a você respeitar cada uma:

- Remotion: tem licença própria. É gratuito para pessoa física e para empresa de até 3 pessoas. Acima disso, é preciso contratar a licença de empresa diretamente com a Remotion. Consulte os termos atuais em remotion.dev/license.
- React, TypeScript, Node, Python e ffmpeg: cada um segue a sua licença de código aberto.
- Fonte Inter: licença SIL Open Font License, incluída em `public/fontes/LICENSE-Inter-OFL.txt`.
- Serviços de voz por IA e a assinatura do Claude não estão incluídos e seguem os termos de cada fornecedor.

## 5. Garantias e limites

O kit é entregue no estado em que se encontra. Não há promessa de alcance, visualizações, seguidores ou renda com os vídeos produzidos.

## 6. Titularidade

O código e os textos do kit pertencem aos criadores da Fábrica POV. A compra dá direito de uso nos termos acima e não transfere a propriedade do kit.
