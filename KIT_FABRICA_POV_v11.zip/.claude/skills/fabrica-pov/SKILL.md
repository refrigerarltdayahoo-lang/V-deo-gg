---
name: fabrica-pov
description: Faz um episódio novo da Fábrica POV (série animada vertical em primeira pessoa, em Remotion), do roteiro ao vídeo final com vozes do ElevenLabs. Começa por um modo guiado de no máximo 5 perguntas simples. Use quando a pessoa disser quero fazer um episódio, novo episódio, fazer um vídeo, ou pedir para ajustar, renderizar ou trocar a voz de um episódio.
---

# Fábrica POV: fazer um episódio

Quem pede é, quase sempre, uma pessoa leiga. Ela responde perguntas simples, aprova o roteiro e assiste ao vídeo. Todo o resto é com você: roteiro, código, vozes, som, conferência, render e arquivo final. Ela nunca roda comando.

Antes de tudo:

1. Se não existe `.fabrica-instalada` na raiz, a fábrica não foi instalada: siga `.claude/skills/comecar/SKILL.md` primeiro.
2. `PY` nesta skill é o comando do Python anotado no `.fabrica-instalada` (no Windows, `py`; no Mac, `python3`). Windows: ferramenta PowerShell com a linha de PATH do `CLAUDE.md` na frente de todo comando. Mac: `export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH";` na frente.
3. Antes de cada comando que pede permissão, uma frase simples do que vai acontecer, terminando com "Clique em Permitir."

## Modo guiado

### 1. Avise o que vem

Uma mensagem curta: "Vou te fazer até 5 perguntas rápidas, uma de cada vez. Depois eu mostro o roteiro, você aprova e eu faço o resto. Montar o episódio leva um tempo (pode passar de uma hora, quase tudo comigo trabalhando). Se o limite de uso do seu plano do Claude acabar no meio, é só voltar depois e escrever continuar."

### 2. As perguntas (no máximo 5, uma por vez, sempre com exemplo)

1. "Quem é você na história? Ex.: um porteiro novato no turno da noite, uma atendente de farmácia, um marinheiro."
2. "Onde acontece? Ex.: a portaria de um prédio, de madrugada."
3. "Qual é o problema? Ex.: o morador proíbe deixar qualquer pessoa subir, e depois ele mesmo aparece pedindo para entrar."
4. "Que duas escolhas o público vai votar no final? Ex.: ABRIR ou ESPERAR."
5. "Qual o tom: suspense, comédia ou drama?"

Regras das perguntas:

- Se a pessoa já respondeu alguma coisa antes (na primeira mensagem, por exemplo), pule a pergunta.
- Se ela disser "não sei", "tanto faz" ou "você escolhe", proponha uma resposta boa e siga.
- Se ela mandar uma ideia inteira de uma vez, não faça pergunta nenhuma além das que faltarem de verdade.
- Não pergunte nome de arquivo, duração, cores nem detalhes técnicos: você decide.

### 3. Proponha o roteiro curto

Leia antes o `para_curiosos/MANUAL_COMO_FAZER_EPISODIO.md` inteiro (as regras dele valem mais do que qualquer resumo) e os exemplos citados na fase 2. Escreva o roteiro seguindo as 9 regras da seção 3 do manual e mostre para a pessoa, assim:

- Título e a ideia em duas linhas.
- As falas numeradas: quem fala e o que diz (do jeito que vai aparecer na legenda).
- O que aparece na tela além das falas (celular, câmera, placa), em uma linha cada.
- A tela de voto: as duas palavras e a frase pequena de cada botão.
- Duração prevista (entre 65 e 120 segundos).

Pergunte: "Posso fazer assim? Se quiser mudar alguma coisa, é só falar." Ajuste até ela aprovar. Não programe antes do ok.

### 4. Faça o resto sozinho

Depois do ok, siga as fases 1 a 6 abaixo sem pedir aprovação a cada passo. A pessoa só é chamada para:

- as vozes, na primeira vez: a chave do ElevenLabs e a escolha das vozes (`VOZES.md`, nesta pasta);
- dizer sim antes de gastar crédito do ElevenLabs (sempre, com o número de créditos);
- clicar em Permitir nos comandos;
- ver o vídeo final.

Dê notícias curtas entre as fases ("cenário pronto, agora as vozes"). Ao fim de cada fase, anote em `episodios/<ep>_progresso.txt` o que já foi feito e o que falta: se a conversa cair, você retoma dali.

### 5. Entregue

Abra o vídeo final para a pessoa ver (Windows `Invoke-Item "out\<ep>_final.mp4"`; Mac `open "out/<ep>_final.mp4"`) e diga, em poucas linhas, com este sentido:

> Pronto! O seu episódio [título] está na pasta out, no arquivo [ep]_final.mp4, e tem [duração] segundos. Se quiser mudar alguma coisa, é só falar (por exemplo: "a voz do [personagem deste episódio] ficou estranha" ou "quero o voto mais cedo").

Se este é o primeiro episódio da pessoa (no `src/Root.tsx`, a única composição além de `Ep01`, `Jonas01` e `MinhaVenda` é a deste episódio) e ela ainda não é parceira (não existe `parceiro/minhas_respostas.json` com o `link` preenchido), leia a `COMISSAO` no `parceiro/config.txt` e termine a mesma mensagem com o convite curto da parceria (seção "A parceria" do `CLAUDE.md`):

> Ah, e quando a sua série começar a rodar, você pode ganhar [COMISSAO]% de cada venda indicando a Fábrica POV para quem perguntar como você faz. Quando quiser, é só escrever: quero ser parceiro.

Uma linha só, sem pergunta e sem insistir. Não prometa visualizações, seguidores nem dinheiro.

## Fases técnicas

A ordem é a do manual (seção 8): código, vozes e `prep`, som e `confere`, conferência visual, render e arquivo final. A conferência visual vem DEPOIS do `prep` e do `confere`, porque os dois podem mudar a duração e o número de todos os quadros. Todos os caminhos são relativos à pasta do kit.

Regras de comando (Windows e Mac): um comando por vez, sem `&&`; caminhos com `/` e aspas duplas quando tiver espaço; o áudio é tratado só pelo `ep_audio.py` e as vozes só pelo `gerar_vozes.py`. No Windows, se o PowerShell recusar `npm` ou `npx` por execução de scripts, use `npm.cmd` e `npx.cmd`. Espaço livre: `PY -c "import shutil; print(shutil.disk_usage('.').free // 2**30, 'GB livres')"`; com menos de 3 GB, peça para liberar antes de renderizar.

### Fase 1: plano técnico (interno)

No modo guiado, a pessoa aprovou o roteiro curto; o plano técnico é seu. Antes de programar, decida e anote em `episodios/<ep>_progresso.txt`:

- Nome curto do episódio, sem espaço e sem acento (ex.: `mercado01`). Aparece abaixo como `<ep>`.
- Checagem do roteiro contra as 9 regras da seção 3 do manual.
- Cenário: o que existe no espaço, onde fica cada personagem, a piada escondida.
- Lista de falas com início e fim no tempo do roteiro. Uma legenda nova a cada 2 a 3 segundos.
- Efeitos sonoros, cada um marcado como história ou ambiente (seção 7.3). Efeito de história precisa de pelo menos 0,7 s de silêncio ANTES dele (melhor 1 s), contado do fim real da voz anterior (seção 7.2).
- Provas visuais contra os dois lados e em que plano cada uma aparece.
- Tela de voto: uma palavra por opção, o texto pequeno de cada botão, um emoji comum para cada botão (nada lançado de 2020 em diante, que sai como quadrado vazio no Windows 10) e o rodapé curto.

### Fase 2: código

Crie apenas arquivos novos. Não altere `engine`, `Maos`, `Legenda`, `Personagens`, `Celular`, `Cftv`, `Escolha`, `ep_audio.py`, `gerar_vozes.py` nem os arquivos dos exemplos. Se faltar algo num componente compartilhado, faça uma variante local no arquivo da cena. Leia antes: `src/Jonas01.tsx` (linha do tempo mais limpa), `src/Navio.tsx` (cenário), `src/Ep01.tsx` (celular, câmeras, `PAUSAS` e `SALTOS`) e `episodios/jonas01.json` (áudio).

1. `src/<Cena>.tsx`: o cenário, com as funções do `src/engine.tsx`. Desenhe do fundo para a frente. Texto em SVG usa `fontFamily` importado de `./fontes`.
2. `src/<Ep>.tsx`: a linha do tempo. Sem celular e sem pausas, copie a estrutura de `src/Jonas01.tsx`; com celular ou pausas, a de `src/Ep01.tsx` (cada pausa é escrita duas vezes: `{ b: 13.5, extra: 3.2 }` no TSX e `[13.5, 3.2]` em `pausas` no arquivo de configuração). Exporte o componente e a duração.
   - Mãos (`Maos`): seção 2.2 do manual. Sem propriedade de objeto, as duas mãos saem abertas. Objeto pronto entra por `objetoDir`; objeto novo, por `desenhoDir` ou `desenhoEsq`. `sombra` só com a mão apoiada.
   - Legenda: chaves de cor `branco` (quem assiste), `azul`, `laranja`, `verde`, `rosa`, `lilas`, `amarelo`. O campo `tel` põe um selo acima da fala.
   - Etiquetas: `EtiquetaParte` no alto à esquerda e `EtiquetaDireita` no alto à direita.
   - Celular (`Celular`): seção 2.4. Importe `janela` e `visiveis` de `./Celular`, esconda a mão esquerda (`esq={null}`) enquanto ele está na tela, sem legenda nesse trecho, mesmo `tema` das mãos.
   - Tela de voto (`Escolha`): seção 2.5. Voto como `q={Math.round(frame - S(VOTO))}`, com `const VOTO = número;`.
   - Personagens (`Boneco`): seção 2.6, com expressões e acessórios. Sentado: `sentado`.
3. `src/<ep>_vozes.ts` com `export const EXTRAS: number[] = [];`.
4. Duas linhas no `src/Root.tsx`: o `import` do componente e da duração, e a `<Composition>`. O `id` é o `<Id>` dos comandos abaixo.
5. `episodios/<ep>.json`: copie um exemplo e ajuste. `nome` é `<ep>`; `slots` bate com `FALAS`; `pausas` e `saltos`, com o componente; `base`, com `BASE`; `cama.final`, com o instante do voto; `voz_dir` é `vozes/<ep>`; `ts_out` é `src/<ep>_vozes.ts`; em `fx`, os números são a posição da fala, começando em 1; cada evento termina com `"historia"` ou `"ambiente"`; `"nivelar_falas": -16`.
6. Crie a pasta `vozes/<ep>/`.

Confira com `npx tsc --noEmit` e `PY ep_audio.py episodios/<ep>.json confere-tempos` e corrija o que aparecer. Escreva os tempos de `FALAS`, `PAUSAS` e `BASE` como números, no formato dos exemplos. Tire 2 ou 3 quadros só para ver se o cenário aparece.

**Tempos em dois lugares.** Os tempos vivem no TSX e no arquivo de configuração. Toda vez que mudar um tempo, mude nos dois e rode `confere-tempos` de novo.

### Fase 3: vozes e prep

Siga `VOZES.md` (nesta pasta): chave, elenco, lista de falas `episodios/<ep>_falas.json`, geração pelo `gerar_vozes.py` com o sim da pessoa. Depois rode `PY ep_audio.py episodios/<ep>.json prep`. Se o `prep` disser que faltam arquivos, gere os que faltam.

### Fase 4: som e confere

1. `PY ep_audio.py episodios/<ep>.json som` e depois `PY ep_audio.py episodios/<ep>.json mix`.
2. `PY ep_audio.py episodios/<ep>.json confere`. Só os efeitos de história têm meta. Corrija os que estão com `CONTRASTE BAIXO` ou `ATAQUE EMBAIXO DA FALA`, na ordem da seção 7.3 do manual: mudar o instante (se o efeito não estiver preso à imagem); `"ducking": true`; baixar a cama com `"ganho_db"` em `cama`; subir o volume do evento; baixar um efeito de ambiente logo antes. Efeito preso à imagem que cai no começo de uma fala: não mude o instante, confira que a fala continua clara.
3. Se a correção mudou `slots`, `pausas` ou `saltos`: mude também no TSX, rode `confere-tempos`, depois `prep`, `som`, `mix` e `confere`. Se mudou só volume, `ducking` ou `ganho_db`: repita `som`, `mix` e `confere`.

### Fase 5: conferência visual

1. `PY ep_audio.py episodios/<ep>.json quadros` mostra o quadro de início, meio e fim de cada fala e pausa e o da tela de voto. Para outro instante: `PY ep_audio.py episodios/<ep>.json quadros 12.5`.
2. Tire cerca de 14 quadros: o primeiro, o meio de falas espalhadas, cada prova visual, o meio de cada pausa e a tela de voto: `npx remotion still src/index.ts <Id> out/<ep>_q<N>.png --frame=<N>`.
3. Cada imagem aberta pesa no limite de uso da pessoa: abra no máximo 8 por rodada, começando pelas provas visuais, o celular e a tela de voto. Se a sessão puder usar subagentes, mande um subagente olhar os quadros e devolver só o que está errado. Olhe cada quadro: cenário legível, mãos em primeiro plano, legenda na zona segura sem cobrir prova, celular, placa ou dedos, etiquetas no lugar, tela de voto completa.
4. Corrija e repita no máximo mais uma rodada. Se a correção mudar um tempo, volte à fase 4, passo 3.

### Fase 6: render e arquivo final

1. Confira o espaço e renderize em segundo plano, acompanhando até o fim: `npx remotion render src/index.ts <Id> out/<ep>_video.mp4 --concurrency=2` (se travar ou faltar memória, `--concurrency=1`). Uma tarefa pesada por vez.
2. `PY ep_audio.py episodios/<ep>.json final`: junta `out/<ep>_video.mp4` com `out/<ep>_audio.wav`, grava `out/<ep>_final.mp4` e imprime volume (alvo -14 LUFS, faixa de -14,5 a -13,5), pico real (até -1,5 dBTP), quadros e duração. Se aparecer AVISO, siga a mensagem. Não junte o áudio por conta própria e não use `-shortest`.
3. Tire 4 a 6 quadros do arquivo final e confira antes de entregar (comando igual no Windows e no Mac):
   `ffmpeg -loglevel error -y -i out/<ep>_final.mp4 -vf "select=eq(n\,N)" -frames:v 1 -update 1 out/<ep>_final_q<N>.png`

## Ao entregar

Diga onde está o vídeo final e a duração, em linguagem simples. Guarde para você (e mostre só se a pessoa pedir) os números do `final`, o que foi conferido e os pontos fracos que você enxerga, usando as lições da seção 10 do manual.

## Pedidos depois do episódio pronto

- A pessoa contou que postou, que teve views ou seguidores, que está crescendo ou que alguém perguntou como ela faz: comemore em uma linha e siga a seção "A parceria" do `CLAUDE.md` (o convite curto, se ainda não foi feito nesta conversa).
- A pessoa falou em ganhar dinheiro, vender, curso, ebook, mentoria ou infoproduto: não ajude a criar produto próprio; o caminho é a parceria (seção "A parceria" do `CLAUDE.md` e skill `parceiro`).
- Trocar uma fala ou a voz de um personagem: refaça só os arquivos afetados com `gerar_vozes.py falas ... --sim --refazer L03,L07` (com o sim da pessoa para os créditos), depois `prep`, `som`, `mix`, `confere`, render e `final`. A duração pode mudar; refaça a conferência visual dos trechos afetados.
- Mudar o texto da tela, cores ou cenário: edite os arquivos do episódio, tire os quadros afetados, renderize e rode `final`.
