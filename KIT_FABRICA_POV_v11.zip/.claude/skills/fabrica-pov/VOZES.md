# Vozes com o ElevenLabs (fase 3 do episódio)

As vozes são geradas pelo `gerar_vozes.py`, que fala com a API do ElevenLabs e salva os MP3 com os nomes que o `ep_audio.py` espera. Você roda os comandos; a pessoa só cola a chave uma vez, escolhe vozes se quiser e diz sim antes de gastar crédito.

## 1. A chave (só na primeira vez)

Se o arquivo `.env` não existe na raiz do kit, explique e passe o caminho, um passo por mensagem se a pessoa se perder:

> Para as vozes eu uso o ElevenLabs, um site de vozes por inteligência artificial. A conta grátis serve para começar. Faça assim:
> 1. Entre em elevenlabs.io e crie a sua conta (botão Sign up). Pode entrar com o Google.
> 2. No menu da esquerda, clique em Developers (Desenvolvedores) e depois na aba API Keys (Chaves de API).
> 3. Clique em Create API Key (Criar chave de API). Dê um nome, por exemplo fabrica. Se aparecer a opção Restrict Key, deixe desligada. Clique em Create Key (Criar chave).
> 4. Copie a chave que aparecer (ela começa com sk_ e só aparece uma vez) e cole aqui na conversa.

Quando a pessoa colar a chave:

1. Crie o arquivo `.env` na raiz do kit com a linha `ELEVENLABS_API_KEY=<chave>` (ferramenta de escrever arquivo). Não repita a chave na conversa.
2. "Vou conferir se a chave funciona. Isso não gasta crédito. Clique em Permitir." `PY gerar_vozes.py chave`
3. Conte em uma frase o plano e quantos créditos sobram. Se for o plano grátis, diga uma vez, sem assustar: "No plano grátis são 10 mil créditos por mês (cada letra falada gasta mais ou menos 1) e cabem 3 vozes suas. O plano grátis não inclui licença comercial: se for ganhar dinheiro com os vídeos, veja os planos pagos no site do ElevenLabs."

Se der erro, a mensagem do `gerar_vozes.py` já diz o que fazer. Os casos comuns: chave copiada pela metade (peça para copiar de novo), chave apagada no site, VPN ligada no plano grátis ("atividade incomum").

## 2. O elenco

`PY gerar_vozes.py elenco` mostra as vozes já criadas (ficam em `vozes/elenco.json`). Reaproveite sempre que der: quem assiste (o "você") deve ter a mesma voz em toda a série.

Para cada personagem sem voz, sugira uma receita pronta do kit (`PY gerar_vozes.py receitas`):

| Receita | Serve para |
|---|---|
| `rapaz` | quem assiste (você), protagonista jovem |
| `homem_maduro` | morador misterioso, chefe, capitão, vilão calmo |
| `homem_animado` | entregador, amigo, marinheiro, colega |
| `mulher_jovem` | moradora, amiga, cliente, protagonista jovem |
| `mulher_madura` | gerente, síndica, mãe, médica, policial |

Para um personagem que não cabe em nenhuma (criança, idoso, sotaque forte), escreva uma descrição em inglês com idade, gênero, "native Brazilian Portuguese speaker", timbre e jeito de falar, e use no lugar da receita.

No plano grátis cabem 3 vozes próprias. Monte o elenco dentro disso: personagem pequeno reaproveita a voz de outro que não contracena com ele. Com 3 vozes já criadas e um personagem novo importante, pergunte se a pessoa prefere reaproveitar uma voz ou apagar uma no site (menu Voices, My Voices).

Para criar uma voz:

1. Diga: "Para o porteiro vou usar a voz rapaz. Vou criar 3 amostras para você escolher; isso gasta um pouco de crédito. Posso?" Espere o sim.
2. `PY gerar_vozes.py amostras <nome> [receita ou "descrição"]` (o nome é curto, sem acento: `rapaz`, `seu_alvaro`). As amostras ficam em `vozes/amostras/<nome>_1.mp3` a `_3.mp3`.
3. Pergunte se ela quer ouvir. Se sim, abra a pasta (Windows `Invoke-Item vozes\amostras`; Mac `open vozes/amostras`) e pergunte qual prefere: 1, 2 ou 3. Se ela não quiser ouvir, use a 1.
4. `PY gerar_vozes.py salvar <nome> <n>`: a voz vai para a conta dela (ocupa 1 vaga) e para o elenco.

Se a pessoa já tem vozes próprias na conta (ou um plano pago e uma voz da biblioteca adicionada em My Voices), dá para usar: `PY gerar_vozes.py minhas-vozes` lista, e `PY gerar_vozes.py usar <nome> <voice_id>` põe no elenco. No plano grátis, a API não usa vozes da biblioteca do ElevenLabs (Voice Library); o `gerar_vozes.py` avisa se for o caso.

## 3. A lista de falas

Escreva `episodios/<ep>_falas.json` no formato do exemplo `episodios/portaria01_falas.json`:

```json
{
  "modelo": "eleven_v4",
  "estabilidade": 0.3,
  "elenco": {"Você": "rapaz", "Interfone": "homem_maduro"},
  "falas": [
    {"arquivo": "L01", "quem": "Você", "texto": "[calm, tired] Portaria, boa noite."}
  ]
}
```

- `arquivo` é o nome do MP3 sem extensão: o `prefixo` do `episodios/<ep>.json` mais o número com 2 dígitos, na ordem de `arq` (o mesmo nome que o `prep` procura). Uma linha por arquivo.
- `elenco` liga cada `quem` a um nome do elenco (ou a um voice_id).
- `texto` segue a receita da seção 4 do manual: direção de emoção em inglês, entre colchetes, só no começo; número por extenso ("oitocentos e quatro"); não comece com palavra escrita igual ao inglês (final, real, total, normal); texto limpo, sem efeito (interfone, vidro e porão são aplicados pelo `prep`).
- `modelo`: `eleven_v4` é o padrão. Se a conta não aceitar, o `gerar_vozes.py` tenta sozinho `eleven_v3` e depois `eleven_multilingual_v2` (este não entende a direção entre colchetes, então ela é tirada do texto).

## 4. Gerar

1. Confira sem gastar nada: `PY gerar_vozes.py falas episodios/<ep>.json`. Ele aponta erro na lista (voz que falta no elenco, arquivo que falta, número em algarismo) e mostra quantas letras serão geradas e quantos créditos sobram.
2. Diga o número e peça o sim: "São 23 falas, umas 1.100 letras, mais ou menos 1.100 créditos dos 9.400 que você tem. Posso gerar?"
3. Com o sim: `PY gerar_vozes.py falas episodios/<ep>.json --sim`. Ele só gera o que ainda não existe. Para refazer falas específicas: `--sim --refazer L03,L07` (também com o sim da pessoa).

## 5. Conferir

Você não ouve áudio, e uma fala errada descoberta só no vídeo final custa outro render. Por isso recomende ouvir antes: "As falas estão prontas. Recomendo ouvir antes de eu montar o vídeo, leva uns 2 minutos. Abro a pasta para você?" Se a pessoa apontar uma fala errada (palavra repetida, trocada, sotaque estranho), reescreva o texto se preciso e refaça só ela com `--refazer`. Se houver um transcritor instalado no computador, use como apoio (exemplos na seção 4 do manual). Se a pessoa não quiser ouvir, siga: ela confere no vídeo final e você refaz o que ela apontar.

Depois: `PY ep_audio.py episodios/<ep>.json prep` e siga a fase 4 da skill.

## Plano B: sem chave do ElevenLabs

Se a pessoa não quiser criar conta ou usar chave:

1. Mostre a lista de falas numa tabela simples: nome do arquivo, quem fala, texto para colar no gerador de voz.
2. Explique: gerar uma voz por fala no site de voz que ela preferir, baixar em MP3, renomear com o nome da tabela (L01.mp3, L02.mp3...) e pôr todos na pasta `vozes/<ep>` do kit. Abra a pasta para ela (Windows `Invoke-Item vozes\<ep>`; Mac `open vozes/<ep>`).
3. Quando ela disser que terminou, rode o `prep`. Se faltar arquivo, a mensagem do `prep` lista quais.
