---
name: comecar
description: Instala e configura a Fábrica POV do zero no Windows ou no Mac (Node, Python, ffmpeg, peças do projeto, navegador do Remotion), renderiza o exemplo A Portaria e abre o vídeo. Use quando a pessoa escrever começar, instalar ou continuar e o arquivo .fabrica-instalada ainda não existir.
---

# Instalar a Fábrica POV

Você vai instalar tudo sozinho. A pessoa só clica em Permitir e, em poucos momentos, numa janela do sistema. Siga as etapas na ordem. Cada etapa confere antes se já está feita: se a pessoa voltar depois ("continuar"), recomece da etapa 1 e pule o que já existe.

Regras desta instalação (além das do `CLAUDE.md`):

- Antes de cada comando: uma frase simples dizendo o que vai acontecer, terminando com "Clique em Permitir."
- Um comando por vez. Leia a saída antes do próximo.
- Comandos de instalação, `npm install` e render: timeout de 600000 ms. Se um comando passar para segundo plano, acompanhe a saída até o fim antes de seguir.
- Windows: ferramenta PowerShell, com a linha de PATH do `CLAUDE.md` (abaixo chamada de `[PATH]`) no começo de todo comando que usa node, npm, npx, py, python, ffmpeg ou winget. Mac: `export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH";` no começo de todo comando.
- Não diga "terminal", "PATH" nem "dependência" para a pessoa.
- Parceria: não fale dela por conta própria durante a instalação. Se a pessoa perguntar como ganhar dinheiro com a fábrica, ou falar em vender, curso ou infoproduto, responda em duas linhas como na seção "A parceria" do `CLAUDE.md` (o caminho é a parceria, não um produto próprio) e ofereça fazer o modo parceiro quando a instalação terminar, ou agora, se ela preferir (os textos de parceiro não precisam da fábrica instalada). Depois siga de onde parou.
- Windows PowerShell 5.1 mostra em vermelho (NativeCommandError) qualquer texto que um programa escreve como aviso. Isso não é erro se o comando terminou com código 0: confira `$LASTEXITCODE` e o fim da saída antes de concluir que falhou, e não assuste a pessoa por causa disso.

## Etapa 0. Apresentação

Responda com este sentido, nas suas palavras, curto:

> Oi! Vou montar a sua Fábrica POV agora. Você não precisa digitar nenhum comando: eu faço tudo e vou te avisando. De vez em quando vai aparecer um pedido de permissão. Antes de cada um eu explico numa frase o que vai acontecer, e você só clica em Permitir. Leva de 15 a 30 minutos, conforme a internet e o computador. Primeiro vou ver o que o seu computador já tem. Isso só lê, não muda nada. Clique em Permitir.

Se for Mac, acrescente: "Se o Mac perguntar se o Claude pode acessar a pasta Downloads, clique em Permitir." Se for Windows: "Se aparecer uma janela do Windows perguntando se um programa pode fazer alterações, clique em Sim."

Se a sessão estiver no modo Plan, peça para trocar para Manual no seletor de modo (embaixo da caixa de texto) e escrever continuar, antes de qualquer comando.

E já rode o comando da etapa 1.

## Etapa 1. Olhar o computador (só leitura)

Windows (PowerShell), um comando só:

```
$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') + ';' + $env:Path; "windows=" + [Environment]::OSVersion.Version; "cpu=" + $env:PROCESSOR_ARCHITECTURE; "pasta=" + (Get-Location).Path; "livre_gb=" + $(try { [math]::Round((Get-PSDrive ((Get-Location).Drive.Name)).Free/1GB,1) } catch { 'desconhecido' }); foreach ($c in 'winget','node','npm','py','python','ffmpeg','ffprobe') { "$c=" + (Get-Command $c -ErrorAction SilentlyContinue).Source }; if (Get-Command node -EA 0) { "node_v=" + (node -v) }; if (Get-Command py -EA 0) { "py_v=" + (py --version) }; if (Get-Command ffmpeg -EA 0) { "ffmpeg_v=" + (ffmpeg -version | Select-Object -First 1) }; "projeto_instalado=" + (Test-Path node_modules\@remotion\cli)
```

Mac (Bash), um comando só:

```
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"; echo "macos=$(sw_vers -productVersion)"; echo "cpu=$(uname -m)"; echo "pasta=$(pwd)"; echo "livre_gb=$(df -g . | tail -1 | awk '{print $4}')"; for c in brew node npm python3 ffmpeg ffprobe; do echo "$c=$(command -v $c)"; done; echo "clt=$(xcode-select -p 2>/dev/null)"; command -v node >/dev/null && echo "node_v=$(node -v)"; command -v ffmpeg >/dev/null && echo "ffmpeg_v=$(ffmpeg -version | head -1)"; [ -d node_modules/@remotion/cli ] && echo projeto_instalado=sim
```

Como ler o resultado:

- Programa presente = linha com caminho depois do `=`. Node precisa ser versão 18 ou mais nova.
- Windows: `python=` apontando para `...\WindowsApps\python.exe` é só um atalho da Microsoft Store, não é o Python. Conta como ausente se não houver `py`.
- Mac: `python3=/usr/bin/python3` com `clt=` vazio é só um atalho que abre uma janela de instalação; conta como ausente. Não rode esse `python3`.
- Windows antes da versão 10.0.17763: o app do Claude e as ferramentas não funcionam; avise com gentileza.
- Windows com `cpu=ARM64` (notebooks Snapdragon): avise que o motor de vídeo não tem versão própria para esse processador e que você vai tentar com a versão x64 do Node, que o Windows roda por emulação. Na etapa 3, instale o Node com `--architecture x64`. Esse caminho não foi testado; se o render falhar, explique e indique o suporte.
- Espaço: Windows precisa de pelo menos 3 GB livres; Mac, 5 GB (o Homebrew e o ffmpeg ocupam mais). Se faltar, peça para liberar espaço e escrever "continuar".
- Se `projeto_instalado` for verdadeiro e Node, Python e ffmpeg estiverem presentes, pule para a etapa 5.

Diga à pessoa, em uma ou duas frases, o que já tem e o que falta.

## Etapa 2. A pasta está num lugar bom?

Mude a pasta de lugar SÓ nestes casos:

- Windows: o caminho tem `OneDrive` (a sincronização trava a instalação).
- Mac: o caminho começa com `/Volumes/` (HD externo ou pendrive, que costuma ser exFAT e quebra a instalação) ou tem `Mobile Documents` (iCloud).

Como fazer:

1. Explique: "Sua pasta está num lugar que atrapalha a instalação (OneDrive / HD externo / iCloud). Vou copiar o kit para um lugar seguro no seu computador. Clique em Permitir."
2. Windows: `robocopy "<pasta atual>" "C:\fabrica-pov" /E /XD node_modules out /NFL /NDL /NJH /NJS` (código de saída de 0 a 7 é sucesso). Se `C:\fabrica-pov` já existir com outro conteúdo, use `C:\fabrica-pov2`. Se o Windows negar acesso a `C:\`, use `$env:USERPROFILE\fabrica-pov`.
   Mac: `rsync -a --exclude node_modules --exclude out ./ "$HOME/fabrica-pov/"`.
3. Peça para a pessoa abrir a pasta nova no Claude, passo a passo: "Embaixo da caixa de texto, clique no nome da pasta, escolha Open folder… (Abrir pasta…), vá até [Disco Local (C:) > fabrica-pov] / [a pasta da sua casa, a do ícone de casinha > fabrica-pov], clique em Select Folder / Open e escreva continuar." No Mac, o atalho Cmd+Shift+H leva à pasta da casa nessa janela.
4. Pare aqui. A instalação continua na sessão da pasta nova.

## Etapa 3. Instalar os programas que faltam

### Windows

Instale só o que faltou na etapa 1, um por vez, nesta ordem. Antes de cada um, explique e avise da janela do Windows:

> Vou instalar o Node, o programa que monta os vídeos. Clique em Permitir. Se o Windows perguntar se o instalador pode fazer alterações no computador, clique em Sim (a janela pode piscar na barra de tarefas).

1. Sem `winget`: abra a loja na página do Instalador de Aplicativo com `Start-Process "ms-windows-store://pdp/?productid=9NBLGGH4NNS1"` e diga: "Abri a Microsoft Store. Clique em Obter ou Atualizar, espere terminar e escreva continuar aqui." Pare até a pessoa voltar.
2. Node: `[PATH] winget install --id OpenJS.NodeJS.LTS -e --source winget --accept-source-agreements --accept-package-agreements --disable-interactivity` (em ARM64, acrescente `--architecture x64`).
3. Python ("o Python, que cuida do som dos episódios"): `[PATH] winget install --id Python.Python.3.12 -e --source winget --accept-source-agreements --accept-package-agreements --disable-interactivity`
4. ffmpeg ("o ffmpeg, que junta imagem e som"): `[PATH] winget install --id Gyan.FFmpeg -e --source winget --accept-source-agreements --accept-package-agreements --disable-interactivity`

Saída do winget que NÃO é erro: "já instalado" / "Found an existing package already installed" / "No available upgrade found". Se a pessoa recusou a janela do Windows (código 1602, 1223 ou "cancelado"), explique que precisa clicar em Sim e tente de novo uma vez.

Confira tudo num comando: `[PATH] node -v; npm -v; py --version; ffmpeg -version | Select-Object -First 1`

- `py` não reconhecido: procure `"$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"` com `Test-Path`. Se existir, use esse caminho completo, entre aspas e com `&` na frente no PowerShell, no lugar de `py` daqui em diante e anote no `.fabrica-instalada`.
- Algum programa continua "não reconhecido" mesmo com a linha `[PATH]`: diga "O Windows instalou, mas o app do Claude só enxerga programas novos depois de reaberto. Feche o Claude por completo: clique com o botão direito no ícone do Claude perto do relógio e escolha Quit (Sair). Abra o Claude de novo, clique nesta conversa na barra lateral e escreva continuar." Pare até a pessoa voltar.

### Mac

0. Sem as ferramentas de desenvolvedor da Apple (`clt=` vazio) e faltando o Homebrew ou algum programa: instale-as primeiro, porque o Homebrew usa essas ferramentas e, sem elas, uma janela da Apple aparece no meio da instalação. Diga: "Primeiro o Mac precisa das ferramentas de desenvolvedor da Apple, que são grátis. Vou abrir a janela da Apple. Clique em Permitir." Rode `xcode-select --install` e depois: "Abriu uma janela da Apple. Clique em Instalar, depois em Concordar, e espere terminar (de 5 a 15 minutos). Quando acabar, escreva pronto aqui." Pare até a pessoa voltar e confira com `xcode-select -p`.
1. Sem Homebrew (`brew=` vazio):
   - `cpu=arm64` (Mac com chip Apple): explique "Seu Mac ainda não tem o Homebrew, um instalador de programas grátis. Vou baixar o instalador oficial e abrir para você. Clique em Permitir." Rode:
     `URL=$(curl -fsSL https://api.github.com/repos/Homebrew/brew/releases/latest | grep -o 'https://[^"]*\.pkg' | head -1); [ -n "$URL" ] || URL="https://github.com/Homebrew/brew/releases/latest/download/Homebrew.pkg"; echo "$URL"; curl -fL -o "$HOME/Downloads/Homebrew.pkg" "$URL" && ls -l "$HOME/Downloads/Homebrew.pkg" && open "$HOME/Downloads/Homebrew.pkg"`
     Se o download falhar ou o arquivo tiver menos de 1 MB, tente uma vez de novo; se falhar outra vez, use o caminho do Mac Intel abaixo (comando no Terminal), que funciona em qualquer Mac.
     Depois diga: "Abriu o instalador do Homebrew. Clique em Continuar até o fim, depois em Instalar, digite a senha do seu Mac quando ele pedir e, quando terminar, clique em Fechar. Aí escreva pronto aqui." Pare até a pessoa voltar e confira com `/opt/homebrew/bin/brew --version`.
   - `cpu=x86_64` (Mac Intel; o instalador `.pkg` do Homebrew é só para chip Apple): este é o único caso em que a pessoa usa o Terminal. Explique com calma: "No seu Mac o Homebrew precisa ser instalado por um comando. É a única vez que você vai fazer isso. Aperte Cmd+Espaço, digite Terminal e aperte Return. Copie a linha abaixo, cole na janela do Terminal e aperte Return. Quando ele pedir a senha, digite a senha do seu Mac (as letras não aparecem, é normal) e aperte Return. Espere aparecer Installation successful e escreva pronto aqui." Mostre a linha oficial, num bloco de código:
     `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
     Avise que em Mac Intel a instalação pode demorar mais. Pare até a pessoa voltar e confira com `/usr/local/bin/brew --version`.
2. Deixe o Homebrew achável nas próximas vezes ("Vou anotar no seu Mac onde o Homebrew fica, para os programas acharem ele depois. Clique em Permitir."):
   `B=$( [ -x /opt/homebrew/bin/brew ] && echo /opt/homebrew/bin/brew || echo /usr/local/bin/brew ); grep -q 'brew shellenv' "$HOME/.zprofile" 2>/dev/null || echo "eval \"\$($B shellenv)\"" >> "$HOME/.zprofile"; echo ok`
3. Instale só o que faltou, num comando ("Agora vou instalar o Node, o Python e o ffmpeg, os três programas que a fábrica usa. Leva de 3 a 10 minutos. Clique em Permitir."):
   `export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"; brew install node python ffmpeg` (tire da lista o que já existe). O ffmpeg traz muitas peças junto: rode em segundo plano e acompanhe até o fim, dando notícias.
   Se o Homebrew disser que faltam as ferramentas de desenvolvedor da Apple (Command Line Tools), rode `xcode-select --install`, diga "Abriu uma janela da Apple. Clique em Instalar, aceite e espere terminar. Depois escreva pronto." e repita o `brew install`.
4. Confira: `export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"; node -v; npm -v; python3 --version; ffmpeg -version | head -1`

## Etapa 4. Peças da fábrica

Pule se `node_modules/@remotion/cli` já existir.

> Agora vou baixar as peças da fábrica, uns 250 MB. Pode levar alguns minutos. Clique em Permitir.

`npm install` (Windows com `[PATH]` na frente).

- Avisos de `vulnerabilities`, `deprecated` ou sobre scripts de instalação são normais: diga "apareceram avisos amarelos, são normais e não atrapalham". Nunca rode `npm audit fix`.
- Windows, erro dizendo que `npm.ps1` não pode ser carregado (execução de scripts desabilitada): use `npm.cmd install` e, daqui em diante, `npm.cmd` e `npx.cmd`.
- `EPERM`, `EBUSY` ou `operation not permitted`: geralmente antivírus ou sincronização segurando arquivos. Rode de novo uma vez. Se repetir no Windows, volte à etapa 2 e copie para `C:\fabrica-pov`.
- Erro de rede (`ETIMEDOUT`, `ECONNRESET`, `getaddrinfo`, `SELF_SIGNED_CERT`): confira a internet com a pessoa e rode de novo. Rede de escola ou de empresa costuma bloquear: sugira tentar em casa ou no roteador do celular. Antivírus que apaga o navegador baixado na etapa 5: peça para liberar a pasta do kit no antivírus.
- `ENOSPC` ou disco cheio: peça para liberar espaço.

## Etapa 5. Navegador do motor de vídeo

> Agora vou baixar o navegador invisível que desenha os quadros do vídeo, uns 100 MB, só desta vez. Clique em Permitir.

`npx remotion browser ensure`

## Etapa 6. Fabricar o exemplo A Portaria

Pule para a etapa 7 se `out/portaria01_exemplo.mp4` já existir.

> Tudo instalado! Agora vou fabricar o episódio de exemplo, A Portaria, para testar a fábrica. Leva de 4 a 12 minutos e o computador pode ficar mais lento nesse tempo. Clique em Permitir.

`npx remotion render src/index.ts Ep01 out/portaria01_video.mp4 --concurrency=2`

Rode em segundo plano (timeout de 1800000 ms) e acompanhe a saída; a cada poucos minutos diga em que ponto está ("já foram 1.800 de 3.523 quadros"). São 3.523 quadros. Se o computador travar ou o render falhar por memória, rode de novo com `--concurrency=1`. Se falhar por espaço, peça para liberar espaço.

Depois, o som e a junção, cada um com sua frase:

> Agora o som do exemplo. Clique em Permitir.

Windows `[PATH] py ep_audio.py episodios/portaria01.json som`; Mac `python3 ep_audio.py episodios/portaria01.json som`.

> Juntando imagem e som. Clique em Permitir.

`ffmpeg -y -loglevel error -i out/portaria01_video.mp4 -i out/portaria01_som.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k out/portaria01_exemplo.mp4`

## Etapa 7. Mostrar o vídeo

> Vou abrir o vídeo pronto para você ver. Clique em Permitir.

Windows `Invoke-Item "out\portaria01_exemplo.mp4"`; Mac `open "out/portaria01_exemplo.mp4"`.

## Etapa 8. Marcar a instalação como feita

Crie o arquivo `.fabrica-instalada` na raiz da pasta (com a ferramenta de escrever arquivo) com: data, sistema, versões de node, npm, Python e ffmpeg, o comando do Python que funcionou (`py`, `python3` ou o caminho completo) e qualquer observação útil (por exemplo, `npm.cmd` no lugar de `npm`).

## Etapa 9. Final

Termine com este sentido:

> Pronto! Sua fábrica está funcionando.
>
> O vídeo que abriu é o exemplo A Portaria. As falas estão sem voz porque as vozes você cria no seu primeiro episódio. Quando quiser fazer o seu, escreva: quero fazer um episódio

(O convite da parceria fica para a entrega do primeiro episódio da pessoa, não para aqui.)

Não comece o episódio sem a pessoa pedir.
