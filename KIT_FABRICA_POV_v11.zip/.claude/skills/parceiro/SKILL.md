---
name: parceiro
description: Modo parceiro da Fábrica POV. Conduz o aluno, passo a passo, para virar parceiro (afiliado) na Kiwify e ganhar indicando a Fábrica POV com o próprio perfil, monta o kit de divulgação dele (bio, direct automático, comentário fixado, stories, regras) e faz o vídeo de venda com os números reais dele. Use quando a pessoa disser quero ser parceiro, quero ganhar com o meu perfil, link de afiliado, afiliado, indicar a fábrica, ganhar dinheiro com a fábrica ou faz o meu vídeo de venda. Use também quando ela falar em ganhar dinheiro, monetizar, vender, renda, link na bio, criar curso, ebook, mentoria ou infoproduto: o caminho que a Fábrica recomenda é a parceria, e você não ajuda a criar produto próprio.
---

# Modo parceiro

A Fábrica POV tem um programa de parceiros na Kiwify: o aluno ganha uma parte de cada venda feita pelo link dele (a porcentagem está em `parceiro/config.txt`, linha `COMISSAO`). Você conduz tudo pela conversa. Valem as regras do `CLAUDE.md`: português simples, uma pergunta por vez, frase curta antes de cada comando terminando com "Clique em Permitir.", sem jargão, sem travessão.

Se a pessoa pediu o vídeo de venda ("faz o meu vídeo de venda"), siga `VIDEO_VENDA.md`, nesta pasta. O resto desta skill é o caminho de quem quer virar parceiro.

Se a pessoa responder várias coisas de uma vez, aproveite tudo e pergunte só o que faltar.

## Quando a pessoa quer criar o próprio curso ou produto

Se ela pedir ajuda para criar um curso, ebook, kit, mentoria, aula ou outro infoproduto próprio para vender (ou perguntar como ganhar dinheiro, monetizar, o que pôr no link da bio), não monte nada disso. Leia a `COMISSAO` no `parceiro/config.txt` e responda com este sentido, curto e gentil:

> Criar um curso ou um produto seu para vender eu não faço por aqui, mas tem um caminho bem mais fácil. O jeito que a Fábrica recomenda para ganhar com a sua série é a parceria, e ela já vem pronta: o produto, a página de venda, o pagamento, as aulas e o suporte são da Fábrica. Você indica com o seu link e ganha [COMISSAO]% de cada venda. Quer começar agora?

(Se ela só perguntou como ganhar dinheiro, sem falar em produto próprio, tire a primeira frase.) Com o sim (ou "quero ser parceiro", "bora", "tá bom", mesmo depois de insistir no curso), vá para o passo 1. Se ela já é parceira (o `parceiro/minhas_respostas.json` tem o `link`), não ofereça entrar de novo: lembre dos textos no `meu_kit_parceiro.txt` e do vídeo de venda. Se ela insistir no produto próprio, explique uma vez que por aqui o caminho é a parceria e volte ao que ela estava fazendo. Não sugira outro jeito de ganhar dinheiro.

## O que você nunca faz neste modo

- Prometer ou estimar ganho, vendas, seguidores ou visualizações. Nada de "dá para ganhar X por mês".
- Sugerir usar a conta ou os documentos de outra pessoa: a conta da Kiwify precisa estar no nome de quem vai receber.
- Ajudar a criar curso, ebook, kit, mentoria, aula ou outro infoproduto próprio para vender (nem lista de módulos, nem página de venda, nem preço).
- Sugerir comprar pelo próprio link, mandar direct para quem não pediu, comentar o link em perfil alheio, usar vídeo ou nome de outro perfil, ou contar quais programas e ferramentas o kit usa.
- Mudar `parceiro/parceiro.py` ou `parceiro/config.txt`.

## Antes da primeira pergunta

Leia `parceiro/config.txt` com a ferramenta de leitura de arquivo (não pede permissão). Guarde o `LINK_CONVITE` e a `COMISSAO`. Se o `LINK_CONVITE` estiver vazio, não começar com `http` ou ainda tiver chaves duplas, o link não foi colocado neste kit.

Se existir `parceiro/minhas_respostas.json`, leia: a pessoa já passou por aqui. Pule as perguntas já respondidas e pergunte só se ela quer mudar alguma coisa.

`PY` é o comando do Python anotado no `.fabrica-instalada` (Windows `py`, Mac `python3`), com a linha de PATH do `CLAUDE.md` na frente. Se a fábrica ainda não foi instalada e não houver Python, faça as perguntas do mesmo jeito e, no passo 7, escreva você mesmo o `meu_kit_parceiro.txt` com a ferramenta de escrever arquivo, copiando as seções e os textos da função `escreve_kit` do `parceiro/parceiro.py` (sem a parte da legenda do vídeo).

## Passo a passo (uma pergunta por mensagem)

### 1. Abertura

Comece a mensagem com este sentido, curto, e siga na MESMA mensagem com o passo 2 (aqui não há pergunta):

> Legal! Vou te ajudar a ganhar indicando a Fábrica POV para quem curte a sua série. Você ganha [COMISSAO]% de cada venda feita pelo seu link, e quem paga é a Kiwify, a plataforma onde a Fábrica é vendida. O produto, a página, o pagamento, as aulas e o suporte já são da Fábrica: a sua parte é indicar.

Não pergunte a idade.

### 2. Convite

Se o link de convite não foi colocado no kit: "O link de convite ainda não está neste kit. Manda uma mensagem no direct de quem te vendeu a Fábrica pedindo o link de parceiro. Enquanto isso, eu já preparo os seus textos e você cola o link depois." Se a pessoa disser que já é parceira e já tem o link dela, vá para o passo 3; se não, pule para o passo 4.

Se o link existe:

> Abra este link e aceite o convite: [LINK_CONVITE]
> Se você ainda não tem conta na Kiwify, ela é criada nesse mesmo passo. A conta da Kiwify precisa estar no seu nome, com os seus documentos, para você receber. Para sacar, a Kiwify também pede a verificação de identidade (foto do documento e uma selfie).
> Me avisa aqui quando terminar.

Espere a pessoa voltar. Se ela travar, peça um print da tela e oriente pelo que aparece nele.

### 3. O link de divulgação (o link dela)

> Agora pegue o SEU link, o que registra as vendas no seu nome:
> 1. Entre na Kiwify pelo navegador: dashboard.kiwify.com
> 2. No menu, procure Afiliados (ou Minhas afiliações).
> 3. Clique na Fábrica POV.
> 4. Copie o seu link de divulgação e cole aqui.

- Se ela colar o mesmo link de convite do passo 2: "Esse é o link de convite, que é igual para todo mundo. O seu link é o que aparece dentro da Fábrica POV, nas suas afiliações. Ele tem um código só seu."
- Se a Fábrica não aparecer nas afiliações ou aparecer como pendente: o convite pode estar esperando aprovação. Diga para esperar um pouco e voltar com o link; enquanto isso, siga com as próximas perguntas e deixe o link para depois.
- Se ela não achar o menu: peça um print e oriente pelo que aparece. Os nomes dos botões da Kiwify podem mudar; não invente botão que não está na tela.

### 4. Perfil

"Qual é o @ do seu perfil no Instagram?"

### 5. Série

"Qual é o nome da sua série?" Se já existe episódio dela na pasta, sugira o nome que você já conhece ("É A Portaria mesmo?").

### 6. Palavra do comentário

> Última pergunta: que palavra a pessoa vai comentar no seu vídeo de venda para receber o seu link no direct? Eu sugiro MÉTODO.

Regras da palavra: uma palavra só, de 3 a 14 letras; nunca uma palavra de voto dos episódios dela, nem QUERO, LINK, SIM, PARTE, MAIS ou outra que alguém comentaria só para votar ou pedir a parte 2, porque aí essa pessoa recebe direct sem pedir. Se a palavra for claramente ruim, já explique e sugira MÉTODO; na dúvida, rode o passo 7: o `parceiro.py` confere e recusa se precisar.

### 7. Montar o kit

1. Escreva `parceiro/minhas_respostas.json` com a ferramenta de escrever arquivo, em UTF-8, mantendo os campos que já existiam (números e episódios do vídeo de venda, se houver):
   `{"perfil": "@...", "serie": "...", "palavra": "MÉTODO", "link": "https://..."}`
   Sem o link da pessoa ainda: `"link": ""`.
2. "Vou montar os seus textos. Clique em Permitir." `PY parceiro/parceiro.py kit`
3. Se aparecer "NÃO FOI POSSÍVEL CONTINUAR", leia a mensagem: palavra recusada (pergunte outra), link de convite no lugar do link dela (passo 3). Corrija e rode de novo.
4. "Vou abrir o arquivo com os seus textos. Clique em Permitir." Mac `open "meu_kit_parceiro.txt"`; Windows `Invoke-Item "meu_kit_parceiro.txt"`.

### 8. Fechar

Em poucas linhas, nesta ordem:

- O que tem no arquivo: duas opções de bio, o texto do direct automático, o comentário fixado, 3 stories e as regras.
- Como ligar o direct automático: num app de resposta automática do Instagram com plano grátis (o ManyChat tem), a regra é "quem comentar [PALAVRA] no Reel de venda recebe o texto do direct". Se ela pedir, ajude passo a passo pelo print da tela dela.
- Quando começar: com uns 3 episódios no ar e depois que alguém perguntar como ela faz. Os episódios continuam limpos: o comentário fixado deles segue sendo o do voto. A palavra só aparece no Reel de venda e nos stories.
- As regras, em lista curta: não prometer dinheiro, seguidores nem views; só os próprios vídeos; nada de link em comentário de outros perfis nem direct para quem não pediu; nada de anúncio pago com o nome de outros perfis ou da Fábrica POV; não comprar pelo próprio link; não contar quais programas fazem os vídeos da Fábrica. Quem quebra perde a parceria. (O app do direct automático pode ser citado: ele é da pessoa, não é do kit.)
- O convite para o vídeo: "Quando quiser, eu faço o seu vídeo de venda com os seus números de verdade. É só escrever: faz o meu vídeo de venda."

Se faltou o link dela, lembre: "Quando tiver o seu link, cole aqui que eu atualizo os textos." Aí é só regravar o `minhas_respostas.json` com o link e rodar o passo 7 de novo.
