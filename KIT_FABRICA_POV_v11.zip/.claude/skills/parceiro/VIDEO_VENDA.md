# Vídeo de venda do parceiro ("faz o meu vídeo de venda")

Um Reel de uns 25 a 30 segundos, 1080x1920, com o personagem e os cenários da série DA PESSOA, os números reais dela e no fim "Comenta [PALAVRA] que eu te mando no direct". O molde é fixo (`src/VendaParceiro.tsx`, composição `MinhaVenda`); você só faz as perguntas, roda os comandos e confere. A pessoa só responde, diz sim antes de gastar crédito do ElevenLabs, clica em Permitir e assiste.

Regras deste vídeo:

- Nunca invente número. Só entra o que a pessoa disse. Se ela não souber, aquele número sai do vídeo. O `parceiro.py` arredonda sempre para baixo (na fala e na tela) e tira seguidores e visualizações abaixo de mil.
- Não mude falas, textos de tela nem o molde. O vídeo não fala de ferramenta, de IA nem de como é feito, e não promete nada para quem assiste.
- Mesmos cuidados dos episódios: uma tarefa pesada por vez, 3 GB livres antes de renderizar, render em segundo plano acompanhando até o fim.

## 1. Conferir antes

- Sem `.fabrica-instalada`: instale antes (`.claude/skills/comecar/SKILL.md`).
- O vídeo precisa de pelo menos um episódio DA PESSOA: uma `<Composition>` em `src/Root.tsx` além de `Ep01`, `Jonas01` e `MinhaVenda`, com o arquivo de configuração em `episodios/`. Se não tiver: "O vídeo de venda usa o personagem e os cenários da sua série. Primeiro vamos fazer um episódio seu: escreva quero fazer um episódio." Não faça o vídeo com os exemplos do kit.
- Leia `parceiro/minhas_respostas.json` se existir (perfil, série, palavra e link já respondidos no modo parceiro). Se não existir, a pessoa ainda não passou pelo modo parceiro: diga em uma linha que o vídeo leva as pessoas para o link de parceiro dela e ofereça fazer o modo parceiro antes (`SKILL.md`, desde o passo 1). Se ela preferir fazer o vídeo primeiro, faça: o perfil, a série e a palavra são perguntados no passo 2 abaixo, e o link entra depois. Não pergunte a idade.
- Se ela tiver menos de 3 episódios no ar, diga uma vez que o vídeo de venda funciona melhor depois de uns 3 episódios e de alguém perguntar como ela faz. Se ela quiser mesmo assim, faça.

## 2. Perguntas (uma por vez; pule o que já foi respondido)

Avise antes: "Vou te fazer 3 perguntas sobre os seus números. Use os números de verdade, do jeito que aparecem no Instagram. Se não souber algum, é só dizer não sei que ele fica de fora do vídeo."

1. "Quantos seguidores você tem hoje?"
2. "Faz quantos dias que você postou o primeiro episódio?"
3. "Quantas visualizações teve o seu vídeo mais visto? Aparece no próprio Reel, embaixo dele no seu perfil."
Se ainda faltar, pergunte também (uma coisa por vez) o @ do perfil, o nome da série e a palavra do comentário (sugira MÉTODO; mesmas regras do modo parceiro).

Aceite o número como a pessoa falar: "12,4 mil", "12400", "1,2 mi". Não corrija para cima e não chute. Se a resposta for aproximada ("uns 40 mil"), peça o número que aparece no Instagram; se ela não achar, aquele número fica de fora. Se ela disser a data do primeiro episódio em vez dos dias, conte os dias até hoje e confirme com ela. Na fala o número sai arredondado para baixo ("três mil e quatrocentos" para 3.420); na tela, do jeito do Instagram.

Episódio: use os episódios dela mais recentes (o `parceiro.py` pega os 2 últimos sozinho). Só pergunte se ela tiver mais de uma série e não der para saber qual vender.

## 3. Montar o roteiro

1. Escreva `parceiro/minhas_respostas.json` (ferramenta de escrever arquivo), mantendo o que já existia:
   `{"perfil": "@...", "serie": "...", "palavra": "MÉTODO", "link": "...", "seguidores": 12400, "dias": 12, "views": 152300, "episodios": []}`
   Número que ela não sabe: `null`. Pode escrever do jeito que ela falou, entre aspas: `"seguidores": "12,4 mil"`. `episodios` vazio = os mais recentes dela; para escolher, use o id da composição (ex.: `["Mercado01"]`).
2. "Vou montar o roteiro do vídeo com os seus números. Clique em Permitir." `PY parceiro/parceiro.py video`
3. Mostre o que o vídeo vai falar (as linhas V01, V02... da saída) e o que ficou de fora, e pergunte: "Posso fazer assim?" Se ela quiser mudar um número, regrave as respostas e rode de novo. O texto das falas não muda.

## 4. Vozes

A voz é a mesma do "você" da série dela (o `parceiro.py` pega do elenco do episódio). Siga `../fabrica-pov/VOZES.md` com `episodios/minha_venda.json`:

1. `PY gerar_vozes.py falas episodios/minha_venda.json` (só confere, não gasta). Se faltar a voz no elenco, crie como no `VOZES.md`.
2. Diga quantas letras e créditos e peça o sim. Com o sim: `PY gerar_vozes.py falas episodios/minha_venda.json --sim`.
3. Recomende ouvir as falas antes do render (pasta `vozes/minha_venda`), como nos episódios.

Se rodar o vídeo de novo com números novos, o `parceiro.py` apaga só as vozes das falas que mudaram; as outras são reaproveitadas e não gastam crédito de novo.

## 5. Som

Um comando por vez, cada um com sua frase:

1. `PY ep_audio.py episodios/minha_venda.json prep`
2. `PY ep_audio.py episodios/minha_venda.json som`
3. `PY ep_audio.py episodios/minha_venda.json mix`

O `prep` mostra o quadro de cada fala; guarde os números para o passo 6.

## 6. Conferir 3 quadros antes do render

`npx remotion still src/index.ts MinhaVenda out/minha_venda_q<N>.png --frame=<N>` no meio da fala 1 (o gancho), no meio da fala do voto e uns 2 segundos depois do início da última fala (o CTA). Abra no máximo esses 3 (ou mande um subagente olhar). Confira: personagem e cenários da série dela aparecendo, números certos, a palavra certa, legenda inteira e legível.

## 7. Render e arquivo final

1. Confira o espaço e renderize em segundo plano: `npx remotion render src/index.ts MinhaVenda out/minha_venda_video.mp4 --concurrency=2` (se travar ou faltar memória, `--concurrency=1`).
2. `PY ep_audio.py episodios/minha_venda.json final`: grava `out/minha_venda_final.mp4` no volume certo (-14 LUFS) e mostra duração e quadros. Se aparecer AVISO, siga a mensagem.
3. Tire 4 quadros do final e confira: `ffmpeg -loglevel error -y -i out/minha_venda_final.mp4 -vf "select=eq(n\,N)" -frames:v 1 -update 1 out/minha_venda_final_q<N>.png`

## 8. Entregar

Abra o vídeo (Mac `open "out/minha_venda_final.mp4"`; Windows `Invoke-Item "out\minha_venda_final.mp4"`) e diga, curto:

- onde está o arquivo e quanto dura;
- a legenda pronta para postar e o comentário fixado estão no `meu_kit_parceiro.txt` (o `parceiro.py video` já colocou a legenda lá);
- postar como Reel, fixar no perfil, fixar o comentário e ligar o direct automático com a palavra;
- dá para refazer quando os números crescerem: é só escrever "faz o meu vídeo de venda" de novo.

Não prometa resultado.
