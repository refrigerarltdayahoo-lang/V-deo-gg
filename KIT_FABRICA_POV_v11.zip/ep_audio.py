# Audio de um episodio a partir de um arquivo de configuracao (episodios/NOME.json).
# Uso no Windows: py ep_audio.py episodios/jonas01.json prep | som | mix | confere | confere-tempos | final | quadros
# Uso no Mac:     python3 ep_audio.py episodios/jonas01.json prep | som | mix | confere | confere-tempos | final | quadros
#   prep:    trata as vozes, mede e grava os tempos extras (TS + out/NOME_warp.json) e mostra o quadro de cada fala
#   som:     sintetiza a cama e os efeitos (Python puro) em out/NOME_som.wav
#   mix:     junta vozes e som em out/NOME_audio.wav
#   confere: mede o contraste de cada efeito contra os 0,7 s anteriores e avisa se ele cai embaixo de fala
#   final:   junta o video mudo com o mix, ajusta o volume para -14 LUFS e pico de -1,5 dBTP e grava out/NOME_final.mp4
#   quadros: mostra o quadro real de inicio e fim de cada fala e de cada pausa (e de tempos do roteiro passados depois do comando)
#   confere-tempos: compara os tempos do TSX do episodio (FALAS, PAUSAS, BASE, voto) com o arquivo de configuracao
# O "som" funciona sem as vozes: ele usa os tempos ja gravados no arquivo TS do episodio.
# "prep" e "mix" precisam dos arquivos de voz (MP3) na pasta indicada em "voz_dir".
# So usa a biblioteca padrao do Python 3. Todos os comandos, menos "som", "quadros" e "confere-tempos", chamam o ffmpeg
# e o ffprobe. O "som" tambem chama o ffmpeg quando o episodio usa um arquivo de som proprio.
# Funciona no Windows e no Mac: caminhos montados com os.path (nunca com "/" fixo), ffmpeg e ffprobe achados com
# shutil.which e chamados com lista de argumentos (sem shell, entao caminho com espaco ou acento passa inteiro),
# texto lido e gravado em UTF-8 e saida do terminal em UTF-8.
import json, math, os, random, re, shutil, struct, subprocess, sys, wave
from array import array

# O terminal do Windows costuma usar cp1252 ou cp850, que nao tem emoji nem todos os simbolos, e quem le a saida por
# outro programa (o Claude Code, por exemplo) espera UTF-8. Grava a saida sempre em UTF-8 e troca o que nao couber.
for _fluxo in (sys.stdout, sys.stderr):
    try:
        _fluxo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

NO_WINDOWS = os.name == "nt"
# Nome do Python nos comandos sugeridos pelas mensagens: "py" no Windows (ou "python", se o py nao existir) e
# "python3" no Mac.
PY = ("py" if shutil.which("py") else "python") if NO_WINDOWS else "python3"
USO = f"Uso: {PY} ep_audio.py episodios/NOME.json prep | som | mix | confere | confere-tempos | final | quadros"
COMANDOS = ("prep", "som", "mix", "confere", "confere-tempos", "final", "quadros")


def para(msg):
    print("\nNÃO FOI POSSÍVEL CONTINUAR\n" + msg + "\n")
    sys.exit(1)


def aspas(arg):
    # Caminho com espaco vai entre aspas no comando sugerido, para funcionar quando colado no terminal.
    arg = str(arg)
    return f'"{arg}"' if (" " in arg or not arg) else arg


def dica_ffmpeg():
    if NO_WINDOWS:
        return "no Windows: winget install Gyan.FFmpeg"
    if sys.platform == "darwin":
        return "no Mac: brew install ffmpeg"
    return "pelo instalador de programas do seu sistema"


def le_texto(caminho):
    # Le texto em UTF-8. "utf-8-sig" aceita tambem o arquivo salvo com BOM, como alguns editores do Windows fazem.
    try:
        with open(caminho, encoding="utf-8-sig") as f:
            return f.read()
    except UnicodeDecodeError:
        para(f"O arquivo {caminho} não está em UTF-8.\nAbra no editor, salve com a codificação UTF-8 e rode de novo.")


def le_json(caminho):
    try:
        return json.loads(le_texto(caminho))
    except json.JSONDecodeError as e:
        para(f"O arquivo {caminho} tem um erro de formato na linha {e.lineno}, coluna {e.colno}: {e.msg}.\n"
             "Confira vírgulas, aspas e colchetes perto desse ponto.")


def rel(*partes):
    # Caminho relativo a pasta do kit, so para mostrar nas mensagens, com o separador do sistema.
    return os.path.join(*partes)


if len(sys.argv) < 3 or sys.argv[2] not in COMANDOS:
    para(USO)
if not os.path.isfile(sys.argv[1]):
    para(f"Arquivo de configuração não encontrado: {sys.argv[1]}\nRode o comando de dentro da pasta do kit.\n" + USO)

FAB = os.path.dirname(os.path.abspath(__file__))


def kit(*partes):
    # Caminho dentro da pasta do kit, com o separador do sistema ("\" no Windows, "/" no Mac).
    return os.path.normpath(os.path.join(FAB, *partes))


CMD = f"{PY} ep_audio.py {aspas(sys.argv[1])}"  # comeco dos comandos sugeridos nas mensagens
CFG = le_json(sys.argv[1])
NOME = CFG["nome"]
VOZ_DIR = os.path.normpath(CFG["voz_dir"]) if os.path.isabs(CFG["voz_dir"]) else kit(CFG["voz_dir"])
OUT = kit("out")
VOZ_OUT = os.path.join(OUT, f"voz_{NOME}")
WARP = os.path.join(OUT, f"{NOME}_warp.json")
FPS = 30
SLOTS = [tuple(x) for x in CFG["slots"]]
PRE = CFG.get("pre", 0)
ALVO_LUFS = -14.0   # volume final
ALVO_VOZ = -16.0    # volume de cada fala quando "nivelar_falas" e true
TETO_DBTP = -1.5    # pico real maximo do arquivo final

# Duracao de cada efeito, em segundos ("zumbido" e "batidas" usam o quarto valor do evento).
EV_DUR = {"trovao": 3.03, "onda": 2.6, "splash": 0.7, "batida": 0.2, "tique": 0.05, "impacto": 1.6,
          "toque": 0.45, "clique": 0.05, "plim": 0.32, "chiado": 0.16, "sino": 0.9, "zumbido": 0.8, "batidas": 0.0, "arquivo": 0.0}


SR_SOM = 32000
_SONS = {}
_PROGRAMAS = {}


def programa(nome):
    # Caminho completo do ffmpeg ou do ffprobe (no Windows, o .exe), achado no PATH.
    if nome not in _PROGRAMAS:
        caminho = shutil.which(nome)
        if caminho is None:
            para(f"Programa não encontrado: {nome}.\nInstale o ffmpeg ({dica_ffmpeg()}), feche e abra o terminal e rode de novo.")
        _PROGRAMAS[nome] = caminho
    return _PROGRAMAS[nome]


def roda(args, texto=False):
    # Roda o ffmpeg ou o ffprobe sem shell, com a lista de argumentos. Com texto=True, a saida vem como texto UTF-8
    # (o padrao do Windows, cp1252, quebra com alguns caracteres de nome de arquivo).
    cmd = [programa(args[0])] + [str(a) for a in args[1:]]
    if texto:
        return subprocess.run(cmd, capture_output=True, encoding="utf-8", errors="replace")
    return subprocess.run(cmd, capture_output=True)


def sem_acesso(caminho):
    para(f"Não consegui gravar {caminho}.\n"
         "Se esse arquivo estiver aberto em outro programa (um player de vídeo ou de áudio, por exemplo), feche e rode de novo.")


def troca(tmp, destino):
    # Poe o arquivo temporario no lugar do definitivo. No Windows isso falha se o definitivo estiver aberto em um player.
    try:
        os.replace(tmp, destino)
    except PermissionError:
        if os.path.isfile(tmp):
            os.remove(tmp)
        sem_acesso(destino)


def roda_ou_para(args, o_que):
    # Roda o ffmpeg e, se ele falhar, para com a mensagem de erro dele em vez de um traceback do Python.
    r = roda(args, texto=True)
    if r.returncode != 0:
        para(f"O ffmpeg não conseguiu {o_que}:\n" + (r.stderr or "").strip()[-600:])
    return r


def som_do_arquivo(caminho):
    # Som proprio do usuario (WAV, MP3 ou outro formato que o ffmpeg leia), em mono, com o pico em 1.
    if caminho not in _SONS:
        arq = os.path.normpath(caminho) if os.path.isabs(caminho) else kit(caminho)
        if not os.path.isfile(arq):
            para(f"Arquivo de som não encontrado: {arq}\nConfira o caminho no arquivo de configuração. Ele é relativo à pasta do kit.")
        if shutil.which("ffmpeg") is None:
            para(f"Para usar um arquivo de som próprio é preciso o ffmpeg ({dica_ffmpeg()}).")
        r = roda(["ffmpeg", "-loglevel", "error", "-i", arq, "-map", "0:a:0", "-ac", "1", "-ar", str(SR_SOM), "-f", "s16le", "-"])
        a = array("h")
        a.frombytes(r.stdout[:len(r.stdout) // 2 * 2])
        if sys.byteorder == "big":
            a.byteswap()
        pico = max((abs(x) for x in a), default=0)
        if r.returncode != 0 or pico == 0:
            para(f"Não consegui ler o som de {arq}. O arquivo tem áudio?")
        _SONS[caminho] = array("d", (x / pico for x in a))
    return _SONS[caminho]


def dur_evento(ev):
    if ev[0] == "arquivo":
        return len(som_do_arquivo(ev[3])) / SR_SOM
    if ev[0] == "zumbido" and len(ev) > 3:
        return float(ev[3])
    if ev[0] == "batidas":
        return max(0.0, float(ev[3]) - float(ev[1])) if len(ev) > 3 else 0.0
    return EV_DUR.get(ev[0], 0.0)


CLASSES = ("historia", "ambiente")


def eventos_validos(com_classe=False):
    # Cada evento: [tipo, instante, volume] (mais o quarto valor de "zumbido", "batidas" e "arquivo").
    # No fim pode vir "historia" ou "ambiente". Sem essa marca, o evento conta como "historia".
    evs = []
    for bruto in CFG.get("eventos", []):
        classe = bruto[-1] if isinstance(bruto[-1], str) and bruto[-1] in CLASSES else "historia"
        ev = [x for x in bruto if not (isinstance(x, str) and x in CLASSES)]
        if com_classe:
            ev = ev + [classe]
        if ev[0] not in EV_DUR:
            print(f"AVISO: tipo de evento desconhecido, ignorado: {ev[0]} (tipos: {', '.join(sorted(EV_DUR))})")
        elif ev[0] == "arquivo" and not (len(ev) > 3 and isinstance(ev[3], str)):
            print("AVISO: o evento \"arquivo\" precisa do caminho do som como quarto valor. Ignorado.")
        elif ev[0] == "batidas" and not (len(ev) > 3 and isinstance(ev[3], (int, float))):
            print("AVISO: o evento \"batidas\" precisa do quarto valor (instante final). Ignorado.")
        else:
            evs.append(ev)
    return evs


def precisa_ffmpeg():
    falta = [x for x in ("ffmpeg", "ffprobe") if shutil.which(x) is None]
    if falta:
        para("Programa não encontrado: " + " e ".join(falta) + f".\nInstale o ffmpeg ({dica_ffmpeg()}), feche e abra o terminal e rode de novo.")


def dur(p):
    r = roda(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], texto=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        para(f"Não consegui medir a duração de {p}. O arquivo tem áudio?")


def nivela_voz(arq, alvo):
    # Opcao "nivelar_falas": leva a fala ja tratada ao volume pedido (LUFS). Fala curta, sussurrada ou com efeito
    # costuma sair do passo anterior mais baixa que as outras. Para subir, usa ganho e um limitador que segura
    # os picos em -2 dB; para descer, so ganho. A duracao nao muda.
    for _ in range(3):
        I = mede(arq)[0]
        if I < -45 or abs(alvo - I) <= 0.5:
            return
        ganho = max(-12.0, min(9.0, alvo - I))
        filtro = f"volume={ganho:.2f}dB" + (",alimiter=limit=0.7943:level=false:attack=3:release=50" if ganho > 0 else "")
        tmp = arq + ".tmp.wav"
        roda_ou_para(["ffmpeg", "-loglevel", "error", "-y", "-i", arq, "-af", filtro, "-ar", "48000", "-ac", "1", tmp], f"ajustar o volume de {arq}")
        troca(tmp, arq)


def alvo_da_fala(i):
    # Volume pedido para a fala i (posicao em "slots", comecando em 1), ou None para nao nivelar.
    geral = CFG.get("nivelar_falas")
    geral = ALVO_VOZ if geral is True else geral
    alvo = CFG.get("nivel_por_fala", {}).get(str(i), geral)
    return float(alvo) if isinstance(alvo, (int, float)) and not isinstance(alvo, bool) else None


def prep():
    precisa_ffmpeg()
    esperados = [f"{CFG['prefixo']}{n:02d}.mp3" for n in CFG["arq"][:len(SLOTS)]]
    if len(esperados) < len(SLOTS):
        para(f"A configuração tem {len(SLOTS)} falas em \"slots\" e só {len(esperados)} arquivos em \"arq\". Os dois precisam ter o mesmo tamanho.")
    faltam = [a for a in esperados if not os.path.isfile(os.path.join(VOZ_DIR, a))]
    if faltam:
        para(f"Faltam {len(faltam)} de {len(esperados)} arquivos de voz na pasta:\n  {VOZ_DIR}\n"
             "Arquivos que faltam: " + ", ".join(faltam) + "\n"
             "O kit não traz as vozes. Gere uma voz por fala com o roteiro da pasta ROTEIROS e a receita do manual,\n"
             "salve em MP3 com esses nomes, na ordem das falas, e rode o prep de novo.\n"
             f"Sem as vozes você ainda pode gerar a cama e os efeitos: {CMD} som")
    os.makedirs(VOZ_OUT, exist_ok=True)
    limpa = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,areverse,"
             "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse,"
             f"atempo={CFG.get('atempo', 1.08)}")
    nivel = ",loudnorm=I=-16:TP=-2:LRA=7"
    fxs = {"interfone": ",highpass=f=450,lowpass=f=3100,acompressor=threshold=-18dB:ratio=4",
           "vidro": ",highpass=f=120,lowpass=f=3200,aecho=0.8:0.4:28:0.15",
           "porao": ",highpass=f=90,aecho=0.8:0.5:45|70:0.22|0.12"}
    por_fala = {}
    for nome_fx, lista in CFG.get("fx", {}).items():
        for i in lista:
            por_fala[i] = fxs[nome_fx]
    extras, durs = [], []
    for i, (a, b) in enumerate(SLOTS, start=1):
        src = os.path.join(VOZ_DIR, f"{CFG['prefixo']}{CFG['arq'][i - 1]:02d}.mp3")
        dst = os.path.join(VOZ_OUT, f"S{i:02d}.wav")
        fx = por_fala.get(i, ",highpass=f=90")
        roda_ou_para(["ffmpeg", "-loglevel", "error", "-y", "-i", src, "-af", limpa + fx + nivel, "-ar", "48000", "-ac", "1", dst], f"tratar a voz {src}")
        if alvo_da_fala(i) is not None:
            nivela_voz(dst, alvo_da_fala(i))
        d = dur(dst)
        durs.append(round(d, 2))
        ex = max(0.0, d + CFG.get("folga", 0.3) - (b - a))
        extras.append(round(round(ex * FPS) / FPS, 4))
    # newline="\n": o arquivo sai igual no Windows e no Mac.
    with open(kit(CFG["ts_out"]), "w", encoding="utf-8", newline="\n") as f:
        f.write("// Gerado por ep_audio.py: segundos extras que cada fala precisa alem do tempo previsto no roteiro.\n")
        f.write("export const EXTRAS: number[] = " + json.dumps(extras) + ";\n")
    cortes = sorted([[b, e] for (a, b), e in zip(SLOTS, extras)] + CFG.get("saltos", []) + CFG.get("pausas", []))
    with open(WARP, "w", encoding="utf-8", newline="\n") as f:
        json.dump({"cortes": cortes, "pre": PRE, "durs": durs, "slots": [list(x) for x in SLOTS]}, f)
    print("durações das vozes (s):", durs)
    print("episódio:", round(CFG["base"] + PRE + sum(e for b, e in cortes), 2), "s")
    quadros()


def extras_do_ts():
    # Sem o arquivo gerado pelo prep, le os tempos extras direto do arquivo TS do episodio.
    caminho = kit(CFG["ts_out"])
    if not os.path.isfile(caminho):
        para(f"Arquivo de tempos não encontrado: {caminho}\nCrie o arquivo com a linha: export const EXTRAS: number[] = [];")
    m = re.search(r"EXTRAS[^=]*=\s*(\[[^\]]*\])", le_texto(caminho))
    if not m:
        para(f"Não encontrei a lista EXTRAS em {caminho}.")
    extras = json.loads(m.group(1))
    if len(extras) not in (0, len(SLOTS)):
        para(f"{caminho} tem {len(extras)} tempos e a configuração tem {len(SLOTS)} falas. Rode o prep para gravar os tempos de novo.")
    return extras or [0.0] * len(SLOTS)


def carrega():
    if os.path.isfile(WARP):
        w = le_json(WARP)
        C = w["cortes"]
        fixos = sorted([list(x) for x in CFG.get("saltos", []) + CFG.get("pausas", [])])
        bate = sorted(b for b, e in C) == sorted([b for a, b in SLOTS] + [x[0] for x in fixos]) and all(x in C for x in fixos)
        if "slots" in w and [list(x) for x in SLOTS] != w["slots"]:
            bate = False
        if not bate:
            print(f"AVISO: os tempos em {rel('out', NOME + '_warp.json')} foram gravados pelo último prep e NÃO batem mais com {sys.argv[1]}\n"
                  "       (slots, pausas ou saltos mudaram depois). O resultado vai usar tempos velhos.\n"
                  f"       Rode de novo: {CMD} prep")
    else:
        C = sorted([[b, e] for (a, b), e in zip(SLOTS, extras_do_ts())] + CFG.get("saltos", []) + CFG.get("pausas", []))
    return C, (lambda t: t + PRE + sum(e for b, e in C if b <= t))


def som():
    C, W = carrega()
    os.makedirs(OUT, exist_ok=True)
    SR = SR_SOM
    DUR = W(CFG["base"])
    N = int(SR * DUR)
    buf = array("d", bytes(8 * N))
    random.seed(11)
    rnd = random.random

    def add(t0, d, fn):
        i0 = int(W(t0) * SR)
        n = int(d * SR)
        for i in range(n):
            j = i0 + i
            if 0 <= j < N:
                buf[j] += fn(i / SR, i / n)

    def filtrado(vol, k, d, env):  # ruido passa-baixa de 1 polo, com envelope env(x)
        st = [0.0]
        def f(t, x):
            st[0] = st[0] * (1 - k) + (rnd() * 2 - 1) * k
            return vol * env(x) * st[0]
        return f

    cama = CFG.get("cama", {})
    abaf = [(W(a), W(b)) for a, b in cama.get("abafada", [])]
    fim = W(cama.get("final", CFG["base"]))
    if cama.get("tipo") == "tempestade":
        g = v = c = 0.0
        for i in range(N):
            t = i / SR
            r = rnd() * 2 - 1
            g = g * 0.996 + r * 0.004      # grave: mar e vento
            v = v * 0.93 + r * 0.07        # medio: vento
            c = r - v                      # agudo: chuva
            dentro = any(a <= t < b for a, b in abaf)
            rajada = 0.55 + 0.45 * math.sin(2 * math.pi * 0.19 * t) * math.sin(2 * math.pi * 0.07 * t + 1)
            s = g * 9.0 * (0.7 + 0.3 * rajada)
            if dentro:
                s += v * 0.25 * rajada + 0.05 * math.sin(2 * math.pi * (190 + 40 * math.sin(2 * math.pi * 0.7 * t)) * t) * (0.5 + 0.5 * math.sin(2 * math.pi * 0.35 * t))
            else:
                s += v * 1.1 * rajada + c * 0.10
            if t >= fim:
                s *= 0.4
            buf[i] += 0.5 * s
    if cama.get("tipo") == "sala":
        prev = 0.0
        ini2 = W(cama.get("segunda_camada", 1e9))
        s0, s1 = W(cama.get("subida", [1e9, 1e9])[0]), W(cama.get("subida", [1e9, 1e9])[1])
        for i in range(N):
            t = i / SR
            prev = prev * 0.985 + (rnd() * 2 - 1) * 0.015
            cresce = min(1.0, max(0.0, (t - 7) / 60))
            s = prev * 0.9 + (0.05 + 0.1 * cresce) * math.sin(2 * math.pi * 55 * t) * (0.6 + 0.4 * math.sin(2 * math.pi * 0.6 * t))
            s += 0.09 * min(1.0, max(0.0, (t - ini2) / 35)) * math.sin(2 * math.pi * 82.4 * t)
            if s0 < t < s1:
                r = (t - s0) / (s1 - s0)
                s += 0.1 * r * math.sin(2 * math.pi * (110 + 330 * r * r) * t)
            if t >= fim:
                s *= 0.45
            buf[i] += s
    if cama.get("tipo") == "arquivo":
        # Cama a partir de um som do usuario (ambiente de rua, mata, bar). Repete ate cobrir o episodio.
        # O volume e ajustado para um nivel medio parecido com o da cama "sala".
        dados = som_do_arquivo(cama.get("arquivo", ""))
        g_arq = 0.1 / max(1e-6, math.sqrt(sum(x * x for x in dados) / len(dados)))
        n_arq = len(dados)
        for i in range(N):
            buf[i] += dados[i % n_arq] * g_arq * (0.45 if i / SR >= fim else 1.0)
    elif cama.get("tipo") not in (None, "tempestade", "sala"):
        print(f"AVISO: tipo de cama desconhecido: {cama.get('tipo')} (tipos: tempestade, sala, arquivo). O episódio fica sem cama.")
    if cama.get("ganho_db"):
        # Sobe ou desce a cama inteira em relacao aos efeitos (valor negativo abaixa).
        g_cama = 10 ** (float(cama["ganho_db"]) / 20)
        for i in range(N):
            buf[i] *= g_cama
    duck = CFG.get("ducking", False)
    if duck:
        # Rebaixa a cama antes de cada efeito de historia: desce em 0,2 s, fica baixa de 0,8 s antes do efeito
        # ate o fim do ataque dele e volta em 0,4 s. "ducking": true usa 4 dB; um numero troca a quantidade de dB.
        g_duck = 10 ** (-(4.0 if duck is True else float(duck)) / 20)
        env = array("d", [1.0]) * N
        for ev in [e[:-1] for e in eventos_validos(com_classe=True) if e[-1] == "historia"]:
            ini = W(ev[1])
            fim_ev = W(ev[3]) if ev[0] == "batidas" else ini + min(dur_evento(ev), 0.4)
            a0, a1, b1 = ini - 1.0, ini - 0.8, fim_ev + 0.4
            for i in range(max(0, int(a0 * SR)), min(N, int(b1 * SR))):
                t = i / SR
                k = (t - a0) / (a1 - a0) if t < a1 else 1.0 if t <= fim_ev else 1 - (t - fim_ev) / (b1 - fim_ev)
                v = 1 - (1 - g_duck) * k
                if v < env[i]:
                    env[i] = v
        for i in range(N):
            buf[i] *= env[i]
    for ev in eventos_validos():
        tipo, t0, vol = ev[0], ev[1], ev[2]
        if tipo == "arquivo":  # som proprio: volume 1 deixa o pico no nivel de um impacto de volume 1
            dados = som_do_arquivo(ev[3])
            j0 = int(W(t0) * SR)
            for i in range(max(0, -j0), min(len(dados), N - j0)):
                buf[j0 + i] += vol * 0.8 * dados[i]
            continue
        if tipo == "toque":  # interfone ou telefone
            for k in range(2):
                add(t0 + k * 0.25, 0.2, lambda t, x: vol * 0.22 * (1 if math.sin(2 * math.pi * 26 * t) > 0 else 0) * (math.sin(2 * math.pi * 1250 * t) + 0.45 * math.sin(2 * math.pi * 1560 * t)))
        elif tipo == "clique":
            add(t0, 0.03, lambda t, x: vol * 0.35 * math.exp(-90 * t) * (rnd() * 2 - 1))
            add(t0, 0.05, lambda t, x: vol * 0.3 * math.exp(-60 * t) * math.sin(2 * math.pi * 180 * t))
        elif tipo == "plim":  # mensagem no celular
            add(t0, 0.12, lambda t, x: vol * 0.16 * math.exp(-18 * t) * math.sin(2 * math.pi * 1175 * t))
            add(t0 + 0.1, 0.22, lambda t, x: vol * 0.16 * math.exp(-12 * t) * math.sin(2 * math.pi * 1568 * t))
        elif tipo == "chiado":  # troca para o monitor
            add(t0, 0.16, lambda t, x: vol * (0.22 * math.exp(-14 * t) * (rnd() * 2 - 1) + 0.12 * math.sin(2 * math.pi * 60 * t)))
        elif tipo == "zumbido":  # lampada falhando; ev[3] = duracao
            add(t0, ev[3] if len(ev) > 3 else 0.8, lambda t, x: vol * 0.07 * (1 if math.sin(2 * math.pi * 17 * t) > 0 else 0.1) * math.sin(2 * math.pi * 100 * t))
        elif tipo == "sino":  # elevador
            add(t0, 0.9, lambda t, x: vol * (0.2 * math.exp(-4.5 * t) * math.sin(2 * math.pi * 1568 * t) + 0.08 * math.exp(-6 * t) * math.sin(2 * math.pi * 2093 * t)))
        elif tipo == "batidas":  # mao batendo sem parar ate ev[3], em tempo real (acompanha a fala esticada)
            tr, fim_b = W(t0), W(ev[3])
            while tr < fim_b:
                j0 = int(tr * SR)
                for i in range(int(0.18 * SR)):
                    if j0 + i < N:
                        tt = i / SR
                        buf[j0 + i] += vol * math.exp(-22 * tt) * math.sin(2 * math.pi * 92 * tt)
                tr += 0.21
        if tipo in ("toque", "clique", "plim", "chiado", "zumbido", "sino", "batidas"):
            continue
        if tipo == "trovao":
            add(t0, 0.07, lambda t, x: vol * 0.9 * (rnd() * 2 - 1) * (1 - x))
            add(t0 + 0.03, 3.0, filtrado(vol * 7.0, 0.006, 3.0, lambda x: math.exp(-3.2 * x) * (0.6 + 0.4 * math.sin(40 * x))))
        elif tipo == "onda":
            add(t0, 2.6, filtrado(vol * 2.4, 0.05, 2.6, lambda x: math.sin(math.pi * x) ** 1.5))
        elif tipo == "splash":
            add(t0, 0.7, filtrado(vol * 1.6, 0.25, 0.7, lambda x: (1 - x) ** 2))
        elif tipo == "batida":
            add(t0, 0.2, lambda t, x: vol * 0.7 * math.exp(-22 * t) * math.sin(2 * math.pi * 92 * t))
        elif tipo == "tique":
            add(t0, 0.05, lambda t, x: vol * 0.5 * (rnd() * 2 - 1) * (1 - x) ** 2)
        elif tipo == "impacto":
            add(t0, 1.6, lambda t, x: vol * 0.8 * math.exp(-2.6 * t) * math.sin(2 * math.pi * (46 - 10 * t) * t))
    t = cama.get("final", CFG["base"]) + 0.4
    while cama.get("coracao", True) and t < CFG["base"] - 0.2:  # coracao na tela de escolha
        add(t, 0.14, lambda tt, x: 0.5 * math.exp(-26 * tt) * math.sin(2 * math.pi * 58 * tt))
        add(t + 0.2, 0.14, lambda tt, x: 0.35 * math.exp(-26 * tt) * math.sin(2 * math.pi * 52 * tt))
        t += 0.9
    pico = max(1e-6, max(abs(x) for x in buf))
    g2 = 0.89 / pico
    dados_wav = b"".join(struct.pack("<h", int(max(-1, min(1, x * g2)) * 32767)) for x in buf)
    try:
        with wave.open(os.path.join(OUT, f"{NOME}_som.wav"), "wb") as wv:
            wv.setnchannels(1); wv.setsampwidth(2); wv.setframerate(SR)
            wv.writeframes(dados_wav)
    except PermissionError:
        sem_acesso(os.path.join(OUT, f"{NOME}_som.wav"))
    print("som ok", round(DUR, 2), "s")


def mix():
    precisa_ffmpeg()
    som_wav = os.path.join(OUT, f"{NOME}_som.wav")
    if not os.path.isfile(som_wav):
        para(f"Falta o arquivo {rel('out', NOME + '_som.wav')}. Rode antes: {CMD} som")
    faltam = [f"S{i:02d}.wav" for i in range(1, len(SLOTS) + 1) if not os.path.isfile(os.path.join(VOZ_OUT, f"S{i:02d}.wav"))]
    if faltam or not os.path.isfile(WARP):
        para("As vozes ainda não foram preparadas (faltam " + (f"{len(faltam)} arquivos em {rel('out', 'voz_' + NOME)}" if faltam else f"os tempos em {rel('out', NOME + '_warp.json')}") + ").\n"
             f"Coloque os MP3 das falas em {VOZ_DIR}\n"
             f"e rode, nesta ordem: {CMD} prep, depois som, depois mix.")
    C, W = carrega()
    cmd = ["ffmpeg", "-loglevel", "error", "-y", "-i", som_wav]
    partes = [f"[0]volume={CFG.get('volume_cama', 0.42)}[s]"]
    nomes = ["[s]"]
    for i, (a, b) in enumerate(SLOTS, start=1):
        cmd += ["-i", os.path.join(VOZ_OUT, f"S{i:02d}.wav")]
        ini = W(a)
        partes.append(f"[{i}]adelay={int(ini * 1000 + 60)}:all=1[v{i}]")
        nomes.append(f"[v{i}]")
        print(f"S{i:02d} voz entra em {ini + 0.06:.2f}s")
    partes.append("".join(nomes) + f"amix=inputs={len(nomes)}:normalize=0:duration=longest,alimiter=limit=0.95[out]")
    cmd += ["-filter_complex", ";".join(partes), "-map", "[out]", "-ar", "48000", "-ac", "2", os.path.join(OUT, f"{NOME}_audio.wav")]
    roda_ou_para(cmd, "fazer a mixagem")
    print("mix ok")


def falas_reais(C, W):
    # Inicio e fim de cada fala no tempo real do video, em segundos. O fim inclui o tempo extra da voz.
    return [(W(a), W(b)) for a, b in SLOTS]


def quadros():
    C, W = carrega()
    total = W(CFG["base"])
    print(f"\nQuadro real de cada fala (30 quadros por segundo). Episódio: {round(total * FPS)} quadros, {total:.2f} s")
    print("fala  roteiro (s)      quadro início  quadro fim  quadro do meio")
    for i, ((a, b), (ra, rb)) in enumerate(zip(SLOTS, falas_reais(C, W)), start=1):
        qi, qf = round(ra * FPS), round(rb * FPS)
        print(f"{i:>4}  {a:>6.2f} a {b:<6.2f}  {qi:>13}  {qf:>10}  {(qi + qf) // 2:>14}")
    for b, extra in sorted([list(x) for x in CFG.get("pausas", [])]):
        fim_p = W(b)
        print(f"pausa de {extra:.2f} s em {b:.2f} s do roteiro: quadros {round((fim_p - extra) * FPS)} a {round(fim_p * FPS)} (quadro do meio {round((fim_p - extra / 2) * FPS)})")
    for b, extra in sorted([list(x) for x in CFG.get("saltos", [])]):
        print(f"salto de {-extra:.2f} s em {b:.2f} s do roteiro: o trecho até {b - extra:.2f} s não aparece; o vídeo segue no quadro {round(W(b) * FPS)}")
    if "final" in CFG.get("cama", {}):
        print(f"tela de voto (cama.final = {CFG['cama']['final']} s): quadro {round(W(CFG['cama']['final']) * FPS)}")
    for x in sys.argv[3:] if sys.argv[2] == "quadros" else []:
        try:
            t = float(x.replace(",", "."))
        except ValueError:
            continue
        print(f"tempo do roteiro {t:.2f} s: quadro {round(W(t) * FPS)} ({W(t):.2f} s no vídeo)")
    print("Para tirar um quadro: npx remotion still src/index.ts <Id> out/quadro.png --frame=N")


def le_mono(caminho, sr=16000):
    r = roda(["ffmpeg", "-loglevel", "error", "-i", caminho, "-map", "0:a:0", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"])
    if r.returncode != 0 or not r.stdout:
        para(f"Não consegui ler o áudio de {caminho}.")
    a = array("h")
    a.frombytes(r.stdout[:len(r.stdout) // 2 * 2])
    if sys.byteorder == "big":
        a.byteswap()
    return a


def rms_db(a, sr, t0, t1):
    i0, i1 = max(0, int(t0 * sr)), min(len(a), int(t1 * sr))
    if i1 - i0 < sr // 50:
        return None
    return 10 * math.log10(sum(x * x for x in a[i0:i1]) / (i1 - i0) / 32768.0 ** 2 + 1e-12)


def confere():
    precisa_ffmpeg()
    C, W = carrega()
    if len(sys.argv) > 3:
        arq = sys.argv[3]
    elif os.path.isfile(os.path.join(OUT, f"{NOME}_audio.wav")):
        arq = os.path.join(OUT, f"{NOME}_audio.wav")
    else:
        arq = os.path.join(OUT, f"{NOME}_som.wav")
    if not os.path.isfile(arq):
        para(f"Arquivo de áudio não encontrado: {arq}\nRode antes: {CMD} som")
    SR = 16000
    a = le_mono(arq, SR)
    # Sem as vozes medidas, o fim de cada fala e estimado pelo espaco dela no roteiro menos a folga.
    # A voz entra 0,06 s depois do inicio do espaco, como no mix.
    falas = [(ra + 0.06, max(ra + 0.06, rb - CFG.get("folga", 0.3))) for ra, rb in falas_reais(C, W)]
    if os.path.isfile(WARP) and "durs" in le_json(WARP):
        durs = le_json(WARP)["durs"]
        falas = [(ra + 0.06, ra + 0.06 + d) for (ra, rb), d in zip(falas, durs)]
    com_voz = "_som." not in os.path.basename(arq)
    print(f"\nArquivo medido: {arq} ({'com vozes' if com_voz else 'só cama e efeitos, sem vozes'})")
    print("Contraste = nível médio do ataque do efeito (até 0,4 s) menos o nível médio dos 0,7 s anteriores.")
    print("Em repetição do mesmo efeito (toque-toque, batida-batida), a referência são os 0,7 s antes do primeiro.")
    print("Meta dos efeitos de história: 12 dB para impacto e trovao, 9 dB para os demais.\n")
    todos = [(n, e[:-1], e[-1]) for n, e in enumerate(eventos_validos(com_classe=True), start=1)]
    # Repeticao: mesmo tipo de efeito ate 0,75 s depois do anterior (toque-toque, batida-batida). A referencia de
    # uma repeticao sao os 0,7 s antes do PRIMEIRO da sequencia, para o proprio efeito anterior nao contar como fundo.
    primeiro = {}
    for tipo in set(ev[0] for _, ev, _ in todos):
        ant = None
        for n, ev, _ in sorted([x for x in todos if x[1][0] == tipo], key=lambda x: x[1][1]):
            ini = W(ev[1])
            primeiro[n] = primeiro[ant[0]] if ant and ini - ant[1] <= 0.75 else (n, ini)
            ant = (n, ini)
    baixos = sobre = n_hist = 0
    for grupo, titulo in (("historia", "EFEITOS DE HISTÓRIA (têm meta de contraste)"), ("ambiente", "EFEITOS DE AMBIENTE (sem meta; só para conferência)")):
        lista = [(n, ev) for n, ev, c in todos if c == grupo]
        if not lista:
            continue
        print(titulo)
        print(" #  tipo      roteiro  real     quadro  contraste  meta   situação")
        for n, ev in lista:
            ini = W(ev[1])
            d = (W(ev[3]) - ini) if ev[0] == "batidas" else dur_evento(ev)
            atq = min(d, 0.4)
            meta = 12 if ev[0] in ("impacto", "trovao") else 9
            ref = primeiro[n][1]
            nivel, antes = rms_db(a, SR, ini, ini + atq), rms_db(a, SR, max(0.0, ref - 0.7), ref)
            notas = [f"repetição do efeito {primeiro[n][0]}"] if primeiro[n][0] != n else []
            if nivel is None or antes is None:
                txt = "   sem ref."
            else:
                c = round(nivel - antes, 1)  # compara o mesmo valor que imprime
                txt = f"{c:>8.1f} dB"
                if grupo == "historia" and c < meta:
                    baixos += 1
                    notas.append("CONTRASTE BAIXO")
            na_fala = [i for i, (fa, fb) in enumerate(falas, start=1) if min(fb, ini + atq) - max(fa, ini) > 0.03]
            na_cauda = [i for i, (fa, fb) in enumerate(falas, start=1) if i not in na_fala and min(fb, ini + d) - max(fa, ini + atq) > 0.03]
            if na_fala:
                if grupo == "historia":
                    sobre += 1
                    notas.append("ATAQUE EMBAIXO DA FALA " + ", ".join(map(str, na_fala)))
                else:
                    notas.append("ataque sobre a fala " + ", ".join(map(str, na_fala)))
            if na_cauda:
                notas.append("cauda sobre a fala " + ", ".join(map(str, na_cauda)))
            n_hist += grupo == "historia"
            m = f"{meta:>2} dB" if grupo == "historia" else "  -  "
            print(f"{n:>2}  {ev[0]:<9} {ev[1]:>6.2f}s  {ini:>6.2f}s  {round(ini * FPS):>6}  {txt}  {m}  {'; '.join(notas) or 'ok'}")
        print()
    print(f"História: {n_hist} efeito(s), {n_hist - baixos} na meta, {baixos} abaixo da meta, {sobre} com o ataque embaixo de fala.")
    if baixos or sobre:
        print("Para corrigir: mude o instante do evento para um intervalo entre falas (se ele não estiver preso à imagem),\n"
              "suba o volume dele em \"eventos\", ligue \"ducking\": true, baixe a cama com \"ganho_db\" ou marque o evento\n"
              "como \"ambiente\" se ele não carrega a história. Depois rode som, mix e confere de novo.")

def sem_textos(txt):
    # Tira textos entre aspas e comentarios do TSX, para ler so os numeros.
    txt = re.sub(r'"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'|`(?:\\.|[^`\\])*`', '""', txt)
    return re.sub(r"//[^\n]*|/\*.*?\*/", "", txt, flags=re.S)


def bloco_tsx(txt, nome):
    # Conteudo da lista "const NOME ... = [ ... ]", ou None se nao existir.
    m = re.search(r"\bconst\s+" + nome + r"\b[^=]*=\s*\[", txt)
    if not m:
        return None
    i, nivel = m.end(), 1
    while i < len(txt) and nivel:
        nivel += {"[": 1, "]": -1}.get(txt[i], 0)
        i += 1
    return txt[m.end():i - 1] if nivel == 0 else None


NUM = r"(-?\d+(?:\.\d+)?)"


def confere_tempos():
    # Compara os tempos escritos no TSX do episodio (FALAS, PAUSAS, SALTOS, BASE, PRE, voto) com o arquivo de configuracao.
    mod = os.path.splitext(os.path.basename(CFG["ts_out"]))[0]
    pasta = kit(os.path.dirname(CFG["ts_out"]))
    achados = []
    for f in sorted(os.listdir(pasta)) if os.path.isdir(pasta) else []:
        if f.endswith(".tsx"):
            t = le_texto(os.path.join(pasta, f))
            if re.search(r"from\s+[\"']\./" + re.escape(mod) + r"[\"']", t):
                achados.append((f, t))
    if len(achados) != 1:
        para(f"Não achei um único arquivo .tsx que importe os tempos de {CFG['ts_out']} (achei {len(achados)}).\n"
             "O episódio precisa ter a linha: import { EXTRAS } from \"./" + mod + "\";")
    arq, txt = achados[0][0], sem_textos(achados[0][1])
    print(f"\nComparando {os.path.join(os.path.dirname(os.path.normpath(CFG['ts_out'])), arq)} com {sys.argv[1]}")
    erros, nao_lidos = [], []
    perto = lambda x, y: abs(float(x) - float(y)) < 0.0005

    def lista(nome, padrao, entradas):
        b = bloco_tsx(txt, nome)
        if b is None:
            return []
        itens = re.findall(padrao, b)
        if len(itens) != len(re.findall(entradas, b)):
            nao_lidos.append(nome)
            return None
        return [[float(x), float(y)] for x, y in itens]

    falas = None
    b = bloco_tsx(txt, "FALAS")
    if b is not None:
        chamadas = re.findall(r"\bfala\(\s*" + NUM + r"\s*,\s*" + NUM + r"\s*,", b)
        literais = re.findall(r"\bde:\s*S\(\s*" + NUM + r"\s*\)\s*,\s*ate:\s*S\(\s*" + NUM + r"\s*\)", b)
        if len(chamadas) == len(re.findall(r"\bfala\(", b)) and len(literais) == len(re.findall(r"\bde:", b)) and bool(chamadas) != bool(literais):
            falas = [[float(x), float(y)] for x, y in (chamadas or literais)]
    if falas is None:
        nao_lidos.append("FALAS")
    else:
        slots = [list(x) for x in SLOTS]
        if len(falas) != len(slots):
            erros.append(f"FALAS tem {len(falas)} falas e \"slots\" tem {len(slots)}.")
        for i, (f, sl) in enumerate(zip(falas, slots), start=1):
            if not (perto(f[0], sl[0]) and perto(f[1], sl[1])):
                erros.append(f"fala {i}: FALAS diz {f[0]:g} a {f[1]:g} e \"slots\" diz {sl[0]:g} a {sl[1]:g}.")
    for nome_tsx, nome_json in (("PAUSAS", "pausas"), ("SALTOS", "saltos")):
        v = lista(nome_tsx, r"\{\s*b:\s*" + NUM + r"\s*,\s*extra:\s*" + NUM + r"\s*\}", r"\{")
        if v is None:
            continue
        j = sorted([list(map(float, x)) for x in CFG.get(nome_json, [])])
        v = sorted(v)
        if len(v) != len(j) or any(not (perto(a[0], c[0]) and perto(a[1], c[1])) for a, c in zip(v, j)):
            erros.append(f"{nome_tsx} no TSX: {v}; \"{nome_json}\" no json: {j}.")
    for nome_tsx, nome_json, padrao in (("BASE", "base", None), ("PRE", "pre", 0)):
        m = re.search(r"\bconst\s+" + nome_tsx + r"\s*=\s*" + NUM + r"\s*;", txt)
        if m:
            if not perto(m.group(1), CFG.get(nome_json, 0)):
                erros.append(f"{nome_tsx} no TSX é {float(m.group(1)):g} e \"{nome_json}\" no json é {CFG.get(nome_json, 0):g}.")
        elif padrao is None:
            nao_lidos.append(nome_tsx)
        elif not perto(padrao, CFG.get(nome_json, 0)):
            erros.append(f"O TSX não tem {nome_tsx} e \"{nome_json}\" no json é {CFG.get(nome_json, 0):g}.")
    voto = None
    m = re.search(r"<Escolha\b[^>]*?\bq=\{\s*Math\.round\(\s*frame\s*-\s*S\(\s*([A-Za-z_]\w*|" + NUM[1:-1] + r")\s*\)\s*\)\s*\}", txt)
    if m:
        tok = m.group(1)
        m2 = re.search(r"\bconst\s+" + re.escape(tok) + r"\s*=\s*" + NUM + r"\s*;", txt) if re.match(r"[A-Za-z_]", tok) else None
        voto = float(m2.group(1)) if m2 else (float(tok) if re.fullmatch(NUM[1:-1], tok) else None)
    if voto is None:
        nao_lidos.append("instante do voto")
    elif "final" in CFG.get("cama", {}) and not perto(voto, CFG["cama"]["final"]):
        erros.append(f"A tela de voto entra em {voto:g} s no TSX e \"cama.final\" no json é {CFG['cama']['final']:g}.")
    extras = extras_do_ts()
    cortes = [e for e in extras] + [x[1] for x in CFG.get("pausas", []) + CFG.get("saltos", [])]
    dur_s = CFG["base"] + PRE + sum(cortes)
    print(f"Duração pelos tempos gravados em {CFG['ts_out']}: {dur_s:.2f} s, {round(dur_s * FPS)} quadros.")
    if os.path.isfile(WARP):
        C, W = carrega()
        if abs(W(CFG["base"]) - dur_s) > 0.5 / FPS:
            erros.append(f"O último prep dá {W(CFG['base']):.2f} s e os tempos de {CFG['ts_out']} dão {dur_s:.2f} s. Rode o prep de novo.")
    video = os.path.join(OUT, f"{NOME}_video.mp4")
    if os.path.isfile(video) and shutil.which("ffprobe"):
        qv = sonda(video, "v:0", "nb_frames")
        if qv.isdigit() and int(qv) != round(dur_s * FPS):
            erros.append(f"{rel('out', NOME + '_video.mp4')} tem {qv} quadros e os tempos atuais dão {round(dur_s * FPS)}. Renderize de novo.")
        elif qv.isdigit():
            print(f"{rel('out', NOME + '_video.mp4')} tem {qv} quadros: bate.")
    if nao_lidos:
        print("Não consegui ler com segurança no TSX: " + ", ".join(nao_lidos) + ". Esses itens NÃO foram conferidos;\n"
              "confira à mão. O verificador lê o formato dos exemplos: fala(início, fim, ...) com números, { b: ..., extra: ... } e const BASE = número;")
    if erros:
        print("NÃO BATE:")
        for e in erros:
            print("  - " + e)
        print("Corrija o TSX ou o json para os dois dizerem a mesma coisa. Se mudou \"slots\", \"pausas\" ou \"saltos\", rode o prep de novo.")
        sys.exit(1)
    print("Tudo o que foi lido bate." if nao_lidos else "TEMPOS CONFEREM: FALAS e slots, PAUSAS, SALTOS, BASE, PRE e instante do voto batem.")
    if nao_lidos:
        sys.exit(2)


def mede(caminho):
    # Volume integrado (LUFS), faixa dinamica (LU) e pico real (dBTP), medidos pelo filtro ebur128 do ffmpeg.
    r = roda(["ffmpeg", "-hide_banner", "-nostats", "-i", caminho, "-map", "0:a:0", "-af", "ebur128=peak=true", "-f", "null", "-"], texto=True)
    txt = (r.stderr or "").split("Summary:")[-1]
    mi, ml, mp = re.search(r"I:\s*(-?[\d.]+) LUFS", txt), re.search(r"LRA:\s*(-?[\d.]+) LU", txt), re.search(r"Peak:\s*(-?[\d.]+) dBFS", txt)
    if not (mi and mp):
        para(f"Não consegui medir o volume de {caminho}. O arquivo tem áudio?")
    return float(mi.group(1)), float(ml.group(1)) if ml else 0.0, float(mp.group(1))


def sonda(caminho, fluxo, campo):
    r = roda(["ffprobe", "-v", "error", "-select_streams", fluxo, "-show_entries", f"stream={campo}", "-of", "csv=p=0", caminho], texto=True)
    return (r.stdout or "").strip().splitlines()[0].strip(",") if (r.stdout or "").strip() else ""


def final():
    precisa_ffmpeg()
    extras = sys.argv[3:]
    video = extras[0] if len(extras) > 0 else os.path.join(OUT, f"{NOME}_video.mp4")
    audio = extras[1] if len(extras) > 1 else os.path.join(OUT, f"{NOME}_audio.wav")
    saida = extras[2] if len(extras) > 2 else os.path.join(OUT, f"{NOME}_final.mp4")
    if not os.path.isfile(video):
        para(f"Vídeo não encontrado: {video}\nRenderize antes (veja para_curiosos/INSTALACAO_SEM_CLAUDE.md) ou informe o caminho: {CMD} final VIDEO.mp4 AUDIO.wav SAIDA.mp4")
    if not os.path.isfile(audio):
        para(f"Áudio não encontrado: {audio}\nRode antes o prep, o som e o mix. Para juntar só a cama e os efeitos, sem vozes, use o comando de junção simples da seção 5 de para_curiosos/INSTALACAO_SEM_CLAUDE.md.")
    if os.path.abspath(saida) in (os.path.abspath(video), os.path.abspath(audio)):
        para("O arquivo de saída não pode ser o mesmo do vídeo ou do áudio de entrada.")
    I0, LRA0, TP0 = mede(audio)
    print(f"mix de entrada: {I0:.1f} LUFS, pico real {TP0:.1f} dBTP, faixa dinâmica {LRA0:.1f} LU")
    ganho, limite = ALVO_LUFS - I0, TETO_DBTP - 0.5
    tmp = saida + ".tmp.mp4"
    ok = False
    for tentativa in range(1, 9):
        filtro = f"volume={ganho:.2f}dB,alimiter=limit={10 ** (limite / 20):.4f}:level=false:attack=5:release=60"
        r = roda(["ffmpeg", "-loglevel", "error", "-y", "-i", video, "-i", audio, "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
                  "-af", filtro, "-ar", "48000", "-ac", "2", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", tmp], texto=True)
        if r.returncode != 0:
            if os.path.isfile(tmp):
                os.remove(tmp)
            para("O ffmpeg não conseguiu gravar o arquivo final:\n" + (r.stderr or "").strip()[-600:])
        I, LRA, TP = mede(tmp)
        print(f"tentativa {tentativa}: ganho {ganho:+.2f} dB, limitador em {limite:.2f} dB -> {I:.1f} LUFS, pico real {TP:.1f} dBTP")
        if abs(I - ALVO_LUFS) <= 0.2 and TP <= TETO_DBTP:
            ok = True
            break
        if TP > TETO_DBTP:
            limite -= (TP - TETO_DBTP) + 0.1
        ganho += ALVO_LUFS - I
    troca(tmp, saida)
    quadros_v, dur_v, dur_a = sonda(saida, "v:0", "nb_frames"), float(sonda(saida, "v:0", "duration") or 0), float(sonda(saida, "a:0", "duration") or 0)
    seguro = max(0.0, TP0 + ganho - limite)
    print(f"\nARQUIVO FINAL: {saida}")
    print(f"  volume: {I:.1f} LUFS (alvo {ALVO_LUFS:.0f}, faixa aceita -14,5 a -13,5)")
    print(f"  pico real: {TP:.1f} dBTP (teto {TETO_DBTP})")
    print(f"  faixa dinâmica: {LRA:.1f} LU (no mix: {LRA0:.1f} LU)")
    print(f"  vídeo: {quadros_v} quadros, {dur_v:.3f} s")
    print(f"  áudio: {dur_a:.3f} s")
    if abs(dur_v - dur_a) > 1.5 / FPS:
        print(f"AVISO: vídeo e áudio diferem em {abs(dur_v - dur_a):.2f} s. As vozes mudaram depois da renderização?\n"
              "       Rode prep, som e mix, renderize de novo e repita o final.")
    if seguro > 6:
        print(f"AVISO: o limitador está segurando até {seguro:.1f} dB nos picos. A mixagem tem efeitos muito mais fortes que as vozes.\n"
              "       Para um resultado mais limpo, baixe o volume dos eventos mais fortes em \"eventos\" e rode som, mix e final de novo.")
    if not (ok or (-14.5 <= I <= -13.5 and TP <= TETO_DBTP)):
        print("AVISO: não foi possível chegar ao alvo em 8 tentativas. Confira os números acima antes de publicar.")
        sys.exit(2)


{"prep": prep, "som": som, "mix": mix, "confere": confere, "confere-tempos": confere_tempos, "final": final, "quadros": quadros}[sys.argv[2]]()
