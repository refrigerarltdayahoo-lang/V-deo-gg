# Modo parceiro da Fabrica POV: kit de divulgacao e video de venda a partir das respostas da pessoa.
# Uso (sempre de dentro da pasta do kit):
#   Windows: py parceiro/parceiro.py kit | video | link       Mac: python3 parceiro/parceiro.py kit | video | link
#   link:  mostra o link de convite do programa de parceiros (de parceiro/config.txt)
#   kit:   grava meu_kit_parceiro.txt na pasta do kit (bio, direct automatico, comentario fixado, stories, regras)
#   video: prepara o video de venda (composicao MinhaVenda): roteiro com os numeros reais, falas para as vozes,
#          tempos, sons e o arquivo de dados do molde src/VendaParceiro.tsx. Tambem regrava o meu_kit_parceiro.txt
#          com a legenda pronta do video.
# As respostas ficam em parceiro/minhas_respostas.json (quem escreve e o Claude):
#   {"perfil": "@meu.perfil", "serie": "A Portaria", "palavra": "MÉTODO", "link": "https://...",
#    "seguidores": 12400, "dias": 12, "views": 152300, "episodios": ["Ep01"]}
# Numero que a pessoa nao sabe fica null e sai do video. Aceita "12,4 mil" e "1,2 mi" (vale o numero de baixo).
# O video nunca inventa nem arredonda numero para cima: na fala vai o numero arredondado para BAIXO, na tela o
# numero do jeito que o Instagram mostra (tambem para baixo) ou o numero exato.
# So biblioteca padrao do Python 3. Funciona no Windows e no Mac.
import datetime, json, math, os, random, re, struct, sys, wave
from array import array

for _fluxo in (sys.stdout, sys.stderr):
    try:
        _fluxo.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

NO_WINDOWS = os.name == "nt"
PY = "py" if NO_WINDOWS else "python3"
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
USO = f"Uso: {PY} parceiro/parceiro.py link | kit | video"
FPS = 30
MIN_SEGUIDORES = 1000  # abaixo disso o video nao mostra seguidores
MIN_VIEWS = 1000       # abaixo disso o video nao mostra visualizacoes
PALAVRAS_PROIBIDAS = {"QUERO", "LINK", "EU", "SIM", "NAO", "NÃO", "PARTE", "PARTE2", "MAIS", "OI", "EUQUERO", "COMO", "AMEI", "TOP"}


def para(msg):
    print("\nNÃO FOI POSSÍVEL CONTINUAR\n" + msg + "\n")
    sys.exit(1)


def kit(*partes):
    return os.path.normpath(os.path.join(KIT, *partes))


def le_texto(caminho):
    with open(caminho, encoding="utf-8-sig") as f:
        return f.read()


def grava_texto(caminho, txt):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)
    try:
        os.replace(tmp, caminho)
    except PermissionError:
        os.remove(tmp)
        para(f"Não consegui gravar {caminho}. Se ele estiver aberto em outro programa, feche e rode de novo.")


def le_json(caminho):
    try:
        return json.loads(le_texto(caminho))
    except json.JSONDecodeError as e:
        para(f"O arquivo {caminho} tem um erro de formato na linha {e.lineno}, coluna {e.colno}: {e.msg}.")


# ---------------------------------------------------------------- configuracao e respostas

def config():
    cfg = {}
    caminho = kit("parceiro", "config.txt")
    if os.path.isfile(caminho):
        for linha in le_texto(caminho).splitlines():
            linha = linha.strip()
            if linha and not linha.startswith("#") and "=" in linha:
                k, v = linha.split("=", 1)
                cfg[k.strip().upper()] = v.strip()
    convite = cfg.get("LINK_CONVITE", "")
    if "{{" in convite or not convite.lower().startswith("http"):
        convite = ""
    try:
        comissao = int(float(cfg.get("COMISSAO", "60").replace(",", ".")))
    except ValueError:
        comissao = 60
    return convite, comissao


def numero(valor, campo):
    # Devolve (numero inteiro ou None, aproximado?). "12,4 mil" vira 12400 (o Instagram ja arredonda para baixo).
    if valor is None or isinstance(valor, bool):
        return None, False
    if isinstance(valor, (int, float)):
        return (int(valor) if valor >= 0 else None), False
    s = str(valor).strip().lower().replace(" ", " ")
    if s in ("", "?", "nao sei", "não sei", "null", "none", "-"):
        return None, False
    m = re.fullmatch(r"([\d.,]+)\s*(mil|k|mi|m|milhão|milhao|milhões|milhoes)", s)
    if m:
        base = m.group(1).replace(".", "").replace(",", ".")
        try:
            v = float(base)
        except ValueError:
            para(f"Não entendi o número de {campo}: {valor}")
        mult = 1000 if m.group(2) in ("mil", "k") else 1000000
        return int(math.floor(v * mult + 1e-6)), True
    if re.fullmatch(r"\d{1,3}([.\s]\d{3})+|\d+", s):
        return int(re.sub(r"[.\s]", "", s)), False
    para(f"Não entendi o número de {campo}: \"{valor}\". Escreva só o número (12400) ou como o Instagram mostra (12,4 mil).")


def respostas():
    caminho = kit("parceiro", "minhas_respostas.json")
    if not os.path.isfile(caminho):
        para(f"Faltam as respostas em {os.path.join('parceiro', 'minhas_respostas.json')}.\n"
             "Formato: {\"perfil\": \"@meu.perfil\", \"serie\": \"Nome da série\", \"palavra\": \"MÉTODO\", \"link\": \"https://...\"}")
    R = le_json(caminho)
    perfil = str(R.get("perfil") or "").strip().replace(" ", "")
    if perfil and not perfil.startswith("@"):
        perfil = "@" + perfil
    serie = re.sub(r"\s+", " ", str(R.get("serie") or "").strip())
    palavra = re.sub(r"[^\wÀ-ÿ]", "", str(R.get("palavra") or "MÉTODO").strip()).upper() or "MÉTODO"
    link = str(R.get("link") or "").strip()
    seg, seg_aprox = numero(R.get("seguidores"), "seguidores")
    dias, _ = numero(R.get("dias"), "dias")
    views, views_aprox = numero(R.get("views"), "visualizações")
    if dias is not None and dias < 1:
        dias = None
    eps = R.get("episodios") or []
    if isinstance(eps, str):
        eps = [x.strip() for x in eps.split(",") if x.strip()]
    return {"perfil": perfil, "serie": serie, "palavra": palavra, "link": link, "seguidores": seg, "seg_aprox": seg_aprox,
            "dias": dias, "views": views, "views_aprox": views_aprox, "episodios": eps}


def confere_palavra(palavra, votos):
    if not re.fullmatch(r"[A-ZÀ-Ý0-9]{3,14}", palavra):
        para(f"A palavra \"{palavra}\" não serve: use uma palavra só, de 3 a 14 letras, sem espaço. Sugestão: MÉTODO.")
    sem_acento = palavra.translate(str.maketrans("ÁÀÂÃÉÊÍÓÔÕÚÇ", "AAAAEEIOOOUC"))
    if palavra in PALAVRAS_PROIBIDAS or sem_acento in PALAVRAS_PROIBIDAS:
        para(f"A palavra \"{palavra}\" pega comentário de quem só quer a próxima parte ou só está votando.\n"
             "Escolha outra, que só quem quer criar a série vai comentar. Sugestão: MÉTODO.")
    if palavra in votos or sem_acento in votos:
        para(f"\"{palavra}\" é palavra de voto de um episódio seu. Quem votar ia receber o direct sem pedir.\n"
             "Escolha outra. Sugestão: MÉTODO.")


# ---------------------------------------------------------------- numeros por extenso (para a voz)

UNI_M = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
UNI_F = ["", "uma", "duas", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
DEZ_19 = ["dez", "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"]
DEZENAS = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
CENT_M = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos"]
CENT_F = ["", "cento", "duzentas", "trezentas", "quatrocentas", "quinhentas", "seiscentas", "setecentas", "oitocentas", "novecentas"]


def trinca(n, fem=False):
    if n == 100:
        return "cem"
    c, r = divmod(n, 100)
    partes = []
    if c:
        partes.append((CENT_F if fem else CENT_M)[c])
    if r:
        if r < 10:
            partes.append((UNI_F if fem else UNI_M)[r])
        elif r < 20:
            partes.append(DEZ_19[r - 10])
        else:
            d, u = divmod(r, 10)
            partes.append(DEZENAS[d] + (" e " + (UNI_F if fem else UNI_M)[u] if u else ""))
    return " e ".join(partes)


def extenso(n, fem=False):
    if n == 0:
        return "zero"
    mi, resto = divmod(n, 1000000)
    mil, uni = divmod(resto, 1000)
    grupos = []
    if mi:
        grupos.append(("um milhão" if mi == 1 else trinca(mi) + " milhões", mi))
    if mil:
        grupos.append(("mil" if mil == 1 else trinca(mil, fem) + " mil", mil))
    if uni:
        grupos.append((trinca(uni, fem), uni))
    txt = grupos[0][0]
    for palavra, valor in grupos[1:]:
        txt += (" e " if valor < 100 or valor % 100 == 0 else " ") + palavra
    return txt


def falado(n):
    # Numero para a voz, arredondado para BAIXO: ate 999 exato; ate 9.999 nas centenas; ate 999.999 no milhar;
    # de um milhao para cima nas centenas de milhar. Devolve (valor falado, texto, precisa de "de" antes do nome).
    if n < 1000:
        v = n
    elif n < 10000:
        v = n // 100 * 100
    elif n < 1000000:
        v = n // 1000 * 1000
    else:
        v = n // 100000 * 100000
    return v, extenso(v), v >= 1000000 and v % 1000000 == 0


def com_nome(n, nome):
    v, txt, de = falado(n)
    return f"{txt} {'de ' if de else ''}{nome}"


def fmt_int(n):
    return f"{n:,}".replace(",", ".")


def fmt_ig(n):
    # do jeito que o Instagram mostra, sempre para baixo: 9.874 / 12,4 mil / 268 mil / 1,2 mi
    if n < 10000:
        return fmt_int(n)
    if n < 1000000:
        v = math.floor(n / 100) / 10
        return (f"{int(v)}" if v >= 100 or v == int(v) else f"{v:.1f}".replace(".", ",")) + " mil"
    v = math.floor(n / 100000) / 10
    return (f"{int(v)}" if v == int(v) else f"{v:.1f}".replace(".", ",")) + " mi"


def sem_digitos(txt):
    return re.sub(r"\d+", lambda m: extenso(int(m.group(0))), txt)


def dias_txt(d):
    return "dia" if d == 1 else "dias"


# ---------------------------------------------------------------- episodios da pasta

def composicoes():
    root = le_texto(kit("src", "Root.tsx"))
    imports = {}
    for nomes, mod in re.findall(r"import\s*\{([^}]*)\}\s*from\s*\"\./([^\"]+)\"", root):
        for n in nomes.split(","):
            n = n.strip().split(" as ")[-1].strip()
            if n:
                imports[n] = mod
    comps = []
    for tag in re.findall(r"<Composition\b[^>]*>", root, flags=re.S):
        mi, mc = re.search(r"\bid=\"([^\"]+)\"", tag), re.search(r"\bcomponent=\{(\w+)\}", tag)
        if mi and mc and mc.group(1) in imports:
            comps.append({"id": mi.group(1), "comp": mc.group(1), "mod": imports[mc.group(1)]})
    return comps


def config_do_episodio(mod):
    # Acha o episodios/*.json cujo ts_out e importado pelo arquivo do episodio (ex.: ./vozes, ./jonas01_vozes).
    tsx = le_texto(kit("src", mod + ".tsx"))
    importados = set(re.findall(r"from\s*\"\./([^\"]+)\"", tsx))
    pasta = kit("episodios")
    for nome in sorted(os.listdir(pasta)):
        if nome.startswith(".") or not nome.endswith(".json") or nome.endswith("_falas.json") or nome.startswith("minha_venda"):
            continue
        cfg = le_json(os.path.join(pasta, nome))
        ts = os.path.splitext(os.path.basename(str(cfg.get("ts_out", ""))))[0]
        if ts and ts in importados and "slots" in cfg and "base" in cfg:
            return os.path.join(pasta, nome), cfg, tsx
    return None, None, tsx


def tempo_real(cfg):
    # Mesma conta do ep_audio.py: tempo do roteiro -> tempo real do video (com os extras das vozes, pausas e saltos).
    slots = [tuple(x) for x in cfg["slots"]]
    warp = kit("out", f"{cfg['nome']}_warp.json")
    C = None
    pre = cfg.get("pre", 0)
    if os.path.isfile(warp):
        w = le_json(warp)
        if w.get("slots") == [list(x) for x in slots]:
            C, pre = w["cortes"], w.get("pre", pre)
    if C is None:
        extras = []
        ts = kit(cfg["ts_out"])
        if os.path.isfile(ts):
            m = re.search(r"EXTRAS[^=]*=\s*(\[[^\]]*\])", le_texto(ts))
            if m:
                extras = json.loads(m.group(1))
        if len(extras) != len(slots):
            extras = [0.0] * len(slots)
        C = [[b, e] for (a, b), e in zip(slots, extras)] + [list(x) for x in cfg.get("saltos", [])] + [list(x) for x in cfg.get("pausas", [])]
    return lambda t: t + pre + sum(e for b, e in C if b <= t)


def tema_do_episodio(tsx):
    padrao = {"manga": "#274f8f", "mangaS": "#1d3c6e", "pele": "#b97d4c", "peleS": "#96623a", "unha": "#dcae86"}
    chaves = list(padrao)

    def le_cores(bloco):
        cores = {}
        for k in chaves:
            m = re.search(r"\b" + k + r"\s*:\s*\"(#[0-9a-fA-F]{3,8})\"", bloco)
            if m:
                cores[k] = m.group(1)
        return cores if len(cores) == len(chaves) else None

    m = re.search(r"<Maos\b[^>]*?\btema=\{\{([^}]*)\}\}", tsx, flags=re.S)
    if m and le_cores(m.group(1)):
        return le_cores(m.group(1))
    m = re.search(r"<Maos\b[^>]*?\btema=\{(\w+)\}", tsx, flags=re.S)
    nome = m.group(1) if m else "TEMA_PORTEIRO"
    for fonte in (tsx, le_texto(kit("src", "Maos.tsx"))):
        d = re.search(r"\b" + nome + r"\b[^=]*=\s*\{([^}]*)\}", fonte)
        if d and le_cores(d.group(1)):
            return le_cores(d.group(1))
    return padrao


def escolhas_do_episodio(tsx):
    tag = re.search(r"<Escolha\b[^>]*>", tsx, flags=re.S)
    if not tag:
        return None
    a, b = re.search(r"\ba=\"([^\"]+)\"", tag.group(0)), re.search(r"\bb=\"([^\"]+)\"", tag.group(0))
    return [a.group(1), b.group(1)] if a and b else None


def voto_do_episodio(cfg, tsx):
    if "final" in cfg.get("cama", {}):
        return float(cfg["cama"]["final"])
    m = re.search(r"<Escolha\s+q=\{Math\.round\(frame\s*-\s*S\(([\d.]+)\)\)\}", tsx)
    return float(m.group(1)) if m else float(cfg["base"]) - 5


def voz_do_voce(cfg_caminho):
    falas = os.path.splitext(cfg_caminho)[0] + "_falas.json"
    if os.path.isfile(falas):
        elenco = le_json(falas).get("elenco", {})
        for quem, voz in elenco.items():
            if quem.strip().lower() in ("você", "voce", "vc", "eu"):
                return voz
    return "rapaz"


def episodio(comp):
    caminho, cfg, tsx = config_do_episodio(comp["mod"])
    if cfg is None:
        para(f"Não achei o arquivo de configuração do episódio {comp['id']} na pasta episodios.")
    W = tempo_real(cfg)
    total = round(W(cfg["base"]) * FPS)
    slots = [tuple(x) for x in cfg["slots"]]
    voto = voto_do_episodio(cfg, tsx)
    inicios = [a for a, b in slots if a < voto]

    def perto(frac):
        alvo = frac * voto
        return min(inicios, key=lambda a: abs(a - alvo)) if inicios else alvo

    q = lambda t: max(0, min(total - 2, round(t * FPS)))
    grade = [q(W(perto(f)) + 0.4) for f in (0.06, 0.16, 0.26, 0.36, 0.46, 0.56, 0.66, 0.76, 0.86)]
    return {
        "id": comp["id"], "comp": comp["comp"], "mod": comp["mod"], "total": total,
        "inicio": q(W(slots[0][0]) + 0.1), "meio": q(W(perto(0.45))), "outro": q(W(perto(0.72))),
        "voto": q(W(voto) + 0.7), "fundo": q(W(perto(0.3)) + 0.3), "grade": grade,
        "tema": tema_do_episodio(tsx), "escolhas": escolhas_do_episodio(tsx), "voz": voz_do_voce(caminho),
        "votos": [x.upper() for x in (escolhas_do_episodio(tsx) or [])],
    }


def episodios_do_aluno(pedidos):
    comps = composicoes()
    por_id = {c["id"]: c for c in comps}
    if pedidos:
        faltam = [p for p in pedidos if p not in por_id]
        if faltam:
            para("Estes episódios não estão no src/Root.tsx: " + ", ".join(faltam) + "\nEpisódios que existem: " + ", ".join(c["id"] for c in comps))
        escolhidos = [por_id[p] for p in pedidos][:2]
    else:
        proprios = [c for c in comps if c["id"] not in ("Ep01", "Jonas01", "MinhaVenda")]
        if not proprios:
            para("O vídeo de venda usa o personagem e os cenários da SUA série, e ainda não tem episódio seu nesta pasta.\n"
                 "Faça antes um episódio (escreva: quero fazer um episódio) e depois peça o vídeo de venda.")
        escolhidos = proprios[-2:][::-1]
    return [episodio(c) for c in escolhidos]


# ---------------------------------------------------------------- kit do parceiro (texto)

REGRAS = [
    "Não prometa dinheiro, seguidores nem visualizações para ninguém.",
    "Use só os seus próprios vídeos. Nada de vídeo, nome ou personagem de outros perfis.",
    "Não poste o seu link nos comentários de outros perfis e não mande direct para quem não pediu.",
    "Não faça anúncio pago com o nome de outros perfis ou da Fábrica POV.",
    "Não compre pelo seu próprio link.",
    "Não conte quais programas fazem os vídeos da Fábrica. Isso fica para quem compra.",
]


def legenda_do_video(R):
    linhas = []
    s, d = R["seguidores"], R["dias"]
    if d and s is not None and s >= MIN_SEGUIDORES:
        linhas.append(f"Comecei a postar a minha série há {d} {dias_txt(d)}. Hoje são {fmt_ig(s)} seguidores, sem aparecer 😅")
    elif s is not None and s >= MIN_SEGUIDORES:
        linhas.append(f"Hoje são {fmt_ig(s)} seguidores, sem aparecer 😅")
    elif d:
        linhas.append(f"Comecei a postar a minha série há {d} {dias_txt(d)}, sem aparecer 😅")
    else:
        linhas.append("Criei a minha própria série animada, sem aparecer 😅")
    linhas += ["E dá pra você criar a sua série animada assim.", f"Comenta {R['palavra']} que eu te mando no direct 📩", "#pov"]
    return "\n".join(linhas)


def escreve_kit(R, com_video=False):
    convite, comissao = config()
    perfil = R["perfil"] or "@seu.perfil"
    serie = R["serie"] or "a minha série"
    palavra = R["palavra"]
    link = R["link"] or "[cole aqui o seu link de parceiro]"
    bio1 = "Séries em POV toda semana 🎬\nVocê decide o final nos comentários 👇\nQuer criar a sua? Toca no link"
    bio2 = f"{serie}: você decide o final 🎬\nNova parte toda semana\nCrie a sua série 👇"
    if len(bio2) > 150:
        bio2 = "Histórias em POV que você decide 🎬\nNova parte toda semana\nCrie a sua série 👇"
    hoje = datetime.date.today().strftime("%d/%m/%Y")
    L = []
    add = L.append
    add(f"MEU KIT DE PARCEIRO DA FÁBRICA POV ({perfil}, {hoje})")
    add("")
    add(f"Você ganha {comissao}% de cada venda feita pelo seu link. Quem paga é a Kiwify, depois que a venda é confirmada.")
    add("Para sacar: verificação de identidade na Kiwify (documento físico e selfie). O saque é no Pix.")
    add("")
    add("SEU LINK DE PARCEIRO")
    add(link)
    if convite:
        add(f"(link de convite do programa, caso precise entrar de novo: {convite})")
    add("")
    add("1. BIO (troque no Instagram: Editar perfil. O link vai no campo Links, não no texto da bio)")
    add("")
    add("Opção 1:")
    add(bio1)
    add("")
    add("Opção 2:")
    add(bio2)
    add("")
    add(f"2. DIRECT AUTOMÁTICO para quem comentar {palavra}")
    add("")
    add("Oi! Que bom que você curtiu 😄")
    add("Eu aprendi a fazer as minhas séries com a Fábrica POV: um kit com aulas que te leva do zero até postar a sua própria série animada, sem aparecer.")
    add(f"Tá tudo aqui: {link}")
    add("É o meu link de parceiro, você paga o mesmo preço. Qualquer dúvida, me chama aqui 📩")
    add("")
    add("Resposta pública no comentário (o app manda junto): Te mandei no direct 📩")
    add("")
    add("Como ligar: use um app de resposta automática do Instagram que tenha plano grátis (o ManyChat tem).")
    add(f"Crie a regra: quem comentar {palavra} no seu Reel de venda recebe o texto acima no direct.")
    add("Nunca use palavra de voto, \"quero\" ou \"link\" como gatilho: aí quem só votou recebe direct sem pedir.")
    add("")
    add("3. COMENTÁRIO FIXADO (só no Reel de venda)")
    add("")
    add(f"Quer criar a sua série assim? Comenta {palavra} que eu te mando no direct 📩")
    add("")
    add("Os seus episódios continuam como estão: o comentário fixado deles segue sendo o do voto.")
    add(f"A palavra {palavra} só aparece no Reel de venda e nos stories.")
    add("")
    add("4. STORIES (3 telas, no mesmo dia do Reel de venda)")
    add("")
    add("Story 1 (print do seu melhor episódio): Muita gente me perguntou como eu faço a minha série 👀")
    add("Story 2 (com o adesivo de link, usando o seu link de parceiro): Eu aprendi com um kit com aulas, do zero até postar. Tá aqui 👇")
    add(f"Story 3 (enquete): Querem logo a próxima parte de \"{serie}\"? 🔥  Opções: SIM / MUITO")
    add("")
    if com_video:
        add("5. LEGENDA DO SEU REEL DE VENDA")
        add("")
        add(legenda_do_video(R))
        add("")
    n = 6 if com_video else 5
    add(f"{n}. QUANDO E COMO")
    add("")
    add("Comece depois de ter uns 3 episódios no ar e de alguém perguntar como você faz. Primeiro a série, depois a oferta.")
    add("Onde: link na bio, um Reel de venda (peça aqui: faz o meu vídeo de venda), os stories e o direct de quem pediu.")
    add("Quem vende demais perde quem assiste: no máximo um Reel de venda por semana.")
    add("")
    add(f"{n + 1}. REGRAS DO PROGRAMA (quem quebrar perde a parceria)")
    add("")
    for i, r in enumerate(REGRAS, start=1):
        add(f"{i}. {r}")
    add("")
    add("Nunca fale: \"renda extra garantida\", \"ganhe X por mês\", \"vai viralizar\", \"fácil, sem esforço\", o nome dos programas que fazem os vídeos, nome ou vídeo de outro perfil.")
    add("")
    destino = kit("meu_kit_parceiro.txt")
    grava_texto(destino, "\n".join(L))
    return destino, bio1, bio2


def cmd_kit():
    R = respostas()
    if not R["perfil"]:
        para("Falta o @ do perfil nas respostas (campo \"perfil\").")
    if not R["serie"]:
        para("Falta o nome da série nas respostas (campo \"serie\").")
    votos = set()
    for nome in os.listdir(kit("src")):
        if nome.endswith(".tsx") and not nome.startswith("."):
            votos |= {x.upper() for x in (escolhas_do_episodio(le_texto(kit("src", nome))) or [])}
    confere_palavra(R["palavra"], votos)
    convite, _ = config()
    avisos = []
    if not R["link"]:
        avisos.append("Ainda falta o link de parceiro da pessoa: o arquivo saiu com um espaço para colar.")
    elif not R["link"].lower().startswith("http"):
        avisos.append("O link de parceiro não começa com http. Confira se a pessoa copiou o link inteiro.")
    elif convite and R["link"].rstrip("/") == convite.rstrip("/"):
        para("O link colado é o link de CONVITE do programa, não o link de parceiro da pessoa.\n"
             "Ela precisa copiar o link de divulgação que aparece no painel dela da Kiwify, na Fábrica POV.")
    elif "kiwify" not in R["link"].lower():
        avisos.append("O link de parceiro não parece da Kiwify. Confira com a pessoa.")
    com_video = os.path.isfile(kit("episodios", "minha_venda.json"))
    destino, bio1, bio2 = escreve_kit(R, com_video)
    print(f"Kit do parceiro gravado em: {os.path.relpath(destino, KIT)}")
    print(f"Bio 1: {len(bio1)} caracteres. Bio 2: {len(bio2)} caracteres (máximo do Instagram: 150).")
    for a in avisos:
        print("AVISO: " + a)


def cmd_link():
    convite, comissao = config()
    if not convite:
        para("O link de convite ainda não foi colocado neste kit (parceiro/config.txt).\n"
             "Peça o link de parceiro no direct de quem vendeu o kit.")
    print(f"LINK_CONVITE={convite}\nCOMISSAO={comissao}")


# ---------------------------------------------------------------- video de venda

def roteiro(R, tem_votos):
    # Blocos do video, na ordem. Cada um: tipo, variante, fala (com direcao em ingles no comeco), legenda da tela.
    s, d, v = R["seguidores"], R["dias"], R["views"]
    big_s = s is not None and s >= MIN_SEGUIDORES
    big_v = v is not None and v >= MIN_VIEWS
    serie_fala = sem_digitos(R["serie"])
    B = []
    if big_s and d:
        B.append(("gancho", "seg", f"[excited] {com_nome(s, 'seguidores')} em {extenso(d)} {dias_txt(d)}.", f"*{fmt_ig(s)}* seguidores em *{d} {dias_txt(d)}*"))
    elif big_s:
        B.append(("gancho", "seg", f"[excited] Gente, {com_nome(s, 'seguidores')}!", f"*{fmt_ig(s)}* seguidores!"))
    elif big_v:
        B.append(("gancho", "views", f"[excited] {com_nome(v, 'views')} num vídeo só.", f"*{fmt_ig(v) if R['views_aprox'] else fmt_int(v)}* views num vídeo só"))
    elif d:
        B.append(("gancho", "dias", f"[excited] Faz {extenso(d)} {dias_txt(d)} que eu postei o primeiro episódio da minha série.", f"*{d} {dias_txt(d)}* desde o meu primeiro episódio"))
    else:
        B.append(("gancho", "serie", "[excited] Olha a série animada que eu fiz!", "Olha a *série animada* que eu fiz!"))
    if B[0][1] == "views" and d:
        B.append(("origem", "", f"[calm] Eu postei o primeiro episódio há {extenso(d)} {dias_txt(d)}.", f"Postei o primeiro episódio há *{d} {dias_txt(d)}*"))
    B.append(("serie", "", f"[proud] Essa é a minha série: {serie_fala}.", ""))
    if big_v and B[0][1] != "views":
        B.append(("views", "", f"[excited] O meu vídeo mais visto teve {com_nome(v, 'views')}.", f"O meu vídeo mais visto: *{fmt_ig(v) if R['views_aprox'] else fmt_int(v)}* views"))
    B.append(("voto", "", "[playful] E quem decide o final são vocês, nos comentários.", "E quem decide o final são *vocês!*"))
    B.append(("sua", "", "[warm] E dá pra você criar a sua série assim, sem aparecer.", "E dá pra você criar a *sua série* assim, sem aparecer."))
    B.append(("cta", "", f"[excited] Comenta {R['palavra'].capitalize()} que eu te mando no direct.", ""))

    def maiuscula(fala):
        m = re.match(r"^(\s*(?:\[[^\]]*\]\s*)*)(.)", fala)
        return m.group(1) + m.group(2).upper() + fala[m.end():] if m else fala
    return [(tipo, var, maiuscula(fala), leg) for tipo, var, fala, leg in B]


def sem_direcao(txt):
    return re.sub(r"^\s*(\[[^\]]*\]\s*)+", "", txt).strip()


def tempos(B):
    # Tempo de cada fala no roteiro: 14,5 letras por segundo (o prep estica se a voz precisar de mais).
    # Depois da fala da serie o trecho do episodio segue mais um pouco; no fim, o CTA fica na tela 2,8 s.
    t = 0.1
    blocos = []
    for tipo, var, fala, leg in B:
        dur = max(1.7, len(sem_direcao(fala)) / 14.5 + 0.3)
        de, ate = round(t, 2), round(t + dur, 2)
        blocos.append({"tipo": tipo, "var": var, "de": de, "ate": ate, "leg": leg, "fala": fala})
        t = ate + 0.15 + (2.6 if tipo == "serie" else 0.5 if tipo == "voto" else 0.0)
    base = round(blocos[-1]["ate"] + 2.8, 2)
    return blocos, base


def marcas(blocos):
    # Instantes do roteiro usados pelo molde (src/VendaParceiro.tsx) e pelos sons. O molde passa os dois pelo
    # mesmo tempo elastico, entao imagem e som ficam juntos mesmo se a voz esticar.
    for b in blocos:
        de, ate = b["de"], b["ate"]
        m = {}
        if b["tipo"] == "serie":
            m["corte"] = round(ate + 0.25, 2)
        if b["tipo"] == "voto":
            m["baloes"] = [round(de + 0.35 + 0.42 * j, 2) for j in range(6)]
        if b["tipo"] == "sua":
            m["checks"] = [round(de + 0.6 + 0.65 * j, 2) for j in range(3)]
        if b["tipo"] == "cta":
            m["palavra"] = round(de + 0.55, 2)
            m["digita"] = round(de + 1.0, 2)
            m["seta"] = round(de + 1.35, 2)
        b["m"] = m


def eventos(blocos, base, palavra):
    S = lambda nome: f"out/minha_venda_sons/{nome}.wav"
    E = []
    for b in blocos:
        de, ate, m = b["de"], b["ate"], b["m"]
        if b["tipo"] == "gancho":
            E += [["impacto", 0.0, 0.8, "ambiente"], ["batida", 0.0, 0.8, "ambiente"], ["arquivo", 0.0, 0.3, S("vibra"), "ambiente"]]
            if b["var"] in ("seg", "views"):
                E += [["tique", round(0.05 + 0.06 * k, 2), 0.22, "ambiente"] for k in range(19)]
                E += [["plim", round(0.2 + 0.32 * k, 2), 0.45, "ambiente"] for k in range(int((ate - 0.4) / 0.32))]
        elif b["tipo"] == "origem":
            E += [["arquivo", de, 0.7, S("rebobina"), "ambiente"], ["batida", round(de + 0.6, 2), 0.6, "ambiente"]]
        elif b["tipo"] == "serie":
            E += [["arquivo", round(de - 0.05, 2), 0.7, S("whoosh"), "ambiente"], ["impacto", round(de + 0.15, 2), 0.5, "ambiente"],
                  ["arquivo", round(m["corte"] - 0.05, 2), 0.45, S("whoosh"), "ambiente"]]
        elif b["tipo"] == "views":
            E += [["impacto", de, 0.8, "ambiente"], ["batida", de, 0.7, "ambiente"]]
            E += [["tique", round(de + 0.1 + 0.06 * k, 2), 0.25, "ambiente"] for k in range(15)]
        elif b["tipo"] == "voto":
            E += [["plim", de, 0.4, "ambiente"]] + [["arquivo", t, 0.5, S("pop"), "ambiente"] for t in m["baloes"]]
        elif b["tipo"] == "sua":
            E += [["arquivo", de, 0.6, S("whoosh"), "ambiente"]] + [["batida", t, 0.6, "ambiente"] for t in m["checks"]]
        elif b["tipo"] == "cta":
            E += [["arquivo", round(de - 0.1, 2), 0.6, S("whoosh"), "ambiente"], ["impacto", de, 0.6, "ambiente"],
                  ["impacto", m["palavra"], 1.0, "ambiente"], ["batida", m["palavra"], 0.8, "ambiente"]]
            E += [["tique", round(m["digita"] + 0.083 * k, 3), 0.3, "ambiente"] for k in range(len(palavra))]
            E += [["arquivo", round(base - 0.4, 2), 0.3, S("vibra"), "ambiente"]]
    return E


# sons sintetizados (mesma familia dos sons do Reel de venda de referencia)
SR = 32000


def _grava(pasta, nome, buf, pico=0.89):
    p = max(1e-9, max(abs(x) for x in buf))
    g = pico / p
    with wave.open(os.path.join(pasta, nome), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, x * g)) * 32767)) for x in buf))


def _novo(d):
    return array("d", bytes(8 * int(SR * d)))


def _soma(buf, t0, d, fn):
    i0, n = int(t0 * SR), int(d * SR)
    for i in range(n):
        j = i0 + i
        if 0 <= j < len(buf):
            buf[j] += fn(i / SR, i / max(1, n))


def sons(pasta):
    os.makedirs(pasta, exist_ok=True)
    random.seed(7)
    rnd = random.random
    # cama: 4 compassos a 120 batidas por minuto (8 s), que o ep_audio.py repete ate o fim do video
    beat = 0.5
    buf = _novo(8.0)
    for k in range(16):
        for sub in range(2):
            ts = k * beat + sub * beat / 2
            if sub == 0:
                fase = [0.0]

                def kick(t, x, fase=fase):
                    fase[0] += 2 * math.pi * (45 + 75 * math.exp(-t * 28)) / SR
                    return 0.95 * math.exp(-t * 14) * math.sin(fase[0])
                _soma(buf, ts, 0.32, kick)
                if k % 2 == 1:
                    st = [0.0]

                    def clap(t, x, st=st):
                        r = rnd() * 2 - 1
                        st[0] = st[0] * 0.75 + r * 0.25
                        env = sum(math.exp(-(t - a) * 60) for a in (0.0, 0.012, 0.024) if t >= a) / 3 + 0.5 * math.exp(-t * 22)
                        return 0.4 * env * (r - st[0])
                    _soma(buf, ts, 0.22, clap)
            sh = [0.0]

            def hat(t, x, sh=sh, a=0.16 * (0.7 if sub == 0 else 1.0)):
                r = rnd() * 2 - 1
                sh[0] = sh[0] * 0.6 + r * 0.4
                return a * math.exp(-t * 95) * (r - sh[0])
            _soma(buf, ts, 0.06, hat)
    notas = [55.0, 55.0, 43.65, 49.0]
    acordes = [(220.0, 261.63, 329.63), (220.0, 261.63, 329.63), (174.61, 220.0, 261.63), (196.0, 246.94, 293.66)]
    fb, lp = 0.0, 0.0
    for i in range(len(buf)):
        t = i / SR
        bar = int(t / 2.0) % 4
        pos = (t % (beat / 2)) / (beat / 2)
        fb += 2 * math.pi * notas[bar] / SR
        s = math.sin(fb) + 0.35 * math.sin(2 * fb) + 0.15 * math.sin(3 * fb)
        buf[i] += 0.3 * (1 - math.exp(-pos * 9)) * math.exp(-pos * 2.2) * math.tanh(1.6 * s)
        ac = acordes[bar]
        v = sum(math.sin(2 * math.pi * f * t + j) for j, f in enumerate(ac)) / 3 + 0.4 * math.sin(math.pi * ac[0] * t)
        lp = lp * 0.96 + v * 0.04
        buf[i] += 0.5 * lp * (0.75 + 0.25 * math.sin(math.pi * t))
    _grava(pasta, "cama.wav", buf)
    # vibracao do celular
    b = _novo(0.5)
    for i in range(len(b)):
        t = i / SR
        env = min(1, t / 0.02) * (1 if t < 0.42 else max(0, 1 - (t - 0.42) / 0.06))
        sq = 1 if math.sin(2 * math.pi * 168 * t) > 0 else -1
        b[i] = env * (0.5 * sq * (0.6 + 0.4 * math.sin(2 * math.pi * 31 * t)) + 0.25 * (rnd() * 2 - 1))
    lp = 0.0
    for i in range(len(b)):
        lp = lp * 0.7 + b[i] * 0.3
        b[i] = lp
    _grava(pasta, "vibra.wav", b, 0.8)
    # rebobinar
    d = 0.6
    b = _novo(d)
    fase = 0.0
    for i in range(len(b)):
        t = i / SR
        x = t / d
        fase += 2 * math.pi * (900 * (1 - x) ** 2 + 110) * (1 + 0.04 * math.sin(2 * math.pi * 27 * t)) / SR
        b[i] = (0.6 * math.sin(fase) + 0.25 * (rnd() * 2 - 1) * (0.6 + 0.4 * math.sin(2 * math.pi * 33 * t))) * (1 - x) ** 0.6 * min(1, t / 0.02)
    _grava(pasta, "rebobina.wav", b, 0.8)
    # passagem (whoosh)
    b = _novo(0.42)
    lp = 0.0
    for i in range(len(b)):
        x = i / len(b)
        k = 0.02 + 0.45 * math.sin(math.pi * x) ** 2
        lp = lp * (1 - k) + (rnd() * 2 - 1) * k
        b[i] = lp * math.sin(math.pi * x) ** 1.5
    _grava(pasta, "whoosh.wav", b, 0.8)
    # pop do balao
    b = _novo(0.12)
    fase = 0.0
    for i in range(len(b)):
        t = i / SR
        fase += 2 * math.pi * (700 * math.exp(-t * 18) + 220) / SR
        b[i] = math.sin(fase) * math.exp(-t * 30)
    _grava(pasta, "pop.wav", b, 0.7)


def ts_str(s):
    return json.dumps(s, ensure_ascii=False)


def cmd_video():
    R = respostas()
    eps = episodios_do_aluno(R["episodios"])
    votos = set()
    for e in eps:
        votos |= set(e["votos"])
    confere_palavra(R["palavra"], votos)
    if not R["serie"]:
        para("Falta o nome da série nas respostas (campo \"serie\").")
    if not R["perfil"]:
        para("Falta o @ do perfil nas respostas (campo \"perfil\").")
    B = roteiro(R, bool(eps[0]["escolhas"]))
    blocos, base = tempos(B)
    marcas(blocos)

    # 1. dados do molde
    imports = {}
    for e in eps:
        imports.setdefault(e["mod"], set()).add(e["comp"])
    linhas = [
        f"// Gerado por parceiro/parceiro.py em {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}. Não edite à mão: mude",
        "// parceiro/minhas_respostas.json e rode de novo o parceiro.py video.",
        "import { DadosVenda } from \"./venda_tipos\";",
    ]
    for mod, comps in sorted(imports.items()):
        linhas.append(f"import {{ {', '.join(sorted(comps))} }} from \"./{mod}\";")
    linhas.append("")
    linhas.append("export const DADOS: DadosVenda = {")
    linhas.append(f"  perfil: {ts_str(R['perfil'])},")
    linhas.append(f"  serie: {ts_str(R['serie'])},")
    linhas.append(f"  palavra: {ts_str(R['palavra'])},")
    s, v = R["seguidores"], R["views"]
    linhas.append(f"  seguidores: {s if s is not None and s >= MIN_SEGUIDORES else 'null'},")
    linhas.append(f"  segAprox: {'true' if R['seg_aprox'] else 'false'},")
    linhas.append(f"  dias: {R['dias'] if R['dias'] else 'null'},")
    linhas.append(f"  views: {v if v is not None and v >= MIN_VIEWS else 'null'},")
    linhas.append(f"  viewsAprox: {'true' if R['views_aprox'] else 'false'},")
    linhas.append(f"  tema: {json.dumps(eps[0]['tema'])},")
    linhas.append(f"  escolhas: {ts_str(eps[0]['escolhas']) if eps[0]['escolhas'] else 'null'},")
    linhas.append("  eps: [")
    for e in eps:
        linhas.append(f"    {{ C: {e['comp']}, total: {e['total']}, inicio: {e['inicio']}, meio: {e['meio']}, outro: {e['outro']}, voto: {e['voto']}, fundo: {e['fundo']}, grade: {json.dumps(e['grade'])} }},")
    linhas.append("  ],")
    linhas.append("  blocos: [")
    for b in blocos:
        linhas.append(f"    {{ tipo: {ts_str(b['tipo'])}, var: {ts_str(b['var'])}, de: {b['de']}, ate: {b['ate']}, leg: {ts_str(b['leg'])}, m: {json.dumps(b['m'])} }},")
    linhas.append("  ],")
    linhas.append(f"  base: {base},")
    linhas.append("};")
    grava_texto(kit("src", "minha_venda_dados.tsx"), "\n".join(linhas) + "\n")
    # tempos antigos de voz nao valem mais: o prep grava de novo
    grava_texto(kit("src", "minha_venda_vozes.ts"), "// Gerado por ep_audio.py: segundos extras que cada fala precisa alem do tempo previsto no roteiro.\nexport const EXTRAS: number[] = [];\n")
    for velho in (kit("out", "minha_venda_warp.json"),):
        if os.path.isfile(velho):
            os.remove(velho)

    # 2. falas para as vozes (a mesma voz do "você" da serie). Fala que mudou perde o MP3 antigo.
    falas_cam = kit("episodios", "minha_venda_falas.json")
    antigas = {}
    if os.path.isfile(falas_cam):
        antigas = {f["arquivo"]: f["texto"] for f in le_json(falas_cam).get("falas", [])}
    falas = [{"arquivo": f"V{i:02d}", "quem": "Você", "texto": b["fala"]} for i, b in enumerate(blocos, start=1)]
    refazer = []
    for f in falas:
        mp3 = kit("vozes", "minha_venda", f["arquivo"] + ".mp3")
        if os.path.isfile(mp3) and antigas.get(f["arquivo"]) != f["texto"]:
            os.remove(mp3)
            refazer.append(f["arquivo"])
    for velho in range(len(falas) + 1, 13):
        mp3 = kit("vozes", "minha_venda", f"V{velho:02d}.mp3")
        if os.path.isfile(mp3):
            os.remove(mp3)
    os.makedirs(kit("vozes", "minha_venda"), exist_ok=True)
    grava_texto(falas_cam, json.dumps({
        "sobre": "Falas do vídeo de venda, geradas pelo parceiro/parceiro.py com a mesma voz do \"você\" da série.",
        "modelo": "eleven_v4", "estabilidade": 0.3, "elenco": {"Você": eps[0]["voz"]}, "falas": falas}, ensure_ascii=False, indent=1) + "\n")

    # 3. configuracao do audio para o ep_audio.py
    sons(kit("out", "minha_venda_sons"))
    cfg = {
        "nome": "minha_venda", "voz_dir": "vozes/minha_venda", "prefixo": "V",
        "slots": [[b["de"], b["ate"]] for b in blocos], "arq": list(range(1, len(blocos) + 1)),
        "pausas": [], "saltos": [], "pre": 0, "base": base, "atempo": 1.06, "folga": 0.2,
        "ts_out": "src/minha_venda_vozes.ts", "nivelar_falas": -16, "volume_cama": 0.5,
        "cama": {"tipo": "arquivo", "arquivo": "out/minha_venda_sons/cama.wav", "final": base, "coracao": False},
        "eventos": eventos(blocos, base, R["palavra"]),
    }
    grava_texto(kit("episodios", "minha_venda.json"), json.dumps(cfg, ensure_ascii=False, indent=1) + "\n")

    # 4. kit do parceiro com a legenda do video
    escreve_kit(R, com_video=True)

    print("Vídeo de venda preparado (composição MinhaVenda).")
    print("Episódio usado: " + ", ".join(f"{e['id']} ({e['total']} quadros)" for e in eps) + f". Voz do \"você\": {eps[0]['voz']}.")
    cortados = []
    if R["seguidores"] is None:
        cortados.append("seguidores (não informado)")
    elif R["seguidores"] < MIN_SEGUIDORES:
        cortados.append(f"seguidores (menos de {fmt_int(MIN_SEGUIDORES)}, fica de fora)")
    if R["views"] is None:
        cortados.append("visualizações (não informado)")
    elif R["views"] < MIN_VIEWS:
        cortados.append(f"visualizações (menos de {fmt_int(MIN_VIEWS)}, fica de fora)")
    if R["dias"] is None:
        cortados.append("dias desde o primeiro post (não informado)")
    if cortados:
        print("Ficou de fora: " + "; ".join(cortados) + ".")
    print(f"Duração prevista: {base:.1f} s (o prep acerta pelas vozes).\n\nO que o vídeo fala:")
    for i, b in enumerate(blocos, start=1):
        print(f"  V{i:02d}  {sem_direcao(b['fala'])}")
    if refazer:
        print("\nFalas que mudaram desde a última vez (a voz antiga foi apagada e será gerada de novo): " + ", ".join(refazer))
    print(f"\nPróximo passo: {PY} gerar_vozes.py falas episodios/minha_venda.json")


def main():
    if len(sys.argv) < 2:
        para(USO)
    c = sys.argv[1]
    if c == "kit":
        cmd_kit()
    elif c == "video":
        cmd_video()
    elif c == "link":
        cmd_link()
    else:
        para(USO)


if __name__ == "__main__":
    main()
