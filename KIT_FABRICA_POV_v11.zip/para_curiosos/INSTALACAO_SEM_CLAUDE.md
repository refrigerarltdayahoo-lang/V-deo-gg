# Fábrica POV: instalação e uso pelo terminal (para curiosos)

O jeito normal de usar o kit é o do `LEIA-ME.html`: você abre a pasta do kit na aba Code do app do Claude, escreve "começar" e o Claude instala e faz tudo. Este guia é para quem prefere fazer à mão, pelo terminal, ou quer entender o que o Claude está fazendo.

A Fábrica POV é um projeto em Remotion para produzir episódios animados verticais em primeira pessoa: câmera olho de peixe, mãos em primeiro plano, legenda com cor por personagem, celular, câmeras de segurança e tela de voto. Não usa gerador de vídeo por IA. Cada cena é desenhada por código, então o episódio sai igual a cada renderização. Funciona no Windows e no Mac.

## 1. O que vem na pasta

| Item | O que é |
|---|---|
| `LEIA-ME.html` | O guia de uma página para o comprador. |
| `CLAUDE.md` | As instruções que o Claude lê sozinho quando você abre a pasta: conduzir a instalação, falar simples, pedir permissão explicando cada passo. |
| `.claude/skills/` | As skills do projeto, carregadas pelo Claude Code sem precisar copiar nada: `comecar` (instalação), `fabrica-pov` (episódio, com o modo guiado e as vozes em `VOZES.md`) e `novo-episodio` (atalho). Viram os comandos `/comecar`, `/fabrica-pov` e `/novo-episodio`. A pasta começa com ponto e fica escondida no Finder do Mac. |
| `para_curiosos/` | Este guia e o `MANUAL_COMO_FAZER_EPISODIO.md`, com as regras de roteiro, voz, imagem e áudio. |
| `ROTEIROS/` | O texto das falas dos dois exemplos. |
| `src/` | O código: câmera, mãos, legenda, personagens, celular, câmeras de segurança, tela de voto, os dois cenários e os dois episódios de exemplo. |
| `episodios/` | A configuração de áudio de cada exemplo (`portaria01.json`, `jonas01.json`) e a lista de falas para as vozes (`portaria01_falas.json`, `jonas01_falas.json`). |
| `ep_audio.py` | O gerador de áudio: cama sonora e efeitos sintetizados ou a partir de sons seus, mixagem com as vozes, conferência dos efeitos e dos tempos, e ajuste do volume final. |
| `gerar_vozes.py` | As vozes automáticas pela API do ElevenLabs (seção 7). |
| `vozes/` | Onde ficam os MP3 de cada episódio, as receitas de voz do kit (`receitas.json`) e o seu elenco (`elenco.json`, criado no primeiro uso). |
| `public/fontes/` | A fonte usada nas legendas, com a licença dela. |
| `LICENCA.md` | Os termos de uso do kit. |

Os dois exemplos:

- A Portaria (suspense), composição `Ep01`, cerca de 117 segundos.
- Jonas, parte 1: A Tempestade (o barco), composição `Jonas01`, cerca de 72 segundos.

## 2. O que o kit não traz

- Os arquivos de voz. Cada comprador gera as suas, com o roteiro e a receita do manual. Sem as vozes, os exemplos renderizam com a imagem e o tempo corretos e com o áudio de cama e efeitos, sem falas.
- A assinatura do Claude e o serviço de voz por IA. São contratados à parte.
- Promessa de alcance, visualizações, seguidores ou renda. O kit é uma ferramenta de produção.

## 3. Requisitos

- Computador com Windows 10 ou 11, ou macOS.
- 16 GB de memória recomendados e cerca de 3 GB livres em disco.
- Internet durante a instalação.
- Node, Python 3 e ffmpeg, todos gratuitos. A seção 4 mostra como instalar cada um no Windows e no Mac.
- Para criar episódios próprios: um plano pago do Claude (Pro, Max, Ultra, Team ou Enterprise) e um serviço de voz por IA que gere MP3. O kit já vem pronto para o ElevenLabs (seção 7).

Versões recomendadas: Node na versão LTS (é a que os comandos da seção 4 instalam), Python 3.9 ou mais novo e uma versão recente do ffmpeg.

## 4. Instalação

Siga a seção do seu sistema. Os dois caminhos chegam ao mesmo ponto: o kit instalado e pronto para renderizar o exemplo da seção 5.

O `ep_audio.py` usa apenas a biblioteca padrão do Python. Não há nada para instalar com o `pip` (veja o `requirements.txt`).

### 4.1 No Windows

Todos os comandos são digitados no PowerShell, que já vem no Windows.

1. Descompacte o kit. Clique com o botão direito no arquivo ZIP, escolha **Extrair Tudo**, troque o destino sugerido por `C:\fabrica-pov` e clique em **Extrair**. O kit fica na pasta `C:\fabrica-pov` (se o Windows pedir permissão de administrador, clique em Continuar). Prefira esse lugar: um caminho curto e sem espaço evita erro, e pastas sincronizadas com o OneDrive (em muitos computadores, Documentos e Área de Trabalho) atrapalham a instalação.
2. Abra o PowerShell na pasta do kit. Abra a pasta `C:\fabrica-pov` no Explorador de Arquivos, clique na barra de endereço, digite `powershell` e pressione Enter. A janela que abrir já está dentro da pasta do kit: a linha começa com `PS C:\fabrica-pov>`.
3. Instale o Node, o Python e o ffmpeg, um comando por vez:

```
winget install OpenJS.NodeJS.LTS
winget install Python.Python.3.12
winget install Gyan.FFmpeg
```

Se o winget pedir para aceitar os termos, digite `Y` e pressione Enter. Se o Windows pedir permissão para o instalador fazer alterações, clique em Sim. Se o PowerShell disser que `winget` não é reconhecido, instale o Instalador de Aplicativo (App Installer) pela Microsoft Store e repita este passo.

4. Feche o PowerShell e abra de novo na pasta do kit, como no passo 2. Os programas recém-instalados só aparecem em uma janela nova.
5. Confira. Cada comando deve responder com um número de versão:

```
node -v
py --version
ffmpeg -version
```

6. Libere o PowerShell para rodar o npm. Isso é feito uma vez só e vale apenas para o seu usuário:

```
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
```

7. Instale as dependências do projeto:

```
npm install
```

Na primeira instalação o tempo depende da internet e pode chegar a alguns minutos. A pasta `node_modules` fica com cerca de 250 MB. Ao final, o npm pode mostrar avisos como `10 high severity vulnerabilities` e uma nota sobre scripts de instalação. Esses avisos não impedem a instalação nem a renderização: eles se referem a uma biblioteca usada internamente pelo Remotion. Não rode `npm audit fix --force`, que troca versões das dependências e pode quebrar o projeto.

8. Baixe o navegador que o Remotion usa para renderizar (cerca de 100 MB, só uma vez):

```
npx remotion browser ensure
```

Pronto. Siga para a seção 5 e use os comandos marcados "No Windows".

### 4.2 No Mac

Todos os comandos são digitados no aplicativo Terminal (Applications > Utilities > Terminal).

1. Instale o Homebrew, um instalador de programas para o Mac, se ainda não tiver: acesse brew.sh, copie o comando de instalação que aparece na página, cole no Terminal e siga as instruções. Ao terminar, feche e abra o Terminal.
2. Instale o Node, o Python e o ffmpeg:

```
brew install node python ffmpeg
```

3. Confira. Cada comando deve responder com um número de versão:

```
node -v
python3 --version
ffmpeg -version
```

Se algum responder `command not found`, feche e abra o Terminal e tente de novo.

4. Descompacte o arquivo ZIP com dois cliques, de preferência no disco interno do computador (HD externo e pendrive costumam quebrar a instalação). Ele cria a pasta `KIT_FABRICA_POV_v11`, que é a pasta do kit.
5. No Terminal, entre na pasta do kit: digite `cd` seguido de um espaço, arraste a pasta `KIT_FABRICA_POV_v11` para a janela do Terminal e pressione Return.
6. Instale as dependências do projeto:

```
npm install
```

Na primeira instalação o tempo depende da internet e pode chegar a alguns minutos. A pasta `node_modules` fica com cerca de 250 MB. Os avisos de `vulnerabilities` que o npm pode mostrar no final não impedem a instalação nem a renderização. Não rode `npm audit fix --force`.

7. Baixe o navegador que o Remotion usa para renderizar (cerca de 100 MB, só uma vez):

```
npx remotion browser ensure
```

Pronto. Siga para a seção 5 e use os comandos marcados "No Mac".

### 4.3 Se der erro

1. **`node`, `py`, `ffmpeg` ou `npm` "não é reconhecido"** logo depois do winget: feche o PowerShell e abra de novo na pasta do kit (passo 4 da seção 4.1). O Windows só enxerga um programa recém-instalado em uma janela nova. Se continuar, reinicie o computador e confira de novo.
2. **O PowerShell bloqueia o npm** com uma mensagem como "o arquivo npm.ps1 não pode ser carregado porque a execução de scripts foi desabilitada neste sistema": rode o comando abaixo, que libera os scripts só para o seu usuário, e repita o comando que falhou.

```
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
```

3. **Caminho com espaço.** Se a pasta do kit está em um caminho com espaço (por exemplo, `C:\Users\Maria Silva\Downloads\KIT_FABRICA_POV_v11`) e um comando diz que não encontra o arquivo ou a pasta, ponha o caminho entre aspas duplas: `cd "C:\Users\Maria Silva\Downloads\KIT_FABRICA_POV_v11"`. O jeito mais simples é usar a pasta `C:\fabrica-pov` do passo 1.

No Mac, se um comando responder `command not found`, feche e abra o Terminal.

Se o erro continuar, fale com o suporte pelo contato que veio na sua compra e mande o texto inteiro da mensagem de erro ou um print da tela.

## 5. Renderizar o exemplo da portaria

Sempre a partir da pasta do kit: no PowerShell (Windows) ou no Terminal (Mac).

1. Renderize o vídeo (somente imagem). O comando é igual nos dois sistemas:

```
npm run render:portaria
```

O resultado é `out/portaria01_video.mp4`, dentro da pasta do kit. Em um notebook com 16 GB de memória, os 3.523 quadros (117 segundos de vídeo) levaram entre 3 e 4 minutos, com o arquivo final em 62 MB. O tempo varia com o computador.

2. Gere o áudio de cama e efeitos.

No Windows:

```
py ep_audio.py episodios/portaria01.json som
```

No Mac:

```
python3 ep_audio.py episodios/portaria01.json som
```

O resultado é `out/portaria01_som.wav`. Leva poucos segundos.

3. Junte imagem e som. O comando é igual nos dois sistemas:

```
ffmpeg -y -i out/portaria01_video.mp4 -i out/portaria01_som.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k out/portaria01_exemplo.mp4
```

Abra `out/portaria01_exemplo.mp4`. O vídeo terá a imagem completa, as legendas no tempo certo, a cama sonora e os efeitos. As falas ficam mudas até você gerar as vozes (seção 7). Esta junção simples serve para ver o exemplo; o episódio com vozes é finalizado com o comando `final`, que ajusta o volume.

### O exemplo do barco

No Windows:

```
npm run render:barco
py ep_audio.py episodios/jonas01.json som
ffmpeg -y -i out/jonas01_video.mp4 -i out/jonas01_som.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k out/jonas01_exemplo.mp4
```

No Mac:

```
npm run render:barco
python3 ep_audio.py episodios/jonas01.json som
ffmpeg -y -i out/jonas01_video.mp4 -i out/jonas01_som.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k out/jonas01_exemplo.mp4
```

Rode um comando por vez e espere cada um terminar.

### Ver um quadro isolado

Para conferir um ponto do episódio sem renderizar tudo (igual nos dois sistemas):

```
npx remotion still src/index.ts Jonas01 out/quadro.png --frame=300
```

Troque `Jonas01` por `Ep01` para a portaria e `300` pelo número do quadro (30 quadros por segundo).

### Pré-visualizar no navegador

```
npm run studio
```

O Remotion Studio abre no navegador e permite percorrer o episódio quadro a quadro. Para encerrar, pressione Ctrl + C no terminal. Se o Windows perguntar se deseja finalizar, confirme.

## 6. Fazer um episódio próprio com o Claude

O jeito recomendado é o app do Claude, na aba Code, com a pasta do kit aberta (veja o `LEIA-ME.html`). Escreva "quero fazer um episódio": o Claude segue a skill `fabrica-pov`, faz até 5 perguntas, propõe o roteiro e faz o resto. A aba Code precisa de uma assinatura paga do Claude (Pro, Max, Ultra, Team ou Enterprise); o plano grátis não inclui o Claude Code.

As instruções do projeto ficam no `CLAUDE.md` da raiz e nas skills de `.claude/skills/`. O Claude Code lê os dois sozinho quando a sessão começa nesta pasta, tanto no app quanto no Claude Code de terminal: não é preciso copiar a skill para lugar nenhum. Se você abrir uma pasta acima ou abaixo da do kit, o `CLAUDE.md` pode não ser lido: abra sempre a pasta que tem o `CLAUDE.md`.

Quem prefere o terminal pode instalar o Claude Code de linha de comando (comandos oficiais em code.claude.com/docs/en/setup): no Windows, `irm https://claude.ai/install.ps1 | iex` no PowerShell; no Mac, `curl -fsSL https://claude.ai/install.sh | bash` no Terminal. Depois, dentro da pasta do kit, digite `claude`.

O manual `MANUAL_COMO_FAZER_EPISODIO.md` (nesta pasta) tem as regras e o passo a passo completo, em 8 passos (seção 8 do manual).

Para renderizar um episódio novo, use o identificador registrado no `src/Root.tsx` e grave o vídeo como `out/NOME_video.mp4`, em que NOME é o campo `nome` do arquivo de configuração do episódio. É esse arquivo que o comando `final` procura. Exemplo para um episódio com `nome` igual a `meuep01` (igual nos dois sistemas):

```
npx remotion render src/index.ts MeuEp01 out/meuep01_video.mp4 --concurrency=2
```

## 7. Gerar e conferir as vozes

Vale para os dois exemplos e para os seus episódios.

### 7.1 Automático, pelo ElevenLabs

O `gerar_vozes.py` usa só a biblioteca padrão do Python. Ele lê a chave do arquivo `.env` da pasta do kit (uma linha `ELEVENLABS_API_KEY=sua_chave`; a chave fica no site do ElevenLabs, menu Developers, aba API Keys).

```
py gerar_vozes.py chave
py gerar_vozes.py receitas
py gerar_vozes.py amostras rapaz
py gerar_vozes.py salvar rapaz 1
py gerar_vozes.py falas episodios/portaria01.json
py gerar_vozes.py falas episodios/portaria01.json --sim
```

No Mac, `python3` no lugar de `py`. Na ordem: confere a chave e os créditos (não gasta); lista as vozes prontas do kit; cria 3 amostras de uma voz pelo Voice Design (gasta um pouco de crédito) em `vozes/amostras/`; guarda a amostra escolhida como voz da sua conta e no elenco (`vozes/elenco.json`); confere a lista de falas e mostra quantas letras vão ser geradas (não gasta); gera as falas que faltam (gasta). Para refazer falas: `--sim --refazer L03,L07`. Para usar uma voz que já está na sua conta: `py gerar_vozes.py usar NOME VOICE_ID` (veja as suas com `py gerar_vozes.py minhas-vozes`).

O exemplo da portaria usa as vozes `rapaz`, `homem_maduro` e `homem_animado` (3 vozes, o limite do plano grátis). No plano grátis, a API do ElevenLabs não usa as vozes da biblioteca (Voice Library); por isso o kit cria as vozes na sua conta pelo Voice Design. O plano grátis não inclui licença comercial: confira os termos e planos no site do ElevenLabs.

### 7.2 Manual, em qualquer serviço de voz

1. Abra o roteiro (`ROTEIROS/ROTEIRO_PORTARIA.md` ou `ROTEIROS/ROTEIRO_BARCO.md`). Cada linha da tabela é um arquivo de voz.
2. Gere uma voz por fala no serviço de sua preferência, seguindo a receita da seção 4 do manual: direção em inglês entre colchetes só no começo da fala, número por extenso, uma voz por personagem.
3. Confira cada arquivo: ouça com o roteiro na mão. Fala com palavra repetida, trocada ou faltando deve ser gerada de novo. A transcrição automática é opcional e não está incluída no kit; o manual traz exemplos na seção 4.
4. Salve os MP3 com os nomes indicados no roteiro, na pasta do exemplo: `vozes/portaria01/L01.mp3` a `L23.mp3`, ou `vozes/jonas01/J01.mp3` a `J19.mp3`.
5. Prepare as vozes, gere a cama e os efeitos, faça a mixagem e confira os efeitos. O `prep` mede cada fala, grava os tempos no projeto e mostra em que quadro cada fala começa e termina.

No Windows:

```
py ep_audio.py episodios/portaria01.json prep
py ep_audio.py episodios/portaria01.json som
py ep_audio.py episodios/portaria01.json mix
py ep_audio.py episodios/portaria01.json confere
```

No Mac:

```
python3 ep_audio.py episodios/portaria01.json prep
python3 ep_audio.py episodios/portaria01.json som
python3 ep_audio.py episodios/portaria01.json mix
python3 ep_audio.py episodios/portaria01.json confere
```

O `confere` mostra o contraste de cada efeito, separa os efeitos de história dos de ambiente e avisa quando um efeito cai embaixo de uma fala. A seção 7.3 do manual explica como ler e corrigir. Em episódio próprio, rode também `confere-tempos`, que compara os tempos do código com os do arquivo de configuração (seção 7.5 do manual).

6. Renderize de novo, porque a duração do episódio acompanha a duração das suas vozes, e gere o arquivo final.

No Windows:

```
npm run render:portaria
py ep_audio.py episodios/portaria01.json final
```

No Mac:

```
npm run render:portaria
python3 ep_audio.py episodios/portaria01.json final
```

O resultado é `out/portaria01_final.mp4`. O comando `final` junta o vídeo com o mix, ajusta o volume para -14 LUFS com pico real de até -1,5 dBTP e mostra os números medidos no arquivo pronto. Nos nossos testes, um mix que saiu em -20,0 LUFS e outro em -17,9 LUFS foram entregues em -14,1 e -14,2 LUFS.

Referência de custo, sem garantia: nos nossos episódios, 24 falas custaram perto de 9 créditos no serviço que usamos. Preços e planos mudam e dependem do fornecedor.

## 8. Erros comuns e o que fazer

Nos comandos desta tabela, use `py` no Windows e `python3` no Mac.

| O que aparece | O que fazer |
|---|---|
| `node`, `npm`, `py`, `python3` ou `ffmpeg` "não é reconhecido" (Windows) ou `command not found` (Mac) | O programa não está instalado ou o terminal não foi reaberto. Refaça a instalação da seção 4 e feche e abra o terminal. Veja também a seção 4.3. |
| O PowerShell diz que a execução de scripts foi desabilitada | Rode o comando do item 2 da seção 4.3. |
| `npm install` para com erro de rede | Confira a internet e rode `npm install` de novo. Não rode como administrador e não use `sudo`. |
| Erro ao baixar o navegador na primeira renderização | Rode `npx remotion browser ensure` com a internet funcionando. |
| `NÃO FOI POSSÍVEL CONTINUAR` com a lista de arquivos de voz que faltam | O comando `prep` ou `mix` não encontrou as vozes. Gere os MP3, salve na pasta indicada na mensagem, com os nomes indicados, e rode de novo. Sem as vozes, use apenas o comando `som`. |
| `Falta o arquivo out/..._som.wav` | Rode o comando `som` antes do `mix`. |
| `Não consegui gravar ...` | O arquivo está aberto em outro programa, como um player de vídeo ou de áudio. Feche e rode de novo. |
| `AVISO: os tempos em out/..._warp.json ... NÃO batem mais` | O arquivo de configuração mudou depois do último `prep`. Rode `prep` de novo e depois `som` e `mix`. |
| `AVISO: vídeo e áudio diferem` no comando `final` | As vozes mudaram depois da renderização. Rode `prep`, `som` e `mix`, renderize de novo e repita o `final`. |
| O vídeo final está baixo ou alto demais | Use o comando `final` da seção 7 em vez da junção simples da seção 5. |
| O vídeo renderizado não tem som | É o esperado: a renderização gera só a imagem. Junte o áudio com o comando `ffmpeg` da seção 5 (exemplo sem vozes) ou com o comando `final` da seção 7. |
| A legenda não acompanha a voz | As vozes foram trocadas depois do último `prep`, ou os tempos do episódio e do arquivo de configuração não batem. Rode `py ep_audio.py episodios/NOME.json confere-tempos` (no Mac, `python3` no lugar de `py`), corrija o que ele apontar, rode `prep`, `som` e `mix` de novo e renderize outra vez. |
| A renderização fica muito lenta ou o computador trava | Feche outros programas e confira o espaço em disco. Se persistir, renderize com um núcleo: `npx remotion render src/index.ts Ep01 out/portaria01_video.mp4 --concurrency=1`. |
| Tela vermelha no Studio ou erro de TypeScript em um episódio novo | Copie a mensagem inteira para o Claude e peça a correção. Os exemplos do kit não devem apresentar esse erro. |
| As letras aparecem com outra fonte | A pasta `public/fontes/` precisa estar dentro da pasta do kit, com os dois arquivos `.woff2`. Descompacte o ZIP de novo. |
| Um emoji aparece como um quadrado vazio | O emoji é mais novo que a fonte de emoji do sistema. Troque por um emoji comum (seção 2.5 do manual). |
| `No space left on device` ou disco cheio | Libere espaço. A pasta `out/` pode ser apagada: ela guarda apenas arquivos gerados. |

## 9. Bom saber

- O tempo de renderização depende do computador e do tamanho do episódio.
- A fonte das legendas vem dentro do kit, então as letras são as mesmas no Windows e no Mac. Os emojis (tela de voto e celular) usam a fonte de emoji do sistema, por isso o desenho deles muda um pouco de um sistema para o outro.
- Com as suas vozes, a duração do episódio e o resultado do som dependem dos arquivos que você gerar. Os comandos `prep`, `confere` e `final` mostram os números para você conferir.
- Os dois exemplos já vêm mixados pelas regras de som do manual e servem de referência de mixagem. A seção 7.3 do manual lista os poucos efeitos que ficam abaixo da meta por estarem presos à imagem, e explica por quê.
- A qualidade do episódio novo depende do roteiro e da sua direção. O manual reúne as lições que aprendemos, mas não substitui a revisão de cada quadro.

## 10. Licença

O uso do kit segue o arquivo `LICENCA.md`. Em resumo: o kit é para uso próprio do comprador, os vídeos que você produzir são seus, e não é permitido revender nem redistribuir o kit. O Remotion tem licença própria: é gratuito para pessoa física e para empresa de até 3 pessoas.
