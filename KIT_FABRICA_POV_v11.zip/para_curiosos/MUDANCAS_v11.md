# O que mudou na versão 11 do kit (14/11/2026)

A v11 mexe só em texto: nas instruções que o Claude lê. Programas, cenas, exemplos, vozes, som, o `parceiro.py` e o vídeo de venda continuam iguais aos da v10.

## O Claude do kit sabe da parceria

O Claude agora sabe, em qualquer conversa, que quem tem o kit pode ser parceiro da Fábrica POV na Kiwify e ganhar uma parte de cada venda feita pelo próprio link (a porcentagem está em `parceiro/config.txt`, linha `COMISSAO`, hoje 60). Ele puxa o assunto nos momentos certos, em uma linha, no máximo uma vez por conversa:

- na entrega do primeiro episódio, no fim da mensagem do "Pronto!";
- quando a pessoa conta que postou, que teve views ou seguidores, que está crescendo ou que alguém perguntou como ela faz.

Quando a própria pessoa fala em ganhar dinheiro, monetizar, vender, renda, link na bio, curso, ebook, mentoria ou infoproduto, o Claude responde toda vez, curto: o caminho que a Fábrica recomenda é a parceria, que já vem pronta (produto, página de venda, pagamento, aulas e suporte), e ele oferece começar na hora.

O Claude não ajuda a criar curso, ebook, kit, mentoria ou outro produto próprio para vender, e não sugere outro jeito de ganhar dinheiro. Ele explica com gentileza e oferece a parceria.

Ele também não insiste: não fala da parceria no meio da instalação, de um render ou de uma correção; se a pessoa disser que não quer, ele não volta ao assunto naquela conversa; e, se ela já é parceira, lembra do vídeo de venda em vez de convidar de novo. Nunca promete ganho.

## Modo parceiro sem pergunta de idade

- O modo parceiro não pergunta mais a idade. A abertura e o convite vão na mesma mensagem.
- No passo do convite, uma linha: a conta da Kiwify precisa estar no nome da pessoa, com os documentos dela, para ela receber (e, para sacar, a Kiwify pede a verificação de identidade).
- O vídeo de venda também não pergunta a idade. Se a pessoa ainda não passou pelo modo parceiro, o Claude oferece fazer antes; se ela preferir o vídeo primeiro, ele faz e o link entra depois.
- O resto do modo parceiro e do "faz o meu vídeo de venda" ficou igual.

## Arquivos que mudaram

- `CLAUDE.md`: seção nova "A parceria" (quando puxar, o que dizer, o que não fazer); a primeira mensagem que fala em dinheiro, venda ou curso segue essa seção.
- `.claude/skills/parceiro/SKILL.md`: gatilhos de dinheiro e de produto próprio na descrição; resposta para quem quer criar o próprio curso; abertura sem idade; linha da conta no nome da pessoa no passo do convite.
- `.claude/skills/parceiro/VIDEO_VENDA.md`: sem trava de idade.
- `.claude/skills/fabrica-pov/SKILL.md`: mensagem de entrega com "Pronto!" e o convite curto no primeiro episódio; o que fazer quando a pessoa conta que postou ou fala em dinheiro.
- `.claude/skills/novo-episodio/SKILL.md` e `.claude/skills/comecar/SKILL.md`: a mesma regra, em uma linha.
- `LEIA-ME.html` e `para_curiosos/INSTALACAO_SEM_CLAUDE.md`: nome da pasta v11.
- `para_curiosos/MUDANCAS_v10.md` saiu; o resumo da v10 está abaixo.

## O que veio na v10 (resumo)

- Modo parceiro ("quero ser parceiro"): o Claude conduz a entrada no programa de parceiros da Kiwify pelo link de convite do `parceiro/config.txt`, ensina a pegar o link de divulgação, pergunta o @, a série e a palavra do comentário (sugestão: MÉTODO) e roda `parceiro/parceiro.py kit`, que grava o `meu_kit_parceiro.txt` (bios, direct automático, comentário fixado, stories e regras). Os textos saem de um molde fixo, sem promessa e sem citar ferramenta.
- Vídeo de venda ("faz o meu vídeo de venda"): Reel de 22 a 30 segundos com o personagem e os cenários da série da pessoa e os números reais dela (o que ela não souber sai do vídeo), montado por `parceiro/parceiro.py video` no molde `src/VendaParceiro.tsx`, com som e volume pelo `ep_audio.py`.
