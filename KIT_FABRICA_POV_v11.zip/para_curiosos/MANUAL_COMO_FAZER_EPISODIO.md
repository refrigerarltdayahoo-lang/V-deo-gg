# Como fazer um episódio na Fábrica POV

Manual para quem vai montar um episódio novo, seja você, seja o Claude trabalhando na pasta do kit. Leia inteiro antes de escrever código. Se você usa o Claude, peça que ele leia este arquivo inteiro antes de começar.

**Quem roda os comandos.** No uso normal do kit, quem roda todos os comandos deste manual é o Claude, na aba Code do app do Claude, com a pasta do kit aberta: você conversa e clica em Permitir. Os comandos estão aqui para consulta e para quem preferir o terminal (no Windows, o PowerShell; no Mac, o Terminal), sempre a partir da pasta do kit. Os comandos de áudio estão escritos com `py`, o nome do Python no Windows. No Mac, use `python3` no lugar de `py`. Os comandos `npx` e `ffmpeg` são iguais nos dois sistemas.

## 1. O que é

Série animada vertical (1080x1920, 30 quadros por segundo) em primeira pessoa, com lente olho de peixe, feita em Remotion. Não há vídeo gerado por IA: tudo é SVG desenhado por código, por isso o episódio sai igual a cada renderização. O espectador é o personagem, e só as mãos dele aparecem. Cada episódio termina com um voto de uma palavra.

## 2. Arquivos de referência

Leia antes de começar:

- `src/engine.tsx`: a câmera olho de peixe.
- `src/Navio.tsx`: exemplo de cenário (convés e porão). `src/Portaria.tsx`: outro cenário.
- `src/Jonas01.tsx`: o exemplo mais limpo de linha do tempo (câmera por alvos, falas, tempo elástico, tela de voto). `src/Ep01.tsx`: exemplo com celular, câmeras de segurança, `PAUSAS` e `SALTOS`.
- `src/Maos.tsx` (`Maos`, seção 2.2), `src/Legenda.tsx` (`Legenda`, `EtiquetaParte`, `EtiquetaDireita`, `CORES`, seção 2.3), `src/Celular.tsx` (seção 2.4), `src/Escolha.tsx` (seção 2.5), `src/Personagens.tsx` (`Boneco`, seção 2.6) e `src/Cftv.tsx` (o monitor de câmeras da portaria).
- `ep_audio.py`, `episodios/jonas01.json` e `episodios/portaria01.json`: áudio por configuração.
- `ROTEIROS/`: o texto das falas dos dois exemplos.

### 2.1 O motor (`engine.tsx`)

- O mundo é medido em metros: x para a direita, y para cima, z para a frente. As funções `quad`, `line`, `outline`, `grid` e `box` desenham nesse mundo.
- **A ordem de desenho é a profundidade.** O motor não esconde o que está atrás: o que é desenhado depois cobre o que foi desenhado antes. Desenhe do fundo para a frente (céu, parede do fundo, móveis, personagens, o que está perto da câmera). Para algo passar por trás de uma parede, desenhe esse algo antes da parede.
- `quad(cam, key, a, b, c, d, cor, n, m)` fatia o quadrilátero em n por m pedaços para as bordas curvarem com a lente. Superfície grande (piso, parede) precisa de mais fatias (6 a 10); superfície pequena pode usar 2 ou 3. Com poucas fatias, uma parede grande aparece com borda reta e descola do resto.
- `bill(cam, key, [x, y, z], filhos)` prende um desenho 2D (personagem, placa, objeto) a um ponto do mundo. Dentro dele as medidas são em centímetros, com y para baixo e origem nos pés.
- Texto dentro de `bill` ou de qualquer SVG precisa da fonte do kit: importe `fontFamily` de `./fontes` e use `fontFamily={fontFamily}` no elemento `<text>`. Sem isso o texto sai com a fonte padrão do navegador.

### 2.2 As mãos (`Maos`)

Sem nenhuma propriedade de objeto, as duas mãos aparecem abertas, de dorso para cima.

| Propriedade | O que faz | Padrão |
|---|---|---|
| `esq`, `dir` | Posição de cada mão na tela: `{ x, y, rot, s }` (pixels, graus e escala; `sy` opcional achata a mão). `null` esconde a mão. | obrigatórias |
| `tema` | Cores da manga e da pele. Há `TEMA_PORTEIRO` e `TEMA_MARINHEIRO`; crie o seu com o tipo `Tema`. | `TEMA_PORTEIRO` |
| `objetoDir` | Objeto pronto na mão direita: `"fone"`, `"gravetos"` ou `"punho"` (mão fechada vazia). | `null` (mão aberta) |
| `desenhoDir` | O seu desenho de objeto (SVG) na mão direita. A mão fecha em volta dele. | nenhum |
| `rotDir` | Ângulo, em graus, dos dedos e do objeto da mão direita. | conforme o objeto |
| `esqPunho` | Mão esquerda fechada. | `false` |
| `desenhoEsq`, `rotEsq` | O mesmo que `desenhoDir` e `rotDir`, para a mão esquerda. | nenhum |
| `fioPara` | Ponto da tela onde termina o fio do fone. Só com `objetoDir="fone"`. | nenhum |
| `corda` | Corda grossa atravessando a tela, por trás dos punhos. | `false` |
| `sombra` | Sombra redonda embaixo da mão aberta. Ligue quando a mão está apoiada em bancada ou mesa; com a mão no ar, deixe desligada. | `false` |

O desenho próprio usa as coordenadas da mão: pulso em (0, 0), centro da palma em (0, -60), y para baixo, palma com cerca de 210 de largura. Ele fica entre a palma e os dedos, que fecham por cima. Exemplo de uma chave na mão direita:

```
<Maos esq={esq} dir={dir} rotDir={20}
  desenhoDir={<rect x={-30} y={-330} width={60} height={300} rx={12} fill="#d9b23c" stroke="#15130f" strokeWidth={9} />} />
```

Objeto que cobre a mão inteira (um celular visto de frente, por exemplo) pede um desenho próprio da mão dentro do arquivo da sua cena.

Pose para a mão não cruzar com a legenda: a ponta dos dedos da mão aberta fica em `y` menos 335 vezes `s` (vezes `sy`, se houver). Mantenha esse valor em 1500 ou mais. As poses dos exemplos servem de ponto de partida: mãos apoiadas em `{ x: 250, y: 1850, rot: 9, s: 1.5, sy: 0.5 }` e `{ x: 840, y: 1850, rot: -9, s: 1.5, sy: 0.5 }` (portaria), e punhos fechados em `{ x: 250, y: 1640, rot: 14, s: 1.2 }` e `{ x: 840, y: 1600, rot: -14, s: 1.2 }` (barco). Mão aberta sem `sy` e com `s` acima de 1 precisa de `y` perto de 1900 para não encostar na legenda baixa.

### 2.3 Legenda e etiquetas (`Legenda.tsx`)

- Cada fala é `{ de, ate, quem, texto, y?, tel? }`, com `de` e `ate` em quadros do roteiro.
- `quem` é uma chave de `CORES`. Para episódios novos use as chaves genéricas: `branco` (sempre quem assiste), `azul`, `laranja`, `verde`, `rosa`, `lilas` e `amarelo`. As chaves com nome de personagem (`voce`, `interfone`, `capitao` e as demais) são apelidos usados pelos exemplos.
- `tel` é opcional: um selo pequeno acima da legenda, para dizer de onde vem a voz. Exemplo: `tel: "INTERFONE · 804"`.
- `<EtiquetaParte n={1} />` é a etiqueta `PARTE 1` do alto à esquerda.
- `<EtiquetaDireita borda="#c9a66b">texto</EtiquetaDireita>` é a etiqueta do alto à direita (relógio, capítulo, local). `borda` é a cor da moldura.

### 2.4 O celular (`Celular`)

Mostra uma conversa de mensagens em primeiro plano, com o aparelho na mão esquerda. A conversa é o texto da cena: não coloque legenda enquanto o celular está na tela.

| Propriedade | O que faz |
|---|---|
| `entra` | De 0 a 1. Em 0 o celular não aparece; em 1 está inteiro na tela; no meio do caminho ele sobe ou desce. Use a função `janela`. |
| `titulo`, `sub` | Nome da conversa e a linha pequena embaixo dele ("online", "você e mais 61"). |
| `avatar` | Um emoji ou uma letra, no círculo ao lado do nome. |
| `msgs` | Lista de mensagens. Cada uma: `texto`; `nome` e `cor` (quem mandou, em grupo); `meu: true` (mensagem de quem assiste, à direita); e `ap`, de 0 a 1, que é a aparição da mensagem. Trecho entre asteriscos sai em vermelho: `"*NÃO ATENDE.*"`. Cabem duas mensagens por vez com folga. |
| `tema` | Cores da manga e da pele do braço que segura o aparelho. É o mesmo `Tema` de `Maos`: passe o mesmo nos dois. Padrão: `TEMA_PORTEIRO`. |

Duas funções prontas, exportadas pelo `Celular.tsx`, fazem as contas:

- `janela(T, a, b)`: devolve de 0 a 1 enquanto o roteiro está entre `a` e `b` segundos, com subida e descida curtas. É o valor de `entra`.
- `visiveis(lista, T, max)`: recebe as mensagens com hora marcada (`{ t, m }`, tipo `MsgNoTempo`) e devolve as últimas `max` que já chegaram no instante `T`, com o `ap` calculado.

Trecho mínimo, com uma mensagem só:

```
import { Celular, MsgNoTempo, janela, visiveis } from "./Celular";

// a mensagem chega em 12,4 s do roteiro
const MAE: MsgNoTempo[] = [{ t: 12.4, m: { texto: "Filho, *NÃO ENTRA* no ônibus." } }];
// o roteiro para 3,2 s em 13,5 s, para dar tempo de ler
const PAUSAS: { b: number; extra: number }[] = [{ b: 13.5, extra: 3.2 }];
// com pausas, a linha de CORTES é a do Ep01.tsx, que junta as falas e as pausas
const CORTES = [...FALAS.map((f, i) => ({ b: f.ate / FPS, extra: EXTRAS[i] ?? 0 })), ...PAUSAS].sort((x, y) => x.b - y.b);

// dentro do componente, com T = tempo do roteiro
const celOn = janela(T, 12.2, 13.9);
const esq = celOn > 0 ? null : { x: 250, y: 1850, rot: 9, s: 1.5, sy: 0.5 };

<Maos esq={esq} dir={dir} />
<Celular entra={celOn} titulo="Mãe" sub="online" avatar="👩" msgs={visiveis(MAE, T, 1)} />
```

O que não pode faltar:

- **Mão esquerda escondida.** O `Celular` desenha o próprio braço esquerdo. Enquanto ele está na tela, passe `esq={null}` para `Maos`.
- **Sem legenda durante o celular.** Nenhuma fala de `FALAS` pode cair dentro da janela do celular.
- **Pausa para leitura.** Cada mensagem fica 1 segundo mais 0,28 segundo por palavra. A pausa é escrita em dois lugares, em formatos diferentes: no TSX, `{ b: 13.5, extra: 3.2 }` dentro de `PAUSAS`; no arquivo de configuração, `"pausas": [[13.5, 3.2]]`. Os valores têm de ser os mesmos (o comando `confere-tempos` confere).
- **Qual exemplo copiar.** Episódio sem celular: a estrutura do `Jonas01.tsx`. Episódio com celular ou com pausas: a do `Ep01.tsx`, que já tem `PAUSAS`, `SALTOS` e a linha de `CORTES` completa.
- O quadro para conferir a mensagem na tela é o do meio da pausa, que o comando `quadros` mostra.

### 2.5 A tela de voto (`Escolha`)

Fecha o episódio com as duas opções e uma barra de tempo.

| Propriedade | O que faz |
|---|---|
| `q` | Quadros do roteiro desde o início do voto. Negativo: a tela não aparece. |
| `dur` | Duração do voto em quadros. A barra de tempo esvazia nesse intervalo. |
| `a`, `b` | As duas opções, UMA palavra cada. `a` sai no botão vermelho, `b` no azul. |
| `sa`, `sb` | O texto pequeno de cada botão: o custo daquela escolha. |
| `ia`, `ib` | Um emoji para cada botão. |
| `rodape` | A frase de baixo, curta. Padrão: "A mais votada decide a PARTE 2". |

Trecho mínimo, com o voto começando em `VOTO` segundos do roteiro e `BASE` igual a `VOTO` mais 5 a 7 segundos:

```
const VOTO = 29;
const fim = T >= VOTO;

{fim ? null : <Maos esq={esq} dir={dir} />}
{fim ? null : <EtiquetaParte n={1} />}
<Legenda falas={FALAS} quadro={frame} />
<Escolha q={Math.round(frame - S(VOTO))} dur={S(BASE - VOTO)} a="ENTRAR" b="FICAR" sa="no ônibus sem motorista" sb="no ponto, com o estranho" ia="🚌" ib="🪑" />
```

Esconda as mãos e as etiquetas durante o voto, como nos exemplos. No arquivo de configuração, `cama.final` é o mesmo instante `VOTO`.

Os emojis (`ia`, `ib`, o `avatar` do celular) são desenhados com a fonte de emoji do sistema, então o desenho muda um pouco entre Windows e Mac. Prefira emojis comuns, que existem há anos (porta, casa, relógio, onda, ônibus). Emoji lançado de 2020 em diante pode não existir no Windows 10 e sair como um quadrado vazio. Na dúvida, tire um quadro da tela de voto e confira.

### 2.6 Os personagens (`Boneco`)

Boneco de corpo inteiro, desenhado em centímetros, com a origem nos pés e cerca de 200 de altura. Use dentro de `bill`, para ele ficar preso a um ponto do cenário.

| Propriedade | O que faz |
|---|---|
| `camisa`, `calca`, `pele`, `cabelo` | Cores. Obrigatórias. |
| `expr` | Expressão: `"sorriso"`, `"serio"`, `"grito"`, `"neutro"`, `"susto"` ou `"dormindo"`. Obrigatória. |
| `t` | Tempo real em segundos (`Tr`). Anima a água e a batida. Obrigatória. |
| `mao` | De 0 a 1: braço direito erguido, com a palma aberta para a frente (a mão no vidro). |
| `bate` | O braço treme, como quem bate em uma porta ou vidro. |
| `sentado` | Sentado de frente: o corpo desce 22 cm e os joelhos aparecem à frente do tronco. O assento fica a cerca de 42 cm do chão. Desenhe o banco antes do boneco. |
| `molhado` | Cabelo escorrido, gotas e poça nos pés. |
| `bone`, `barba`, `faixa` | Boné, barba e faixa na testa: o valor é a cor. |
| `capuz`, `tunica` | Capuz na cor da camisa; roupa longa de época, que cobre as pernas. |
| `mochila` | Mochila vermelha de entregador, com os dizeres do exemplo da portaria. |

Trecho mínimo:

```
import { Boneco, Expr } from "./Personagens";
import { bill } from "./engine";

const falando = FALAS.some((f) => f.quem === "laranja" && frame >= f.de && frame < f.ate);
const expr: Expr = falando && Math.floor(Tr * 7) % 2 === 0 ? "neutro" : "serio";

{bill(cam, "homem", [0.5, 0, 3.4], <Boneco camisa="#5d6f86" calca="#23262f" pele="#c9a184" cabelo="#2a2320" expr={expr} t={Tr} sentado />)}
```

A boca "fala" alternando duas expressões enquanto a fala do personagem está na tela, como no trecho acima. Dê a cada personagem um traço próprio (boné, barba, cor de camisa) para ele não se confundir com os outros.

## 3. Regras de roteiro

Estas regras vêm da observação de séries do mesmo formato com bom desempenho e da nossa produção. São orientação de formato, não garantia de resultado.

1. Abra na rotina, com uma fala banal no primeiro quadro. Não mostre antes o que vem depois.
2. A quebra da rotina vem entre 2 e 8 segundos.
3. Uma regra é imposta, alguém pede o contrário, e há prova contra os dois lados.
4. Legenda nova a cada 2 a 3 segundos; virada na história a cada 10 a 15 segundos.
5. Mensagem de celular fica na tela por 1 segundo mais 0,28 segundo por palavra, uma de cada vez (use `PAUSAS`, como no `Ep01.tsx`).
6. Final: tela de voto com UMA palavra para cada opção e a frase que diz o que o voto decide.
7. Duração final entre 65 e 120 segundos, sempre acima de 60.
8. Uma piada escondida no cenário por episódio (placa, adesivo, nome de loja).
9. Sem sangue e sem violência explícita.

## 4. Regras de voz

O kit não traz arquivos de voz. Você gera as suas, uma por fala, em MP3.

O caminho automático é o `gerar_vozes.py`, que usa a API do ElevenLabs: a lista de falas do episódio fica em `episodios/<ep>_falas.json` (quem fala e o texto de cada arquivo, como em `episodios/portaria01_falas.json`), as vozes ficam no elenco (`vozes/elenco.json`) e o comando `py gerar_vozes.py falas episodios/<ep>.json --sim` salva os MP3 com os nomes que o `prep` procura. As vozes prontas do kit são receitas do Voice Design do ElevenLabs (`vozes/receitas.json`), criadas na sua própria conta. No plano grátis do ElevenLabs a API não usa vozes da biblioteca (Voice Library), por isso o kit cria as vozes na sua conta. O passo a passo que o Claude segue está em `.claude/skills/fabrica-pov/VOZES.md`.

O caminho manual continua valendo: gere no serviço de voz por IA que preferir e salve com os nomes do roteiro.

A receita abaixo foi desenvolvida com o modelo ElevenLabs v4 (nos nossos episódios, acessado pelo Higgsfield), com estabilidade 0,3 e um pedido por fala. Ela evita os erros mais comuns: palavra repetida, número lido errado e sotaque trocado.

- Direção de emoção em inglês, entre colchetes, SOMENTE no começo da fala. Exemplo: `[whispering, tense] Não abre pra ele.` Direção no meio da fala já duplicou palavra e trocou o timbre.
- Número sempre por extenso ("oitocentos e quatro", não "804"). A legenda pode continuar com algarismos.
- Não comece a fala com palavra escrita igual ao inglês (decide, final, real, total, normal). O modelo tende a ler com pronúncia inglesa.
- Se uma palavra insiste em sair com sotaque errado, reescreva a fala sem ela em vez de gerar várias vezes.
- Uma voz por personagem, bem diferentes entre si. Quem assiste tem sempre a mesma voz em toda a série.
- Gere as vozes limpas. Os efeitos (interfone, vidro, porão) são aplicados pelo `ep_audio.py`.

Vozes que usamos, como exemplo: Leo (quem assiste), Andre, Kevin, Marcus e Julian. São predefinições do serviço que usamos e não são requisito. Os identificadores delas nesse serviço, apenas para referência de quem usa o mesmo: Leo `73a45c18-0c56-4642-a61e-f6b303f8ded1`, Andre `f1e8226e-2248-4d5f-b43c-0a79e9949dbf`, Kevin `f1373f24-3b96-433f-9a68-e595810ef608`, Marcus `6f98d3dd-324f-4845-8c28-c1d1647a06cd`, Julian `95429266-c0ac-4137-a209-63b8812b0f23`. Em outro serviço, escolha vozes brasileiras equivalentes.

### Conferência das vozes

Toda fala gerada é conferida antes de entrar no episódio.

**Padrão: escuta.** Ouça cada arquivo com o roteiro na mão. Fala com palavra repetida, trocada ou faltando é gerada de novo uma vez. Se o erro persistir, reescreva a fala.

**Opcional: transcrição automática.** Ajuda quando são muitas falas. O kit não inclui transcritor: é um programa à parte, de código aberto, e o modelo, com cerca de 1,6 GB, é baixado no primeiro uso. Carregue o modelo uma vez para todos os arquivos.

No Windows, um exemplo é o `faster-whisper` (instalação por `py -m pip install faster-whisper`):

```
import glob
from faster_whisper import WhisperModel
modelo = WhisperModel("turbo", device="cpu", compute_type="int8")
for arquivo in sorted(glob.glob("vozes/meuep01/*.mp3")):
    trechos, info = modelo.transcribe(arquivo, language="pt", condition_on_previous_text=False)
    print(arquivo, "|", " ".join(t.text.strip() for t in trechos))
```

No Mac com processador Apple (M1 em diante), um exemplo é o `mlx-whisper` (instalação por `pip install mlx-whisper`):

```
import glob, mlx_whisper
for arquivo in sorted(glob.glob("vozes/meuep01/*.mp3")):
    r = mlx_whisper.transcribe(arquivo, path_or_hf_repo="mlx-community/whisper-large-v3-turbo", language="pt", condition_on_previous_text=False, verbose=None)
    print(arquivo, "|", r["text"].strip())
```

Compare cada linha com o texto do roteiro. A transcrição também erra: na dúvida, ouça o arquivo.

## 5. Regras de imagem

- Legenda: no meio da tela (y 1060) por padrão. Desce (y entre 1280 e 1340) quando o ponto de interesse está no centro. Nunca cobre a prova visual da cena, o celular, uma placa ou os dedos.
- Cor de legenda por personagem. Branco é sempre quem assiste.
- Etiqueta `PARTE 1` no alto à esquerda. No alto à direita, um relógio ou outra etiqueta do episódio (`EtiquetaDireita`).
- Zona segura do Instagram: 108 px no topo, 320 px na base, 80 px nas laterais.
- Mãos de quem assiste sempre em primeiro plano, com um objeto da cena quando fizer sentido.
- Câmera: alvos por tempo (`ALVOS`), balanço leve contínuo e um empurrão lento em todo plano.

## 6. Tempo elástico

O roteiro é escrito em um "tempo do roteiro", com um espaço reservado para cada fala. O comando `ep_audio.py prep` mede cada voz e grava, em um arquivo TS, os segundos extras que cada fala precisa. No componente, a função `tempoAntigo(Tr)` faz o relógio do roteiro parar no fim da fala até a voz acabar. Animações contínuas (balanço, chuva, boca) usam o tempo real `Tr`.

- `PAUSAS`: paradas para leitura (mensagens de celular).
- `SALTOS`: valor extra negativo, que pula um trecho do roteiro.

Os arquivos `*_vozes.ts` guardam apenas números. Por isso os exemplos renderizam com o tempo certo mesmo sem os arquivos de voz.

**Os números de quadro mudam depois do `prep`.** Com as vozes medidas, o episódio estica e cada fala passa a começar em outro quadro. O `prep` imprime o quadro real de início, de fim e do meio de cada fala e de cada pausa. Para ver essa tabela de novo, ou converter qualquer instante do roteiro em quadro:

```
py ep_audio.py episodios/NOME.json quadros
py ep_audio.py episodios/NOME.json quadros 12.5 18
```

## 7. Áudio

Os comandos, sempre a partir da pasta do kit.

No Windows (PowerShell):

```
py ep_audio.py episodios/NOME.json prep
py ep_audio.py episodios/NOME.json som
py ep_audio.py episodios/NOME.json mix
py ep_audio.py episodios/NOME.json confere
py ep_audio.py episodios/NOME.json confere-tempos
py ep_audio.py episodios/NOME.json final
```

No Mac (Terminal):

```
python3 ep_audio.py episodios/NOME.json prep
python3 ep_audio.py episodios/NOME.json som
python3 ep_audio.py episodios/NOME.json mix
python3 ep_audio.py episodios/NOME.json confere
python3 ep_audio.py episodios/NOME.json confere-tempos
python3 ep_audio.py episodios/NOME.json final
```

Nos outros trechos deste manual os comandos aparecem só com `py`; no Mac, troque por `python3`. As mensagens do próprio `ep_audio.py` já mostram o comando certo para o seu sistema.

- `prep`: trata as vozes (corta silêncio, ajusta velocidade, aplica efeito e, com `nivelar_falas`, leva cada fala ao mesmo volume), mede cada uma, grava os tempos extras no arquivo TS do episódio e mostra o quadro de cada fala. Precisa dos MP3 na pasta `voz_dir`.
- `som`: sintetiza a cama sonora e os efeitos e grava `out/NOME_som.wav`. Funciona sem as vozes.
- `mix`: junta vozes e som em `out/NOME_audio.wav`. Precisa do `prep` e do `som`.
- `confere`: mede cada efeito (seção 7.3).
- `final`: junta o vídeo renderizado com o mix e ajusta o volume (seção 7.4).
- `confere-tempos`: compara os tempos do TSX do episódio com os do arquivo de configuração (seção 7.5).
- `quadros`: mostra o quadro de cada fala e de cada pausa (seção 6).

Sempre que regravar uma voz, rode `prep`, `som` e `mix` de novo e renderize outra vez: a duração do episódio muda com a duração das vozes.

O `som` usa os tempos gravados pelo último `prep` (`out/NOME_warp.json`). Se esse arquivo não existe, usa os tempos do arquivo TS. Se você mudar `slots`, `pausas` ou `saltos` depois do `prep`, os comandos mostram um AVISO de tempos velhos: rode o `prep` de novo.

### 7.1 Campos do arquivo de configuração

| Campo | Significado |
|---|---|
| `nome` | Nome curto do episódio. Dá nome aos arquivos em `out/`. |
| `voz_dir` | Pasta das vozes, relativa à pasta do kit. Exemplo: `vozes/meuep01`. |
| `prefixo` e `arq` | Nome dos MP3: prefixo mais número com dois dígitos. Com prefixo `L` e `arq` igual a `[1, 2, 3]`, os arquivos são `L01.mp3`, `L02.mp3` e `L03.mp3`, na ordem das falas. |
| `slots` | Início e fim de cada fala no tempo do roteiro, em segundos. Tem de bater com a lista `FALAS` do componente. |
| `fx` | Efeito de voz por fala: `interfone`, `vidro` ou `porao`. Cada lista traz a POSIÇÃO da fala em `slots`, começando em 1 (a terceira fala é 3), e não o número do arquivo em `arq`. |
| `pausas` e `saltos` | Os mesmos valores de `PAUSAS` e `SALTOS` do componente. Têm de bater. |
| `base` | Duração do roteiro, em segundos. Igual ao `BASE` do componente. |
| `pre` | Segundos antes do início do roteiro. Normalmente 0. |
| `atempo` | Velocidade aplicada às vozes (1,06 a 1,08 nos exemplos). |
| `folga` | Respiro depois de cada fala, em segundos. |
| `nivelar_falas` | Opcional. Volume, em LUFS, a que o `prep` leva cada fala depois de tratada. Os exemplos usam -16; `true` também vale -16. Evita que uma fala curta, sussurrada ou com efeito fique mais baixa que as outras. Sem este campo, o `prep` não faz esse ajuste. |
| `nivel_por_fala` | Opcional. Exceções ao `nivelar_falas`: a posição da fala em `slots`, começando em 1, e o volume em LUFS. Exemplo: `{"13": -17}` deixa a fala 13 um pouco mais baixa de propósito, e `{"4": -14}` deixa um grito mais alto. `false` no lugar do número deixa a fala sem ajuste. |
| `ts_out` | Arquivo TS que recebe os tempos extras. Exemplo: `src/meuep01_vozes.ts`. |
| `volume_cama` | Volume do arquivo de som (cama mais efeitos) na mixagem com as vozes. |
| `cama.tipo` | `tempestade`, `sala` ou `arquivo`. Com `arquivo`, a cama é um som seu: informe o caminho em `cama.arquivo` (por exemplo, `"arquivo": "sons/rua.mp3"`, relativo à pasta do kit). O som repete até cobrir o episódio; prefira um arquivo mais longo que o episódio ou que repita sem emenda. |
| `cama.final` | Instante do roteiro em que a tela de voto começa. A cama cai para menos da metade a partir daí. |
| `cama.coracao` | Batimento de coração durante a tela de voto, de `cama.final` até o fim. Ligado por padrão; use `false` para desligar. |
| `cama.abafada` | Só na tempestade: trechos `[início, fim]` em ambiente fechado. |
| `cama.segunda_camada`, `cama.subida` | Só na sala: instante em que entra uma segunda nota grave, e trecho `[início, fim]` de um tom que sobe, para tensão. |
| `cama.ganho_db` | Opcional. Sobe ou desce a cama inteira em relação aos efeitos, em dB. Valor negativo abaixa. |
| `ducking` | Opcional. `true` abaixa a cama 4 dB em volta de cada efeito de história (seção 7.3). Um número troca a quantidade de dB. Ligado nos dois exemplos. |
| `eventos` | Lista de efeitos: `[tipo, instante no tempo do roteiro, volume]`. No fim de cada um pode vir `"historia"` ou `"ambiente"` (seção 7.3). Sem a marca, o efeito conta como história. O tipo `arquivo` usa um som seu (seção 7.2). |

### 7.2 Efeitos disponíveis

| Tipo | Som | Duração |
|---|---|---|
| `toque` | Dois toques de interfone ou telefone | 0,45 s |
| `clique` | Clique seco (gancho, botão) | 0,05 s |
| `plim` | Notificação de mensagem, duas notas | 0,32 s |
| `chiado` | Chiado curto de troca de câmera | 0,16 s |
| `zumbido` | Lâmpada falhando | quarto valor do evento (padrão 0,8 s) |
| `sino` | Sino de elevador | 0,9 s |
| `batida` | Uma batida grave (porta, casco) | 0,2 s |
| `batidas` | Batidas seguidas, a cada 0,21 s | até o instante do quarto valor |
| `tique` | Estalo curto | 0,05 s |
| `impacto` | Pancada grave com cauda | 1,6 s |
| `trovao` | Estalo e ronco longo | 3 s |
| `onda` | Onda que cresce e quebra | 2,6 s |
| `splash` | Água espirrando | 0,7 s |
| `arquivo` | Um som seu (WAV, MP3 ou outro formato que o ffmpeg leia) | a do arquivo |

Tipo que não está na tabela é ignorado, com aviso.

**Som próprio.** Para um som que a tabela não tem (motor, freio, porta, sirene), use o tipo `arquivo`, com o caminho do som como quarto valor, relativo à pasta do kit: `["arquivo", 19.6, 1.0, "sons/freio.wav", "historia"]`. Com volume 1, o pico do arquivo fica no nível de um `impacto` de volume 1. O `ducking` e o `confere` tratam esse evento como os outros. Guarde os seus sons em uma pasta sua dentro do kit (por exemplo, `sons/`).

**Onde pôr um efeito de história.** Não basta o efeito caber no intervalo entre duas falas. Ele precisa de pelo menos 0,7 s de silêncio ANTES dele (melhor 1 s), contado do fim real da voz anterior, e não do fim do espaço da fala no roteiro. O motivo: o `confere` compara o efeito com os 0,7 s anteriores, e é assim que o ouvido percebe também. Se o fim da fala ainda está nesse trecho, o efeito não se destaca, por mais forte que seja. Uma `batida` de 0,2 s colocada em um intervalo de 0,4 s cabe, mas sai com contraste baixo. Planeje o roteiro já com essa folga antes de cada efeito de história; o `prep` mostra onde cada voz termina de verdade. Efeito de ambiente pode ficar em intervalo curto.

O `plim` é um som fraco: como efeito de história ele mal alcança a meta e costuma pedir a cama bem mais baixa (`ganho_db` de -9, por exemplo). Se a mensagem do celular é a virada da cena, acompanhe o `plim` com um `impacto` no mesmo instante, como o exemplo da portaria faz.

O volume de cada evento é relativo. No fim, o `som` normaliza o arquivo inteiro pelo pico mais alto. Na prática, o evento mais forte define a escala: subir o volume de um único evento muito acima dos outros abaixa todo o resto, inclusive a cama.

### 7.3 Conferir os efeitos (`confere`)

```
py ep_audio.py episodios/NOME.json confere
```

**História e ambiente.** Cada efeito tem um papel, e você marca esse papel no fim do evento:

- `"historia"`: o som é a própria informação da cena. Alguém bate na porta, o interfone toca, o impacto marca a virada, o elevador chega. Precisa ser ouvido com clareza.
- `"ambiente"`: som de interface e de clima. O clique do gancho, o aviso de mensagem, o chiado da troca de câmera, o zumbido da lâmpada, a onda, o trovão de fundo. Acompanha a imagem sem disputar atenção.

Exemplo: `["batida", 57.2, 1.0, "historia"]` e `["plim", 27.3, 1.0, "ambiente"]`.

O `confere` mede o mix (`out/NOME_audio.wav`) ou, se ele ainda não existe, o arquivo de som, e mostra os dois grupos separados. Para cada evento aparecem o instante real, o quadro, o contraste e a situação:

- Contraste: nível médio do ataque do efeito (até 0,4 s) menos o nível médio dos 0,7 s anteriores. Em repetição do mesmo efeito em menos de 0,75 s (toque e toque, batida e batida), a referência são os 0,7 s antes do primeiro.
- Meta, só para os efeitos de história: 12 dB para `impacto` e `trovao` e 9 dB para os demais.
- `ATAQUE EMBAIXO DA FALA n`: o efeito começa enquanto a fala n está tocando.
- `cauda sobre a fala n`: o efeito começa em um intervalo livre, mas o final dele entra na fala n. É aceitável em efeito longo.

Efeito de ambiente não tem meta: o contraste dele aparece só para você conferir que não está alto demais.

Para subir o contraste de um efeito de história, nesta ordem:

1. Se ele não está preso a nada que se vê na imagem, mude o instante para um intervalo entre falas. Se está preso à imagem (a mão que bate, o clarão do raio), não mude: a sincronia com o vídeo vale mais que a meta.
2. Ligue `"ducking": true`. A cama desce 4 dB de 0,8 s antes de cada efeito de história até o fim do ataque dele.
3. Baixe a cama inteira com `"ganho_db"` dentro de `cama` (por exemplo, -5).
4. Suba o volume do evento. Faça isso por último e com parcimônia: o `som` normaliza pelo evento mais forte.
5. Baixe o volume de um efeito de ambiente que esteja logo antes.

Depois rode `som`, `mix` e `confere` de novo. Confira nas duas situações: só o arquivo de som (`confere out/NOME_som.wav`) e o mix com as vozes.

Quando o ataque de um efeito de história coincide com o começo de uma fala, por estar preso à imagem, a medida no mix mistura o efeito com a voz e deixa de valer como contraste. Nesse caso confira o efeito no arquivo de som e ouça o trecho: a fala tem de continuar clara.

**Os dois exemplos como referência de mixagem.** Os dois arquivos de configuração de exemplo já vêm mixados por estas regras e servem de modelo: cada evento marcado como história ou ambiente, `ducking` ligado, cama abaixada com `ganho_db` (-7 dB na portaria e -6 dB no barco) e `nivelar_falas` em -16. Nenhum evento dos exemplos mudou de instante para cumprir a meta, porque todos estão presos à imagem.

Medidos só com cama e efeitos, a portaria tem 17 dos 19 efeitos de história na meta, e o barco, 8 de 8. O que fica de fora, e por quê:

- Portaria, sinos do elevador em 89,6 e 90,3 (cerca de 8,5 dB, para uma meta de 9): estão entre as batidas no vidro e o impacto da tela de voto, que vem 0,7 s depois. Subir mais o sino tiraria o contraste do impacto final, que é o mais importante da cena.
- Efeitos de história com o ataque no começo de uma fala, por estarem presos à imagem. Na portaria: o toque de abertura, a batida de 23,3, a batida de 57,2, as batidas de 87 a 89 e os impactos de 8,8, 31,0, 50,5 e 60,6. No barco: os trovões de 2,0, 42,0 e 60,8 e a batida de 20,1. Contra a cama, todos cumprem a meta. No mix com as nossas vozes, três deles aparecem com contraste baixo (o impacto de 8,8 da portaria e os trovões de 2,0 e 60,8 do barco), porque os 0,7 s anteriores contêm a fala anterior. Em nenhum deles o pico do efeito passa do pico da fala.

### 7.4 Volume final (`final`)

```
py ep_audio.py episodios/NOME.json final
```

Junta `out/NOME_video.mp4` (a renderização, sem som) com `out/NOME_audio.wav` (o mix) e grava `out/NOME_final.mp4`. O comando mede o mix, aplica ganho e limitador até o volume ficar em -14 LUFS (faixa aceita de -14,5 a -13,5) com pico real de no máximo -1,5 dBTP, e imprime o que mediu no arquivo pronto: LUFS, pico real, quadros do vídeo e duração do áudio. Não usa compressor e não corta o vídeo.

Para outros nomes de arquivo, informe os três caminhos: `final VIDEO.mp4 AUDIO.wav SAIDA.mp4`.

Se aparecer o aviso de que o limitador está segurando muitos dB, a mixagem tem efeitos muito mais fortes que as vozes: baixe o volume dos eventos mais fortes e repita `som`, `mix` e `final`. Se aparecer o aviso de que vídeo e áudio têm durações diferentes, as vozes mudaram depois da renderização: rode `prep`, `som` e `mix`, renderize de novo e repita o `final`.

### 7.5 Tempos em dois lugares (`confere-tempos`)

Os mesmos tempos vivem em dois arquivos: no TSX do episódio (`FALAS`, `PAUSAS`, `SALTOS`, `BASE`, o instante do voto) e no arquivo de configuração (`slots`, `pausas`, `saltos`, `base`, `cama.final`). Se eles divergirem, nada quebra: a legenda apenas sai fora da voz. **Toda vez que mexer em um tempo, mexa nos dois arquivos** e confira:

```
py ep_audio.py episodios/NOME.json confere-tempos
```

O comando lê o TSX que importa o arquivo de tempos do episódio e diz, linha por linha, o que não bate. Também compara a duração com a do último `prep` e com a do vídeo já renderizado, se ele existir. Ele lê o formato dos exemplos: `fala(início, fim, ...)` com números escritos, `{ b: ..., extra: ... }`, `const BASE = número;` e o voto como `q={Math.round(frame - S(VOTO))}`. Se o seu TSX escrever um tempo como conta ou variável, o comando avisa que não conseguiu ler aquele item e não o confere: nesse caso, confira à mão.

Depois de mudar `slots`, `pausas` ou `saltos`, rode o `prep` de novo: os números de quadro mudam.

## 8. Passo a passo de um episódio novo

Crie arquivos novos. Não altere `engine`, `Maos`, `Legenda`, `Personagens`, `Celular`, `Cftv`, `Escolha`, `ep_audio.py` nem os arquivos dos exemplos: assim os exemplos continuam funcionando como referência. Se faltar algo em um componente compartilhado, faça uma variante local dentro do arquivo da sua cena. O único arquivo existente que você edita é o `src/Root.tsx`, para registrar o episódio.

1. Cenário: `src/<Cena>.tsx`.
2. Linha do tempo: `src/<Ep>.tsx`, exportando o componente e a duração. Sem celular, copie a estrutura do `Jonas01.tsx`; com celular ou pausas, a do `Ep01.tsx` (seção 2.4).
3. Tempos de voz e registro: `src/<ep>_vozes.ts`, que começa com `export const EXTRAS: number[] = [];`, e duas linhas no `src/Root.tsx`, iguais às dos exemplos. Uma de `import` do componente e da duração, no alto, e uma `<Composition>`, na lista.
4. Áudio: `episodios/<ep>.json`, com `voz_dir` apontando para `vozes/<ep>`. Rode `confere-tempos` para ver se os tempos batem com os do TSX.
5. Vozes: escreva `episodios/<ep>_falas.json`, gere com `py gerar_vozes.py falas episodios/<ep>.json --sim` (ou uma por fala no serviço que preferir, salvas em `vozes/<ep>/`), confira cada uma e rode `prep`.
6. Som: rode `som`, `mix` e `confere` e corrija o contraste dos efeitos de história (seção 7.3). Faça isso ANTES de conferir os quadros: corrigir o contraste pode mexer em `slots`, o que pede `prep` de novo e muda o número de todos os quadros. Se mexeu em tempo, repita `confere-tempos`, `prep`, `som`, `mix` e `confere`.
7. Conferência visual: com os tempos e o som fechados, tire cerca de 14 quadros espalhados pelo episódio, usando a tabela do comando `quadros` (`npx remotion still src/index.ts <Id> out/quadro.png --frame=N`), olhe cada um e corrija o que estiver errado. Duas rodadas costumam bastar. Se a correção mudar um tempo, volte ao passo 6.
8. Finalização: renderize o vídeo e rode `final`. Grave a renderização como `out/NOME_video.mp4`, em que NOME é o campo `nome` do arquivo de configuração (`npx remotion render src/index.ts <Id> out/NOME_video.mp4 --concurrency=2`): é esse arquivo que o `final` procura. Se quiser, faça também uma cópia leve em 720x1280 para enviar por mensagem.

Antes das vozes você já pode tirar quadros para ver o cenário e os personagens. Só não use esses números de quadro depois: a conferência que vale é a do passo 7, feita depois do `prep` e do `confere`.

## 9. Cuidados com o computador

- Renderização e transcrição são tarefas pesadas. Rode uma de cada vez.
- Mantenha pelo menos 3 GB livres em disco. Confira antes de renderizar: com o disco quase cheio, a renderização falha ou o computador fica instável.
- Em computador com 16 GB de memória, renderize com `--concurrency=2`.
- A pasta `out/` guarda arquivos intermediários e pode ser apagada quando o episódio estiver pronto. Guarde os vídeos finais e as vozes em outro lugar.

## 10. Lições de qualidade

Nasceram de várias rodadas de revisão dos nossos episódios. Valem para todo episódio novo.

### Roteiro e voto

- O voto precisa de prova VISÍVEL contra os dois lados antes da tela de voto, e o texto pequeno de cada botão diz o custo daquela escolha. Voto com resposta óbvia gera pouco comentário.
- A virada que sustenta o dilema tem de ser legível no tamanho do celular, com e sem som: plano próprio de 1,2 segundo ou mais, corte seco e uma fala curta de quem assiste reagindo ("Ela... piscou pra ele?").
- Coloque algo estranho e visível nos 3 primeiros segundos, sem quebrar a regra da fala banal.

### Imagem

- Prova pequena não é lida. Objeto na mão ou no corpo do boneco só funciona em plano fechado, com fundo que contraste. Sombra escura sobre fundo escuro não aparece: clareie o fundo.
- Não force o boneco a fazer uma pose que o cenário não comporta. Se a prova não é legível, tire a prova e deixe a fala carregar a informação.
- Personagem secundário precisa de um traço próprio (pijama listrado, dente de ouro, óculos de aro grosso) e de reagir ao que acontece. A expressão muda com transição de 2 a 3 quadros, nunca de um quadro para o outro.
- Movimento sutil de cenário durante um movimento de câmera se confunde com a câmera: pare a câmera primeiro. Gesto pequeno de personagem, como um olhar, pede a câmera já perto do rosto ANTES de o gesto começar. A ordem que funciona: câmera perto do rosto, gesto, câmera assenta e para, cenário se mexe, som no intervalo depois da fala.
- Notificação entra já na posição final, com fade e escala, abaixo das etiquetas.
- Mão que segura o celular de frente: palma atrás, polegar saindo da palma, dedos dobrados na borda oposta. Esse desenho não existe no componente compartilhado; faça uma variante local na sua cena.
- Tela de voto: o componente `Escolha` já mantém os textos dentro da margem lateral de 80 px. Mantenha o rodapé curto (até cerca de 32 caracteres) para ele caber em uma linha.
- Com um cenário só e boneco genérico, o episódio tem um teto de qualidade. Séries mais fortes do formato usam de 4 a 9 cenários.

### Som

- O ataque de um efeito sonoro não fica embaixo de fala, a não ser que ele esteja preso a algo que se vê na imagem. Efeito de história pede 0,7 s de silêncio antes dele, melhor 1 s, contado do fim real da voz anterior (seção 7.2). Confira com o `confere`.
- Cama alta tira o impacto dos efeitos. Marque cada efeito como história ou ambiente e mire nas metas de contraste do `confere` (9 dB, e 12 dB para impactos) nos efeitos de história. Se faltar contraste, siga a ordem da seção 7.3. Não suba tudo: é a cama que desce.
- Volume final: use o comando `final`, que entrega -14 LUFS com pico real de até -1,5 dBTP usando ganho e limitador. Não use o filtro `loudnorm` de uma passada para isso: ele comprime a dinâmica e achata a mixagem.
- Confira os números NO ARQUIVO FINAL. O `final` imprime o volume e o pico medidos no arquivo pronto. Para medir o contraste dos efeitos nesse arquivo: `py ep_audio.py episodios/NOME.json confere out/NOME_final.mp4`.
