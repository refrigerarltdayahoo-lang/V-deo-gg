import React from "react";
import { Cam, V3, W, H, bill, box, line, outline, quad } from "./engine";

// Cenario do episodio de Jonas: conves de um barco antigo na tempestade e o porao.
const INK = "#15130f";
const MAD = "#6b4a2e";
const MAD_E = "#4a321f";
const MAD_C = "#5a3d25";

export type NavioState = {
  t: number; // segundos reais (ondas, vela, lanterna)
  raio: number; // 0 a 1, clarao de relampago
  onda: number; // 0 a 1, onda gigante na proa
  carga: boolean; // carga ainda no conves
  local: "conves" | "porao";
};

const Conves: React.FC<{ c: Cam; st: NavioState; gente?: React.ReactNode }> = ({ c, st, gente }) => {
  const els: React.ReactNode[] = [];
  const push = (e: React.ReactNode) => els.push(e);
  const t = st.t;

  push(<rect key="ceu" x={0} y={0} width={W} height={H} fill="#0a0f1c" />);
  // nuvens pesadas
  [[-6, 9, 30, 520], [5, 11, 34, 620], [0, 13, 40, 700], [-12, 8, 36, 480], [11, 8, 30, 460]].forEach(([x, y, z, r], i) =>
    push(bill(c, `nuv${i}`, [x + 0.6 * Math.sin(t * 0.2 + i), y, z], <ellipse rx={r} ry={r * 0.42} fill={i % 2 ? "#1a2233" : "#141b2a"} />)),
  );
  // mar
  push(quad(c, "mar", [-40, -1.6, 60], [40, -1.6, 60], [40, -1.6, 7.2], [-40, -1.6, 7.2], "#0f2a3c", 8, 6));
  for (let i = 5; i >= 0; i--) {
    const z = 10 + i * 7;
    const h = -0.9 + 1.3 * Math.sin(t * 1.1 + i * 1.7);
    push(quad(c, `on${i}`, [-40, h, z], [40, h, z], [40, -1.6, z], [-40, -1.6, z], i % 2 ? "#143649" : "#18405a", 10, 1));
    push(line(c, `cr${i}`, [-40, h, z], [40, h, z], "#cfe4ee", 5, 24, 0.55));
  }
  if (st.onda > 0.01) {
    const hh = -1.2 + 8.5 * st.onda;
    push(quad(c, "ondona", [-30, hh, 9.2], [30, hh, 9.2], [30, -1.6, 9.2], [-30, -1.6, 9.2], "#1b4a66", 10, 4));
    push(line(c, "ondona-e", [-30, hh, 9.2], [30, hh, 9.2], "#e9f6fb", 16, 24, 0.9));
    push(line(c, "ondona-e2", [-30, hh - 0.5, 9.2], [30, hh - 0.5, 9.2], "#9cc7d8", 7, 24, 0.5));
  }

  // conves
  push(quad(c, "piso", [-2.3, 0, 7], [2.3, 0, 7], [2.3, 0, -2.5], [-2.3, 0, -2.5], MAD, 6, 12));
  for (let i = 0; i <= 12; i++) {
    const x = -2.3 + i * (4.6 / 12);
    push(line(c, `tab${i}`, [x, 0.003, 7], [x, 0.003, -2.5], MAD_E, 3, 20));
  }
  // amuradas
  const amurada = (k: string, a: V3, b: V3) => {
    push(quad(c, k, [a[0], 1.0, a[2]], [b[0], 1.0, b[2]], [b[0], 0, b[2]], [a[0], 0, a[2]], MAD_C, 8, 2));
    push(line(c, `${k}t`, [a[0], 1.0, a[2]], [b[0], 1.0, b[2]], INK, 8, 20));
    push(line(c, `${k}m`, [a[0], 0.5, a[2]], [b[0], 0.5, b[2]], MAD_E, 3, 20));
    push(line(c, `${k}b`, [a[0], 0, a[2]], [b[0], 0, b[2]], INK, 6, 20));
  };
  amurada("proa", [-2.3, 0, 7], [2.3, 0, 7]);
  amurada("bb", [-2.3, 0, -2.5], [-2.3, 0, 7]);
  amurada("eb", [2.3, 0, 7], [2.3, 0, -2.5]);

  // carga
  if (st.carga) {
    push(box(c, "cx1", [-1.9, 0, 3.9], [-1.2, 0.6, 4.6], { top: "#9a7746", front: "#84643a", side: "#6f5330" }, INK, 5));
    push(box(c, "cx2", [1.25, 0, 4.2], [1.9, 0.5, 4.9], { top: "#9a7746", front: "#84643a", side: "#6f5330" }, INK, 5));
    push(
      bill(c, "jarro", [1.55, 0.5, 4.5], (
        <path d="M-9 0 Q-16 -18 -8 -34 L-5 -42 L5 -42 L8 -34 Q16 -18 9 0 Z" fill="#b5673c" stroke={INK} strokeWidth={2.4} strokeLinejoin="round" />
      )),
    );
  }

  // mastro, verga, vela e cordas
  push(line(c, "cd1", [-2.3, 1.0, 0.4], [0, 8.6, 5.3], "#231810", 5, 14));
  push(line(c, "cd2", [2.3, 1.0, 0.4], [0, 8.6, 5.3], "#231810", 5, 14));
  const f = (k: number) => 0.3 * Math.sin(t * 3.1 + k) + 0.15 * Math.sin(t * 5.3 + k * 2);
  const vela: V3[] = [[-2.3, 6.2, 5.35 + f(0)], [2.3, 6.2, 5.35 + f(1)], [2.1, 2.7, 5.35 + f(2) * 1.6], [-2.1, 2.7, 5.35 + f(3) * 1.6]];
  push(quad(c, "vela", vela[0], vela[1], vela[2], vela[3], "#c9bc96", 6, 6));
  push(quad(c, "vela-f", [-0.35, 6.2, 5.33 + f(0.5)], [0.35, 6.2, 5.33 + f(0.5)], [0.3, 2.7, 5.33 + f(2.5) * 1.6], [-0.3, 2.7, 5.33 + f(2.5) * 1.6], "#9c4a35", 2, 6));
  push(outline(c, "vela-o", vela, INK, 6));
  push(line(c, "verga", [-2.6, 6.25, 5.3], [2.6, 6.25, 5.3], "#2e1f12", 16, 14));
  push(box(c, "mastro", [-0.16, 0, 5.15], [0.16, 9, 5.45], { top: MAD_E, front: "#3d2a19", side: "#33220f" }, INK, 5));
  const bal = 12 * Math.sin(t * 2.2);
  push(
    bill(c, "lanterna", [0, 2.25, 5.1], (
      <g transform={`rotate(${bal})`}>
        <circle cx={0} cy={22} r={120} fill="url(#haloN)" />
        <line x1={0} y1={0} x2={0} y2={10} stroke={INK} strokeWidth={2.5} />
        <rect x={-8} y={10} width={16} height={22} rx={4} fill="#ffcf6b" stroke={INK} strokeWidth={2.4} />
      </g>
    )),
  );

  if (gente) push(<g key="gente">{gente}</g>);

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="haloN">
          <stop offset="0%" stopColor="#ffd98a" stopOpacity={0.6} />
          <stop offset="100%" stopColor="#ffb347" stopOpacity={0} />
        </radialGradient>
      </defs>
      {els}
      <rect x={0} y={0} width={W} height={H} fill="#cfe2ff" opacity={0.55 * st.raio} />
    </svg>
  );
};

const Porao: React.FC<{ c: Cam; st: NavioState; gente?: React.ReactNode }> = ({ c, st, gente }) => {
  const els: React.ReactNode[] = [];
  const push = (e: React.ReactNode) => els.push(e);
  const t = st.t;
  const X = 2.1;
  const Z = 4.2;
  const Y = 2.05;
  push(<rect key="fundo" x={0} y={0} width={W} height={H} fill="#120c07" />);
  push(quad(c, "piso", [-X, 0, Z], [X, 0, Z], [X, 0, -1.5], [-X, 0, -1.5], "#4a3320", 6, 8));
  for (let i = 0; i <= 8; i++) push(line(c, `tb${i}`, [-X + (i * 2 * X) / 8, 0.003, Z], [-X + (i * 2 * X) / 8, 0.003, -1.5], "#33220f", 3, 16));
  push(quad(c, "teto", [-X, Y, -1.5], [X, Y, -1.5], [X, Y, Z], [-X, Y, Z], "#33220f", 6, 8));
  for (let i = 0; i < 5; i++) push(line(c, `vg${i}`, [-X, Y - 0.02, -1 + i * 1.2], [X, Y - 0.02, -1 + i * 1.2], "#1d1309", 14, 14));
  const parede = (k: string, x: number) => {
    push(quad(c, k, [x, Y, -1.5], [x, Y, Z], [x, 0, Z], [x, 0, -1.5], "#553a23", 8, 4));
    for (let j = 1; j < 5; j++) push(line(c, `${k}l${j}`, [x, (Y * j) / 5, -1.5], [x, (Y * j) / 5, Z], "#33220f", 3, 20));
  };
  parede("pe", -X);
  parede("pd", X);
  push(quad(c, "fundo-p", [-X, Y, Z], [X, Y, Z], [X, 0, Z], [-X, 0, Z], "#4a321f", 6, 4));
  for (let j = 1; j < 5; j++) push(line(c, `fl${j}`, [-X, (Y * j) / 5, Z], [X, (Y * j) / 5, Z], "#33220f", 3, 14));
  push(outline(c, "fundo-o", [[-X, Y, Z], [X, Y, Z], [X, 0, Z], [-X, 0, Z]], INK, 6));
  // escada a direita
  push(line(c, "esc1", [1.2, 0, 3.6], [1.5, Y, 2.6], "#2a1c10", 12, 6));
  push(line(c, "esc2", [1.9, 0, 3.6], [2.0, Y, 2.6], "#2a1c10", 12, 6));
  for (let i = 1; i < 5; i++) push(line(c, `deg${i}`, [1.2 + i * 0.06, (Y * i) / 5, 3.6 - i * 0.2], [1.9 + i * 0.02, (Y * i) / 5, 3.6 - i * 0.2], "#2a1c10", 9, 3));
  // sacos e jarros
  const saco = (k: string, p: V3, s = 1) =>
    push(bill(c, k, p, <g transform={`scale(${s})`}><ellipse cx={0} cy={-18} rx={34} ry={20} fill="#a8905f" stroke={INK} strokeWidth={2.6} /><path d="M-20 -22 q20 -8 40 0" stroke="#7d6a43" strokeWidth={2} fill="none" /></g>));
  saco("s1", [-1.2, 0, 3.3], 1.2);
  saco("s2", [-0.4, 0, 3.5], 1.1);
  saco("s3", [-1.5, 0, 2.5], 1.1);
  push(bill(c, "j1", [0.6, 0, 3.7], <path d="M-11 0 Q-20 -22 -9 -42 L-6 -52 L6 -52 L9 -42 Q20 -22 11 0 Z" fill="#b5673c" stroke={INK} strokeWidth={2.6} strokeLinejoin="round" />));
  push(bill(c, "j2", [0.1, 0, 3.9], <path d="M-9 0 Q-16 -18 -8 -34 L-5 -42 L5 -42 L8 -34 Q16 -18 9 0 Z" fill="#9c5632" stroke={INK} strokeWidth={2.6} strokeLinejoin="round" />));
  if (gente) push(<g key="gente">{gente}</g>);
  saco("s4", [-0.2, 0, 2.2], 1.25);
  const bal = 16 * Math.sin(t * 2.0);
  push(
    bill(c, "lant", [0.5, Y - 0.05, 1.8], (
      <g transform={`rotate(${bal})`}>
        <circle cx={0} cy={38} r={150} fill="url(#haloP)" />
        <line x1={0} y1={0} x2={0} y2={26} stroke={INK} strokeWidth={2.5} />
        <rect x={-8} y={26} width={16} height={22} rx={4} fill="#ffcf6b" stroke={INK} strokeWidth={2.4} />
      </g>
    )),
  );
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="haloP">
          <stop offset="0%" stopColor="#ffd98a" stopOpacity={0.55} />
          <stop offset="100%" stopColor="#ffb347" stopOpacity={0} />
        </radialGradient>
      </defs>
      {els}
      <rect x={0} y={0} width={W} height={H} fill="#050302" opacity={0.3} />
    </svg>
  );
};

export const Navio: React.FC<{ cam: Cam; st: NavioState; gente?: React.ReactNode }> = ({ cam, st, gente }) =>
  st.local === "porao" ? <Porao c={cam} st={st} gente={gente} /> : <Conves c={cam} st={st} gente={gente} />;
