import React from "react";

// Motor da fabrica POV: camera olho de peixe (projecao equidistante) desenhada em SVG.
// Mundo em metros: x para a direita, y para cima, z para a frente.
export const W = 1080;
export const H = 1920;
export const CX = W / 2;
export const CY = H * 0.45;

export type V3 = [number, number, number];
export type Cam = { pos: V3; yaw: number; pitch: number; roll: number; f: number };

const TH_MAX = 2.0; // acima disso o ponto esta atras demais da camera

export const lerp3 = (a: V3, b: V3, t: number): V3 => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];

export function proj(p: V3, c: Cam) {
  const x = p[0] - c.pos[0];
  const y = p[1] - c.pos[1];
  const z = p[2] - c.pos[2];
  const cy = Math.cos(c.yaw);
  const sy = Math.sin(c.yaw);
  const x1 = x * cy - z * sy;
  const z1 = x * sy + z * cy;
  const cp = Math.cos(c.pitch);
  const sp = Math.sin(c.pitch);
  const y1 = y * cp - z1 * sp;
  const z2 = y * sp + z1 * cp;
  const cr = Math.cos(c.roll);
  const sr = Math.sin(c.roll);
  const x2 = x1 * cr - y1 * sr;
  const y2 = x1 * sr + y1 * cr;
  const rxy = Math.hypot(x2, y2);
  const th = Math.atan2(rxy, z2);
  const k = rxy < 1e-9 ? 0 : (c.f * th) / rxy;
  return { x: CX + x2 * k, y: CY - y2 * k, th, d: Math.hypot(x2, y2, z2) };
}

const n2 = (v: number) => v.toFixed(1);

// Quadrilatero a,b,c,d (em volta), fatiado em n x m para as bordas curvarem.
export function quad(
  c: Cam,
  key: string,
  a: V3,
  b: V3,
  cc: V3,
  d: V3,
  fill: string,
  n = 6,
  m = 6,
  opacity = 1,
) {
  const P = (u: number, v: number) => lerp3(lerp3(a, b, u), lerp3(d, cc, u), v);
  const g: ReturnType<typeof proj>[][] = [];
  for (let j = 0; j <= m; j++) {
    const row = [];
    for (let i = 0; i <= n; i++) row.push(proj(P(i / n, j / m), c));
    g.push(row);
  }
  const els: React.ReactNode[] = [];
  for (let j = 0; j < m; j++) {
    for (let i = 0; i < n; i++) {
      const q = [g[j][i], g[j][i + 1], g[j + 1][i + 1], g[j + 1][i]];
      const ths = q.map((o) => o.th);
      if (Math.min(...ths) > TH_MAX || Math.max(...ths) > 2.6) continue;
      els.push(
        <path
          key={`${i}-${j}`}
          d={`M${n2(q[0].x)} ${n2(q[0].y)}L${n2(q[1].x)} ${n2(q[1].y)}L${n2(q[2].x)} ${n2(q[2].y)}L${n2(q[3].x)} ${n2(q[3].y)}Z`}
          fill={fill}
          stroke={fill}
          strokeWidth={1.4}
        />,
      );
    }
  }
  return (
    <g key={key} opacity={opacity}>
      {els}
    </g>
  );
}

// Linha reta no mundo, que sai curva na tela.
export function line(c: Cam, key: string, a: V3, b: V3, stroke: string, w: number, segs = 12, opacity = 1) {
  let d = "";
  let pen = false;
  for (let i = 0; i <= segs; i++) {
    const o = proj(lerp3(a, b, i / segs), c);
    if (o.th > TH_MAX) {
      pen = false;
      continue;
    }
    d += `${pen ? "L" : "M"}${n2(o.x)} ${n2(o.y)}`;
    pen = true;
  }
  if (!d) return null;
  return (
    <path key={key} d={d} fill="none" stroke={stroke} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" opacity={opacity} />
  );
}

export function outline(c: Cam, key: string, pts: V3[], stroke: string, w: number, closed = true) {
  const els: React.ReactNode[] = [];
  const n = closed ? pts.length : pts.length - 1;
  for (let i = 0; i < n; i++) els.push(line(c, `${key}-${i}`, pts[i], pts[(i + 1) % pts.length], stroke, w));
  return <g key={key}>{els}</g>;
}

// Linhas de grade dentro de um quadrilatero (piso, forro).
export function grid(c: Cam, key: string, a: V3, b: V3, cc: V3, d: V3, nu: number, nv: number, stroke: string, w: number) {
  const els: React.ReactNode[] = [];
  for (let i = 0; i <= nu; i++) els.push(line(c, `${key}u${i}`, lerp3(a, b, i / nu), lerp3(d, cc, i / nu), stroke, w, 16));
  for (let j = 0; j <= nv; j++) els.push(line(c, `${key}v${j}`, lerp3(a, d, j / nv), lerp3(b, cc, j / nv), stroke, w, 16));
  return <g key={key}>{els}</g>;
}

// Caixa alinhada aos eixos, vista de frente e de cima.
export function box(
  c: Cam,
  key: string,
  mn: V3,
  mx: V3,
  cols: { top: string; front: string; side: string },
  stroke = "#111",
  w = 5,
) {
  const [x0, y0, z0] = mn;
  const [x1, y1, z1] = mx;
  const els: React.ReactNode[] = [];
  const face = (k: string, pts: [V3, V3, V3, V3], fill: string) => {
    els.push(quad(c, `${key}${k}`, pts[0], pts[1], pts[2], pts[3], fill, 3, 3));
    els.push(outline(c, `${key}${k}o`, pts, stroke, w));
  };
  const sideL: [V3, V3, V3, V3] = [[x0, y1, z1], [x0, y1, z0], [x0, y0, z0], [x0, y0, z1]];
  const sideR: [V3, V3, V3, V3] = [[x1, y1, z0], [x1, y1, z1], [x1, y0, z1], [x1, y0, z0]];
  if (c.pos[0] < x0) face("l", sideL, cols.side);
  if (c.pos[0] > x1) face("r", sideR, cols.side);
  face("t", [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], cols.top);
  face("f", [[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]], cols.front);
  return <g key={key}>{els}</g>;
}

// Recorte 2D (personagem, objeto) preso a um ponto do mundo. Desenho em centimetros, y para baixo.
export function bill(c: Cam, key: string, p: V3, children: React.ReactNode, extraScale = 1) {
  const o = proj(p, c);
  if (o.th > 1.85) return null;
  const up = proj([p[0], p[1] + 0.2, p[2]], c);
  const ang = (Math.atan2(up.x - o.x, -(up.y - o.y)) * 180) / Math.PI;
  const s = (c.f / o.d / 100) * extraScale;
  return (
    <g key={key} transform={`translate(${n2(o.x)} ${n2(o.y)}) rotate(${ang.toFixed(2)}) scale(${s.toFixed(4)})`}>
      {children}
    </g>
  );
}
