import React from "react";
import { Tema } from "./Maos";

// Tipos do video de venda do parceiro (molde em src/VendaParceiro.tsx, dados em src/minha_venda_dados.tsx).
// Quadros (inicio, meio...) sao quadros reais do episodio do aluno, ja com o tempo das vozes.
export type EpVenda = { C: React.FC; total: number; inicio: number; meio: number; outro: number; voto: number; fundo: number; grade: number[] };

export type Bloco = {
  tipo: "gancho" | "origem" | "serie" | "views" | "voto" | "sua" | "cta";
  var: string; // so no gancho: seg, views, dias ou serie
  de: number; // inicio da fala no roteiro (s)
  ate: number; // fim previsto da fala no roteiro (s)
  leg: string; // legenda da tela; *palavra* sai em amarelo
  m: { corte?: number; baloes?: number[]; checks?: number[]; palavra?: number; digita?: number; seta?: number };
};

export type DadosVenda = {
  perfil: string;
  serie: string;
  palavra: string;
  seguidores: number | null;
  segAprox: boolean;
  dias: number | null;
  views: number | null;
  viewsAprox: boolean;
  tema: Tema;
  escolhas: string[] | null;
  eps: EpVenda[];
  blocos: Bloco[];
  base: number;
};
