import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

export const fontFamily = "Inter POV";

loadFont({ family: fontFamily, url: staticFile("fontes/inter-latin-800-normal.woff2"), weight: "800" });
loadFont({ family: fontFamily, url: staticFile("fontes/inter-latin-500-normal.woff2"), weight: "500" });
