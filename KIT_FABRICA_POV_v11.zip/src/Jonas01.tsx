import React from "react";
import { AbsoluteFill, Easing, useCurrentFrame } from "remotion";
import { Cam, bill } from "./engine";
import { Navio } from "./Navio";
import { Maos, Pose, TEMA_MARINHEIRO } from "./Maos";
import { EtiquetaDireita, EtiquetaParte, Fala, Legenda } from "./Legenda";
import { Boneco, Expr } from "./Personagens";
import { Escolha } from "./Escolha";
import { EXTRAS } from "./jonas01_vozes";

// Exemplo 2: JONAS, PARTE 1 (A TEMPESTADE). Voce e um marinheiro no barco. Jonas 1:4-13.
export const FPS = 30;
const BASE = 67;
const S = (s: number) => Math.round(s * FPS);
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const ease = (x: number) => Easing.inOut(Easing.cubic)(clamp(x));
const entre = (T: number, a: number, b: number) => T >= a && T < b;

// posicoes no conves
const P_CAP: [number, number, number] = [-1.15, 0, 2.5];
const P_MAR: [number, number, number] = [1.25, 0, 2.1];
const P_JON: [number, number, number] = [0.3, 0, 3.0];
const yawDe = (p: number[]) => Math.atan2(p[0], p[2]);

type Alvo = { t0: number; yaw: number; pitch: number; f: number; dur?: number };
const CAP = { yaw: yawDe(P_CAP), pitch: 0.02, f: 860 };
const MAR = { yaw: yawDe(P_MAR), pitch: 0.02, f: 860 };
const JON = { yaw: yawDe(P_JON), pitch: 0.01, f: 1080 };
const GERAL = { yaw: 0.06, pitch: -0.02, f: 650 };
const CEU = { yaw: 0, pitch: 0.16, f: 620 };
const ALVOS: Alvo[] = [
  { t0: 0, ...CAP },
  { t0: 2.0, ...CEU, dur: 10 },
  { t0: 4.2, ...MAR },
  { t0: 5.4, ...CEU, dur: 10 },
  { t0: 6.8, ...CAP },
  { t0: 9.2, ...MAR },
  { t0: 12.0, ...GERAL },
  { t0: 14.8, ...MAR },
  { t0: 17.0, yaw: -0.25, pitch: -0.4, f: 760, dur: 1 }, // porao: Jonas dormindo
  { t0: 20.2, yaw: 0.46, pitch: 0.02, f: 820 }, // capitao no porao
  { t0: 22.6, yaw: -0.25, pitch: -0.4, f: 900 },
  { t0: 24.8, ...GERAL, dur: 1 },
  { t0: 25.0, ...MAR },
  { t0: 27.6, yaw: 0.05, pitch: -0.5, f: 640 }, // olha os gravetos na mao
  { t0: 29.6, ...JON },
  { t0: 31.2, ...CAP },
  { t0: 34.2, ...JON, f: 1150 },
  { t0: 42.0, ...MAR },
  { t0: 43.6, ...CEU, dur: 10 },
  { t0: 45.0, ...CAP },
  { t0: 49.0, ...JON, f: 1250 },
  { t0: 54.5, yaw: 0.1, pitch: -0.08, f: 660 },
  { t0: 57.0, ...MAR },
  { t0: 59.5, ...CAP },
  { t0: 60.7, ...CEU, dur: 9 },
];

const camAt = (frame: number, Tr: number): Cam => {
  const T = frame / FPS;
  let i = 0;
  for (let k = 0; k < ALVOS.length; k++) if (ALVOS[k].t0 <= T) i = k;
  const a = ALVOS[i];
  const p = i > 0 ? ALVOS[i - 1] : a;
  const k = ease((frame - S(a.t0)) / (a.dur ?? 7));
  const mix = (x: number, y: number) => x + (y - x) * k;
  const porao = entre(T, 17, 24.8);
  // o barco joga: bem mais balanco que a portaria
  const bal = porao ? 0.6 : 1;
  return {
    pos: [0, porao ? 1.5 : 1.55, 0],
    yaw: mix(p.yaw, a.yaw) + 0.015 * Math.sin(Tr * 1.3),
    pitch: mix(p.pitch, a.pitch) + bal * 0.035 * Math.sin(Tr * 0.9 + 0.5),
    roll: bal * (0.075 * Math.sin(Tr * 1.15) + 0.03 * Math.sin(Tr * 2.4)),
    f: mix(p.f, a.f) * (1 + 0.004 * (T - a.t0)),
  };
};

const P = 1280;
const fala = (a: number, b: number, quem: Fala["quem"], texto: string, y?: number): Fala => ({ de: S(a), ate: S(b), quem, texto, y });
const FALAS: Fala[] = [
  fala(0, 1.9, "capitao", "Segura a vela! O vento virou!", P),
  fala(2.0, 4.1, "voce", "De onde veio isso? O céu tava limpo!"),
  fala(4.2, 6.6, "marinheiro", "O barco vai partir no meio!", P),
  fala(6.8, 9.0, "capitao", "Joga a carga no mar! Tudo!", P),
  fala(9.2, 11.8, "marinheiro", "Cada um clama pro seu deus! Agora!", P),
  fala(12.0, 14.6, "voce", "Cadê o passageiro? O que subiu em Jope?"),
  fala(14.8, 16.6, "marinheiro", "Desceu pro porão!", P),
  fala(18.0, 20.0, "voce", "...Ele tá dormindo?", 1320),
  fala(20.2, 24.4, "capitao", "Como você consegue dormir? Levanta e clama ao teu Deus!", P),
  fala(25.0, 29.4, "marinheiro", "Vamos tirar a sorte. Alguém aqui trouxe essa desgraça.", P),
  fala(31.2, 34.0, "capitao", "Quem é você? De onde você vem?", P),
  fala(34.2, 39.4, "jonas", "Sou hebreu. Eu adoro o Senhor, o Deus do céu, que fez o mar e a terra.", P),
  fala(39.6, 41.8, "jonas", "E eu tô fugindo dele.", P),
  fala(42.0, 44.4, "marinheiro", "O que foi que você fez?!", P),
  fala(45.0, 48.6, "capitao", "O que a gente faz com você pro mar acalmar?", P),
  fala(49.0, 54.2, "jonas", "Me joguem no mar. Aí ele acalma. Eu sei que a culpa é minha.", P),
  fala(54.5, 56.8, "voce", "Jogar um homem no mar...?"),
  fala(57.0, 59.2, "marinheiro", "Vamos remar! Ainda dá pra voltar pra terra!", P),
  fala(59.5, 61.6, "capitao", "Decidam logo! O barco não aguenta mais!", P),
];

// tempo elastico (mesma logica do Ep01): o roteiro para no fim da fala ate a voz acabar
const CORTES = FALAS.map((f, i) => ({ b: f.ate / FPS, extra: EXTRAS[i] ?? 0 })).sort((x, y) => x.b - y.b);
export const DUR_JONAS01 = Math.round((BASE + CORTES.reduce((s, c) => s + c.extra, 0)) * FPS);
const tempoAntigo = (Tr: number): number => {
  let acc = 0;
  for (const c of CORTES) {
    if (Tr < c.b + acc) return Tr - acc;
    if (c.extra > 0 && Tr < c.b + acc + c.extra) return c.b - 0.002;
    acc += c.extra;
  }
  return Tr - acc;
};

const RAIOS = [2.0, 4.7, 14.9, 31.0, 42.0, 53.0, 60.8];
const TUN = { calca: "#3a2a1a", cabelo: "#1d1714" };

export const Jonas01: React.FC = () => {
  const quadroReal = useCurrentFrame();
  const Tr = quadroReal / FPS;
  const T = tempoAntigo(Tr);
  const frame = T * FPS;
  const cam = camAt(frame, Tr);
  const porao = entre(T, 17, 24.8);
  const fim = T >= 62;

  const raio = Math.max(...RAIOS.map((r) => (T >= r && T < r + 0.5 ? Math.max(1 - (T - r) / 0.18, T > r + 0.22 ? 0.7 * (1 - (T - r - 0.22) / 0.28) : 0) : 0)));
  const pico = (a: number, b: number, c2: number) => (T < a || T > c2 ? 0 : T < b ? ease((T - a) / (b - a)) : 1 - ease((T - b) / (c2 - b)));
  const onda = Math.max(pico(4.4, 5.9, 7.4), 0.5 * pico(42.6, 44.2, 45.4), pico(60.2, 61.6, 63));

  const gente: React.ReactNode[] = [];
  const falando = (q: string) => FALAS.some((f) => f.quem === q && frame >= f.de && frame < f.ate);
  const boca = (q: string, calmo: Expr, alto: Expr): Expr => (falando(q) && Math.floor(Tr * 7) % 2 === 0 ? alto : calmo);
  if (porao) {
    gente.push(
      bill(cam, "jonas-d", [-0.55, 0.42, 2.55], (
        <g transform="rotate(-82) translate(-20 60)">
          <Boneco camisa="#7c8a6a" {...TUN} pele="#c69a72" expr={T >= 23.2 ? "susto" : "dormindo"} t={Tr} tunica barba="#2a2019" />
        </g>
      )),
    );
    if (T >= 20.1)
      gente.push(
        bill(cam, "cap-p", [0.9, 0, 1.9], (
          <Boneco camisa="#8c3b2c" {...TUN} pele="#a9764a" expr={boca("capitao", "serio", "grito")} t={Tr} tunica barba="#3a3a3a" faixa="#d9c27a" mao={1} />
        )),
      );
  } else {
    gente.push(
      bill(cam, "cap", P_CAP, (
        <Boneco camisa="#8c3b2c" {...TUN} pele="#a9764a" expr={boca("capitao", "serio", "grito")} t={Tr} tunica barba="#3a3a3a" faixa="#d9c27a" mao={falando("capitao") ? 1 : 0} />
      )),
    );
    gente.push(
      bill(cam, "mar", P_MAR, (
        <Boneco camisa="#4f6f7a" {...TUN} pele="#8a5a36" expr={boca("marinheiro", "susto", "grito")} t={Tr} tunica molhado />
      )),
    );
    if (T >= 24.8)
      gente.push(
        bill(cam, "jonas", P_JON, (
          <Boneco camisa="#7c8a6a" {...TUN} pele="#c69a72" expr={boca("jonas", "serio", "neutro")} t={Tr} tunica barba="#2a2019" />
        )),
      );
  }

  // maos: segurando a corda da vela; no sorteio, a direita mostra os gravetos
  const bob = 14 * Math.sin(Tr * 1.5);
  const sorteio = entre(T, 27.4, 31.0);
  const esq: Pose = { x: 250, y: 1640 + bob, rot: 14, s: 1.2 };
  const dir: Pose = sorteio ? { x: 700, y: 1500 + bob * 0.5, rot: -6, s: 1.3 } : { x: 840, y: 1600 - bob, rot: -14, s: 1.2 };

  // chuva em diagonal (espaco de tela)
  const gotas: React.ReactNode[] = [];
  if (!porao && !fim)
    for (let i = 0; i < 70; i++) {
      const x0 = (i * 173.3) % 1300 - 110;
      const v = 2300 + (i % 7) * 260;
      const y = ((Tr * v + i * 311.7) % 2200) - 140;
      gotas.push(<line key={i} x1={x0 + y * 0.22} y1={y} x2={x0 + y * 0.22 + 20} y2={y + 92} stroke="#cfe4ff" strokeWidth={3} opacity={0.22 + (i % 3) * 0.08} />);
    }
  const tremor = onda > 0.6 ? 9 * Math.sin(Tr * 41) : 0;
  const cartaSorte = entre(T, 29.6, 31.1) ? ease((T - 29.6) / 0.15) : 0;

  return (
    <AbsoluteFill style={{ backgroundColor: "#0a0f1c" }}>
      <AbsoluteFill style={{ transform: `translate(${tremor}px, ${tremor * 0.5}px)` }}>
        <Navio cam={cam} st={{ t: Tr, raio, onda, carga: T < 8.3, local: porao ? "porao" : "conves" }} gente={gente} />
        {fim ? null : (
          <Maos esq={porao ? null : esq} dir={porao ? null : dir} tema={TEMA_MARINHEIRO} esqPunho objetoDir={sorteio ? "gravetos" : "punho"} corda={!sorteio && !porao} />
        )}
      </AbsoluteFill>
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
        {gotas}
      </svg>
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 75% 62% at 50% 45%, rgba(0,0,0,0) 40%, rgba(3,5,14,0.85) 100%)" }} />
      {cartaSorte > 0 ? (
        <div
          style={{
            position: "absolute",
            left: 60,
            width: 960,
            top: 330,
            textAlign: "center",
            fontFamily: "Inter POV",
            fontWeight: 800,
            fontSize: 96,
            lineHeight: 1.05,
            color: "#ffd83d",
            WebkitTextStroke: "20px #0d0c0a",
            paintOrder: "stroke fill",
            opacity: cartaSorte,
            transform: `scale(${0.7 + 0.3 * cartaSorte})`,
          }}
        >
          A SORTE CAIU EM JONAS.
        </div>
      ) : null}
      {fim ? null : <EtiquetaParte n={1} />}
      {fim ? null : (
        <EtiquetaDireita borda="#c9a66b">📖 JONAS 1</EtiquetaDireita>
      )}
      <Legenda falas={FALAS} quadro={frame} />
      <Escolha q={Math.round(frame - S(62))} dur={S(5)} a="JOGAR" b="REMAR" sa="Jonas no mar, como ele pediu" sb="tentar voltar pra terra" ia="🌊" ib="🚣" rodape="Na PARTE 2: o que a Bíblia conta" />
    </AbsoluteFill>
  );
};
