import React from "react";
import { Cam, V3, W, H, bill, box, grid, lerp3, line, outline, quad } from "./engine";

// Cenario: portaria de predio a noite. Camera sentada atras da bancada, olhando para a porta de vidro.
const X0 = -2.3;
const X1 = 2.3;
const Z0 = -1.0;
const Z1 = 3.0;
const YT = 2.7;
const DX = 1.15; // meia largura da porta
const DY = 2.3; // altura da porta
const INK = "#15130f";

export type PortariaState = {
  ledOn: boolean; // luz do interfone
  poste: number; // 0 a 1, brilho do poste
  luz: number; // 0 a 1, luz interna
  chamando: number; // 0 a 1, selo "804 chamando"
  t: number; // segundos
};

export const Portaria: React.FC<{ cam: Cam; st: PortariaState; fora?: React.ReactNode }> = ({ cam: c, st, fora }) => {
  const els: React.ReactNode[] = [];
  const push = (e: React.ReactNode) => els.push(e);

  // 1. Rua
  push(<rect key="ceu" x={0} y={0} width={W} height={H} fill="#060a18" />);
  push(bill(c, "lua", [-0.9, 4.75, 12], <g><circle r={150} fill="url(#halo)" opacity={0.55} /><circle r={46} fill="#f6f2d2" /><circle cx={-12} cy={-10} r={9} fill="#dcd7b4" /><circle cx={16} cy={12} r={6} fill="#dcd7b4" /></g>));
  [[-2.6, 5.1], [1.9, 5.4], [0.6, 4.6], [-1.9, 4.2], [2.9, 4.3], [-3.4, 4.5]].forEach(([x, y], i) => push(bill(c, `est${i}`, [x, y, 12], <circle r={7} fill="#fff" opacity={0.9} />)));
  push(quad(c, "predio", [-8, 3.6, 10], [8, 3.6, 10], [8, 0, 10], [-8, 0, 10], "#111a3a", 8, 4));
  const jan: [number, number, boolean][] = [];
  for (let r = 0; r < 2; r++) for (let k = 0; k < 7; k++) jan.push([-5.4 + k * 1.8, 0.9 + r * 1.3, (r * 7 + k * 3) % 4 === 0 || (k === 3 && r === 1)]);
  jan.forEach(([x, y, on], i) =>
    push(quad(c, `jan${i}`, [x, y + 0.9, 9.98], [x + 0.8, y + 0.9, 9.98], [x + 0.8, y, 9.98], [x, y, 9.98], on ? "#f0c14a" : "#1c2a58", 1, 1)),
  );
  push(quad(c, "asfalto", [-8, 0, 10], [8, 0, 10], [8, 0, 5.4], [-8, 0, 5.4], "#161a25", 8, 4));
  push(quad(c, "calcada", [-8, 0, 5.4], [8, 0, 5.4], [8, 0, Z1], [-8, 0, Z1], "#4a5163", 8, 3));
  push(line(c, "meiofio", [-8, 0.01, 5.4], [8, 0.01, 5.4], "#0b0d14", 7, 20));
  for (let i = 0; i < 9; i++) push(line(c, `faixa${i}`, [-4.2 + i, 0.01, 7.4], [-3.7 + i, 0.01, 7.4], "#d9b648", 5, 2));
  push(quad(c, "cone", [0.1, 3.1, 5.0], [0.3, 3.1, 5.0], [1.5, 0.02, 4.7], [-1.3, 0.02, 4.7], "#f0c14a", 2, 4, 0.13 * st.poste));
  push(grid(c, "calc-g", [-8, 0.01, 5.4], [8, 0.01, 5.4], [8, 0.01, Z1], [-8, 0.01, Z1], 16, 2, "#353b4b", 2.5));
  // poste
  push(line(c, "poste", [0.75, 0, 5.0], [0.75, 3.1, 5.0], "#2c3346", 13));
  push(line(c, "poste-b", [0.75, 3.1, 5.0], [0.2, 3.2, 5.0], "#2c3346", 11));
  push(
    bill(c, "poste-luz", [0.2, 3.12, 5.0], (
      <g opacity={st.poste}>
        <circle r={150} fill="url(#halo)" />
        <ellipse rx={26} ry={14} fill="#fff3c4" />
      </g>
    )),
  );
  push(
    bill(c, "poste-chao", [0.1, 0.02, 4.6], <ellipse rx={230} ry={46} fill="#f0c14a" opacity={0.34 * st.poste} />),
  );

  if (fora) push(<g key="fora">{fora}</g>);

  // 2. Piso e forro
  push(quad(c, "piso", [X0, 0, Z1], [X1, 0, Z1], [X1, 0, Z0], [X0, 0, Z0], "#555a68", 8, 8));
  push(grid(c, "piso-g", [X0, 0, Z1], [X1, 0, Z1], [X1, 0, Z0], [X0, 0, Z0], 8, 8, "#3b3f4b", 3));
  push(quad(c, "forro", [X0, YT, Z0], [X1, YT, Z0], [X1, YT, Z1], [X0, YT, Z1], "#80849b", 8, 8));
  push(grid(c, "forro-g", [X0, YT, Z0], [X1, YT, Z0], [X1, YT, Z1], [X0, YT, Z1], 6, 6, "#63677d", 2.5));
  const lamp: V3[] = [[-0.85, YT - 0.03, 1.15], [0.85, YT - 0.03, 1.15], [0.85, YT - 0.03, 1.55], [-0.85, YT - 0.03, 1.55]];
  push(quad(c, "lamp", lamp[0], lamp[1], lamp[2], lamp[3], st.luz > 0.5 ? "#dbe4ff" : "#5d6074", 4, 2));
  push(outline(c, "lamp-o", lamp, INK, 5));

  // 3. Paredes laterais (faixa de baixo verde, como predio antigo)
  const parede = (k: string, x: number) => {
    push(quad(c, `${k}a`, [x, YT, Z0], [x, YT, Z1], [x, 1.0, Z1], [x, 1.0, Z0], "#787c90", 8, 5));
    push(quad(c, `${k}b`, [x, 1.0, Z0], [x, 1.0, Z1], [x, 0, Z1], [x, 0, Z0], "#2f565c", 8, 3));
    push(line(c, `${k}f`, [x, 1.0, Z0], [x, 1.0, Z1], INK, 4, 20));
    push(line(c, `${k}c`, [x, 0, Z0], [x, 0, Z1], INK, 6, 20));
    push(line(c, `${k}t`, [x, YT, Z0], [x, YT, Z1], INK, 6, 20));
  };
  parede("pe", X0);
  parede("pd", X1);
  // quadro de chaves (esquerda)
  const qx = X0 + 0.02;
  const chaves: V3[] = [[qx, 1.95, 1.5], [qx, 1.95, 2.5], [qx, 1.3, 2.5], [qx, 1.3, 1.5]];
  push(quad(c, "chaves", chaves[0], chaves[1], chaves[2], chaves[3], "#2c3833", 3, 2));
  push(outline(c, "chaves-o", chaves, INK, 5));
  for (let i = 0; i < 4; i++)
    for (let j = 0; j < 2; j++)
      push(line(c, `ch${i}${j}`, [qx + 0.01, 1.8 - j * 0.28, 1.65 + i * 0.24], [qx + 0.01, 1.68 - j * 0.28, 1.65 + i * 0.24], "#e7c65a", 5, 2));
  // mural (direita)
  const mx = X1 - 0.02;
  const mural: V3[] = [[mx, 1.95, 2.6], [mx, 1.95, 1.5], [mx, 1.25, 1.5], [mx, 1.25, 2.6]];
  push(quad(c, "mural", mural[0], mural[1], mural[2], mural[3], "#84704f", 3, 2));
  push(outline(c, "mural-o", mural, INK, 5));
  const papel = (k: string, z: number, y: number, cor: string) => {
    const p: V3[] = [[mx - 0.01, y + 0.3, z + 0.26], [mx - 0.01, y + 0.3, z], [mx - 0.01, y, z], [mx - 0.01, y, z + 0.26]];
    push(quad(c, k, p[0], p[1], p[2], p[3], cor, 1, 1));
    push(outline(c, `${k}o`, p, INK, 3));
  };
  papel("pp1", 1.6, 1.55, "#d2cfc5");
  papel("pp2", 1.95, 1.4, "#cfb24a");
  papel("pp3", 2.28, 1.58, "#d2cfc5");

  // 4. Parede da frente, em volta da porta
  const frente = (k: string, xa: number, xb: number, ya: number, yb: number, cor: string, n: number) =>
    push(quad(c, k, [xa, yb, Z1], [xb, yb, Z1], [xb, ya, Z1], [xa, ya, Z1], cor, n, 3));
  frente("fe-a", X0, -DX, 1.0, YT, "#787c90", 4);
  frente("fe-b", X0, -DX, 0, 1.0, "#2f565c", 4);
  frente("fd-a", DX, X1, 1.0, YT, "#787c90", 4);
  frente("fd-b", DX, X1, 0, 1.0, "#2f565c", 4);
  frente("ft", -DX, DX, DY, YT, "#787c90", 4);
  push(line(c, "ff1", [X0, 1.0, Z1], [-DX, 1.0, Z1], INK, 4));
  push(line(c, "ff2", [DX, 1.0, Z1], [X1, 1.0, Z1], INK, 4));
  push(line(c, "fc1", [X0, 0, Z1], [X1, 0, Z1], INK, 6, 20));
  push(line(c, "fc2", [X0, YT, Z1], [X1, YT, Z1], INK, 6, 20));
  push(line(c, "ke", [X0, 0, Z1], [X0, YT, Z1], INK, 6));
  push(line(c, "kd", [X1, 0, Z1], [X1, YT, Z1], INK, 6));
  // vidro e esquadria
  push(quad(c, "vidro", [-DX, DY, Z1], [DX, DY, Z1], [DX, 0, Z1], [-DX, 0, Z1], "#9fd3ff", 4, 4, 0.1));
  push(outline(c, "esq", [[-DX, DY, Z1], [DX, DY, Z1], [DX, 0, Z1], [-DX, 0, Z1]], "#22252b", 13));
  push(line(c, "esq-m", [0, DY, Z1], [0, 0, Z1], "#22252b", 10));
  push(line(c, "pux1", [-0.12, 1.25, Z1 - 0.03], [-0.12, 0.85, Z1 - 0.03], "#c9ccd2", 8, 3));
  push(line(c, "pux2", [0.12, 1.25, Z1 - 0.03], [0.12, 0.85, Z1 - 0.03], "#c9ccd2", 8, 3));
  // relogio acima da porta
  push(
    bill(c, "relogio", [1.72, 2.05, Z1 - 0.02], (
      <g>
        <circle r={15} fill="#d2cfc5" stroke={INK} strokeWidth={2.4} />
        <line x1={0} y1={0} x2={0} y2={-11} stroke={INK} strokeWidth={2} strokeLinecap="round" />
        <line x1={0} y1={0} x2={3} y2={-7} stroke={INK} strokeWidth={2.4} strokeLinecap="round" />
      </g>
    )),
  );

  // 5. Bancada
  const BY = 0.8;
  const tampo: V3[] = [[-1.7, BY, 1.04], [1.7, BY, 1.04], [1.7, BY, -0.6], [-1.7, BY, -0.6]];
  push(quad(c, "tampo", tampo[0], tampo[1], tampo[2], tampo[3], "#85593a", 10, 10));
  for (let i = 1; i < 9; i++) push(line(c, `veio${i}`, [-1.7, BY + 0.002, -0.6 + i * 0.182], [1.7, BY + 0.002, -0.6 + i * 0.182], "#6b4429", 2.5, 24));
  push(outline(c, "tampo-o", tampo, INK, 7));

  // livro de registro
  const lv: V3[] = [[-0.3, BY + 0.01, 0.84], [0.2, BY + 0.01, 0.84], [0.2, BY + 0.01, 0.5], [-0.3, BY + 0.01, 0.5]];
  push(quad(c, "capa", [-0.34, BY + 0.005, 0.87], [0.24, BY + 0.005, 0.87], [0.24, BY + 0.005, 0.47], [-0.34, BY + 0.005, 0.47], "#1d2f55", 2, 2));
  push(outline(c, "capa-o", [[-0.34, BY + 0.005, 0.87], [0.24, BY + 0.005, 0.87], [0.24, BY + 0.005, 0.47], [-0.34, BY + 0.005, 0.47]], INK, 5));
  push(line(c, "lombada", [-0.05, BY + 0.012, 0.84], [-0.05, BY + 0.012, 0.5], "#8d8a80", 3, 3));
  push(quad(c, "livro", lv[0], lv[1], lv[2], lv[3], "#dedbd0", 3, 3));
  for (let i = 1; i < 6; i++) push(line(c, `lvl${i}`, lerp3(lv[0], lv[3], i / 6), lerp3(lv[1], lv[2], i / 6), "#a9b4c4", 2, 4));
  push(outline(c, "livro-o", lv, INK, 5));
  push(line(c, "caneta", [0.26, BY + 0.02, 0.8], [0.34, BY + 0.02, 0.55], "#1f4fa3", 7, 2));

  // caneca
  push(
    bill(c, "caneca", [-0.52, BY, 0.62], (
      <g>
        <path d="M-5 -11 h10 v9 a3 3 0 0 1 -3 3 h-4 a3 3 0 0 1 -3 -3 z" fill="#e8e3d5" stroke={INK} strokeWidth={1.3} strokeLinejoin="round" />
        <path d="M5 -9 q5 1 0 6" fill="none" stroke={INK} strokeWidth={1.3} />
        <ellipse cx={0} cy={-11} rx={5} ry={1.6} fill="#3a2414" stroke={INK} strokeWidth={1} />
      </g>
    )),
  );

  // monitor das cameras (esquerda), virado para a camera
  const mTL: V3 = [-1.2, 1.34, 0.99];
  const mTR: V3 = [-0.5, 1.34, 0.77];
  const mBR: V3 = [-0.5, 0.88, 0.77];
  const mBL: V3 = [-1.2, 0.88, 0.99];
  const M = (u: number, v: number): V3 => lerp3(lerp3(mTL, mTR, u), lerp3(mBL, mBR, u), v);
  push(line(c, "mon-pe", [-0.85, 0.88, 0.88], [-0.85, BY, 0.88], INK, 16, 2));
  push(quad(c, "mon", mTL, mTR, mBR, mBL, "#1b1b20", 3, 3));
  push(outline(c, "mon-o", [mTL, mTR, mBR, mBL], INK, 6));
  const cams = ["#28384a", "#33423a", "#3d3a2c", "#2b2b3a"];
  cams.forEach((cor, i) => {
    const u0 = 0.06 + (i % 2) * 0.45;
    const v0 = 0.08 + Math.floor(i / 2) * 0.44;
    push(quad(c, `cam${i}`, M(u0, v0), M(u0 + 0.43, v0), M(u0 + 0.43, v0 + 0.4), M(u0, v0 + 0.4), cor, 2, 2));
    push(line(c, `cam${i}l`, M(u0 + 0.1, v0 + 0.4), M(u0 + 0.2, v0 + 0.12), "#8ea3b8", 2, 2, 0.6));
    push(line(c, `cam${i}r`, M(u0 + 0.33, v0 + 0.4), M(u0 + 0.24, v0 + 0.12), "#8ea3b8", 2, 2, 0.6));
  });
  push(bill(c, "mon-rec", M(0.9, 0.12), <circle r={1.3} fill="#ff2a2a" />));
  push(bill(c, "mon-glow", M(0.5, 0.5), <circle r={62} fill="url(#haloC)" />));

  // interfone (direita)
  push(box(c, "interf", [0.3, BY, 0.44], [0.86, BY + 0.11, 0.9], { top: "#34343b", front: "#232328", side: "#1c1c20" }, INK, 5));
  const IY = BY + 0.112;
  for (let r = 0; r < 4; r++)
    for (let k = 0; k < 3; k++) {
      const x = 0.58 + k * 0.085;
      const z = 0.5 + r * 0.07;
      push(quad(c, `tk${r}${k}`, [x, IY, z + 0.05], [x + 0.06, IY, z + 0.05], [x + 0.06, IY, z], [x, IY, z], "#8b8d96", 1, 1));
    }
  const visor: V3[] = [[0.56, IY, 0.88], [0.83, IY, 0.88], [0.83, IY, 0.79], [0.56, IY, 0.79]];
  push(quad(c, "visor", visor[0], visor[1], visor[2], visor[3], st.ledOn ? "#ffd9d0" : "#7fd08a", 1, 1));
  push(outline(c, "visor-o", visor, INK, 2.5));
  push(
    bill(c, "visor-t", [0.695, IY + 0.002, 0.81], (
      <text x={0} y={1.2} fontSize={5.6} fontWeight={800} textAnchor="middle" fill="#14110c" fontFamily="Inter POV, Arial, sans-serif">
        804
      </text>
    )),
  );
  // berco do fone (vazio, o fone esta na mao)
  push(quad(c, "berco", [0.33, IY, 0.88], [0.5, IY, 0.88], [0.5, IY, 0.46], [0.33, IY, 0.46], "#15151a", 1, 2));
  // LED
  push(
    bill(c, "led", [0.54, IY + 0.01, 0.74], (
      <g>
        {st.ledOn ? <circle r={16} fill="url(#haloR)" /> : null}
        <circle r={2.4} fill={st.ledOn ? "#ff2a2a" : "#5a1414"} stroke={INK} strokeWidth={0.5} />
      </g>
    )),
  );

  if (st.chamando > 0.01) {
    const pulso = 1 + 0.06 * Math.sin(st.t * 30);
    push(
      bill(c, "selo", [0.58, 1.2, 0.67], (
        <g opacity={st.chamando} transform={`scale(${pulso})`}>
          <path d="M-4 5 L0 13 L4 5 Z" fill="#e0241b" stroke={INK} strokeWidth={1.1} strokeLinejoin="round" />
          <rect x={-27} y={-7} width={54} height={13} rx={6.5} fill="#e0241b" stroke={INK} strokeWidth={1.1} />
          <text x={0} y={2.6} fontSize={6.4} fontWeight={800} textAnchor="middle" fill="#fff" fontFamily="Inter POV, Arial, sans-serif">
            804 CHAMANDO
          </text>
        </g>
      )),
    );
  }

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="halo">
          <stop offset="0%" stopColor="#ffe9a6" stopOpacity={0.85} />
          <stop offset="35%" stopColor="#f0c14a" stopOpacity={0.3} />
          <stop offset="100%" stopColor="#f0c14a" stopOpacity={0} />
        </radialGradient>
        <radialGradient id="haloC">
          <stop offset="0%" stopColor="#7fd6ff" stopOpacity={0.3} />
          <stop offset="100%" stopColor="#7fd6ff" stopOpacity={0} />
        </radialGradient>
        <radialGradient id="haloR">
          <stop offset="0%" stopColor="#ff5a4a" stopOpacity={0.9} />
          <stop offset="100%" stopColor="#ff2a2a" stopOpacity={0} />
        </radialGradient>
      </defs>
      {els}
      {/* luz interna: escurece tudo quando a lampada falha */}
      <rect x={0} y={0} width={W} height={H} fill="#060914" opacity={0.42 * (1 - st.luz)} />
    </svg>
  );
};
