import React from "react";
import { fontFamily } from "./fontes";

// Tela final: voto de UMA palavra. q = quadros desde o inicio, dur = duracao.
// Os textos ficam dentro da zona segura: caixa de 900 px centrada, 90 px de cada lado (80 px de margem mais o contorno).
const pop = (q: number, de: number) => {
  const x = Math.max(0, Math.min(1, (q - de) / 5));
  return 1 - Math.pow(1 - x, 3);
};

const Botao: React.FC<{ cor: string; icone: string; palavra: string; sub: string; p: number; top: number }> = ({ cor, icone, palavra, sub, p, top }) => (
  <div
    style={{
      position: "absolute",
      left: 100,
      width: 880,
      top,
      transform: `scale(${0.6 + 0.4 * p})`,
      opacity: p,
      background: cor,
      border: "9px solid #0d0c0a",
      borderRadius: 60,
      boxShadow: "0 12px 0 rgba(0,0,0,0.55)",
      padding: "22px 34px 28px",
      boxSizing: "border-box",
      display: "flex",
      alignItems: "center",
      gap: 26,
      color: "#fff",
      fontFamily,
    }}
  >
    <span style={{ fontSize: 96 }}>{icone}</span>
    <span>
      <div style={{ fontWeight: 800, fontSize: 104, lineHeight: 1 }}>{palavra}</div>
      <div style={{ fontWeight: 500, fontSize: 42, opacity: 0.92, marginTop: 4 }}>{sub}</div>
    </span>
  </div>
);

export const Escolha: React.FC<{ q: number; dur: number; a: string; b: string; sa: string; sb: string; ia: string; ib: string; rodape?: string }> = ({ q, dur, a, b, sa, sb, ia, ib, rodape = "A mais votada decide a PARTE 2" }) => {
  if (q < 0) return null;
  const resto = Math.max(0, 1 - q / dur);
  const seg = Math.ceil((dur - q) / 30);
  const titulo: React.CSSProperties = {
    position: "absolute",
    left: 90,
    width: 900,
    textAlign: "center",
    fontFamily,
    fontWeight: 800,
    WebkitTextStroke: "20px #0d0c0a",
    paintOrder: "stroke fill",
  };
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <div style={{ position: "absolute", inset: 0, background: "rgba(4,6,16,0.8)", opacity: Math.min(1, q / 4) }} />
      <div style={{ ...titulo, top: 300, fontSize: 112, lineHeight: 1.0, color: "#fff", transform: `scale(${0.6 + 0.4 * pop(q, 0)})`, opacity: pop(q, 0) }}>O QUE VOCÊ FARIA?</div>
      <div style={{ ...titulo, top: 572, fontSize: 62, color: "#ffd83d", opacity: pop(q, 4), transform: `translateY(${5 * Math.sin(q / 5)}px)` }}>COMENTA UMA PALAVRA 👇</div>
      <Botao cor="#e0241b" icone={ia} palavra={a} sub={sa} p={pop(q, 7)} top={710} />
      <Botao cor="#1f6fe0" icone={ib} palavra={b} sub={sb} p={pop(q, 11)} top={960} />
      <div style={{ position: "absolute", left: 100, top: 1225, width: 880, height: 34, borderRadius: 17, background: "#0d0c0a", opacity: pop(q, 14) }}>
        <div style={{ width: `${resto * 100}%`, height: "100%", borderRadius: 17, background: seg <= 2 ? "#ff3b2f" : "#ffd83d" }} />
      </div>
      <div style={{ ...titulo, top: 1300, fontSize: 52, color: "#fff", WebkitTextStroke: "14px #0d0c0a", opacity: pop(q, 16) }}>{rodape}</div>
    </div>
  );
};
