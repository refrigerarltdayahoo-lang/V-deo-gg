import React, { createContext, useContext } from "react";
import { AbsoluteFill, Easing, Sequence, interpolate, useCurrentFrame } from "remotion";
import { fontFamily } from "./fontes";
import { Tema } from "./Maos";
import { DADOS } from "./minha_venda_dados";
import { EXTRAS } from "./minha_venda_vozes";
import { EpVenda } from "./venda_tipos";

// Molde do Reel de venda do parceiro (composicao MinhaVenda). NAO EDITE este arquivo: os dados (numeros reais,
// palavra, episodios do aluno, tempos) vem de src/minha_venda_dados.tsx, gerado por parceiro/parceiro.py video.
// Os trechos da serie sao o proprio componente do episodio do aluno, mostrado no quadro certo.
// Zona segura: nenhum texto com base abaixo de y 1490 nem a menos de 60 px das laterais.
// modoTexto (so para conferencia): desenha so os textos sobre fundo preto, para medir a zona segura por pixel.

export const FPS = 30;
const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const OUT = Easing.out(Easing.cubic);
const ent = (t: number, a: number, d = 0.25) => interpolate(t, [a, a + d], [0, 1], { ...CL, easing: OUT });
const rola = (t: number, a: number, b: number, de: number, ate: number) => interpolate(t, [a, b], [de, ate], { ...CL, easing: Easing.out(Easing.quad) });

const INK = "#0d0c0a";
const AMARELO = "#ffd21f";
const VERMELHO = "#ff4a36";
const VERDE = "#2fd47f";
const AZUL = "#4fd8ff";
const SW = 9;
const F = `"${fontFamily}", "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
const EMO = `"Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
const BASE_LEG = 1440; // base da legenda (fim da ultima linha), com folga sobre o limite de 1490

// ---------------- tempo elastico: cada fala dura o que a voz durar (EXTRAS vem do ep_audio.py prep) ----------------
const BL = DADOS.blocos;
const CORTES = BL.map((b, i) => ({ b: b.ate, extra: EXTRAS[i] ?? 0 }));
const W = (t: number) => t + CORTES.reduce((s, c) => s + (c.b <= t ? c.extra : 0), 0);
export const DUR_VENDA = Math.max(FPS, Math.round(W(DADOS.base) * FPS));
const INI = BL.map((b) => W(b.de));
const FIM_FALA = BL.map((b) => W(b.ate));

// ---------------- numeros ----------------
const fmtInt = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
// do jeito que o Instagram mostra, sempre para baixo: 9.874 / 12,4 mil / 268 mil / 1,2 mi
const fmtIG = (n: number) => {
  if (n < 10000) return fmtInt(n);
  if (n < 1e6) {
    const v = Math.floor(n / 100) / 10;
    return `${v >= 100 || Number.isInteger(v) ? Math.floor(v) : v.toFixed(1).replace(".", ",")} mil`;
  }
  const v = Math.floor(n / 1e5) / 10;
  return `${Number.isInteger(v) ? v : v.toFixed(1).replace(".", ",")} mi`;
};
const fmtSeg = (n: number) => fmtIG(n);
const fmtViews = (n: number) => (DADOS.viewsAprox || n >= 1e7 ? fmtIG(n) : fmtInt(n));
const diasTxt = (d: number) => `${d} ${d === 1 ? "DIA" : "DIAS"}`;

const ModoTexto = createContext(false);

// ---------------- episodio do aluno, mostrado num quadro escolhido ----------------
// Uma Sequence com inicio negativo faz o episodio "ver" o quadro pedido. (Freeze nao serve: o quadro dele fica
// preso na duracao deste video, e o episodio e bem mais longo.)
const EpQuadro: React.FC<{ ep: EpVenda; q: number }> = ({ ep, q }) => {
  const agora = useCurrentFrame();
  const C = ep.C;
  const quadro = Math.max(0, Math.min(ep.total - 1, Math.round(q)));
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, overflow: "hidden" }}>
      <Sequence from={agora - quadro} layout="none">
        <C />
      </Sequence>
    </div>
  );
};
const EP0 = DADOS.eps[0];
const EP_ULT = DADOS.eps[DADOS.eps.length - 1];

// fundo: o cenario da serie desfocado
const Fundo: React.FC<{ t: number; brilho?: number }> = ({ t, brilho = 0.42 }) => {
  if (useContext(ModoTexto)) return null;
  return (
    <AbsoluteFill style={{ background: "#05060e", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, transform: `translateX(${10 * Math.sin(t * 0.7)}px) scale(${1.12 + 0.006 * t})`, filter: `blur(8px) brightness(${brilho}) saturate(0.85)` }}>
        <EpQuadro ep={EP0} q={EP0.fundo} />
      </div>
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 45%, rgba(28,36,92,0.18) 0%, rgba(5,6,14,0.45) 60%, rgba(5,6,14,0.85) 100%)" }} />
    </AbsoluteFill>
  );
};

// ---------------- celular em pe nas maos do personagem (as cores das maos sao as da serie) ----------------
const PX = 250;
const PY = 300;
const PW = 580;
const PH = 1010;
const TW = PW - 52;
const TH = PH - 52;

const MaoAtras: React.FC<{ c: Tema }> = ({ c }) => (
  <g>
    <path d="M70 1265 L318 1318 L210 1960 L-190 1960 Z" fill={c.manga} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
    <path d="M150 1420 L40 1900" stroke={c.mangaS} strokeWidth={8} strokeLinecap="round" />
    <g transform="rotate(12 200 1300)">
      <rect x={92} y={1262} width={226} height={58} rx={20} fill={c.mangaS} stroke={INK} strokeWidth={SW} />
    </g>
    <rect x={138} y={1040} width={170} height={262} rx={70} fill={c.pele} stroke={INK} strokeWidth={SW} />
    <rect x={150} y={905} width={104} height={74} rx={37} fill={c.pele} stroke={INK} strokeWidth={SW} />
    <rect x={146} y={968} width={108} height={76} rx={38} fill={c.pele} stroke={INK} strokeWidth={SW} />
  </g>
);

const MaoFrente: React.FC<{ c: Tema }> = ({ c }) => (
  <g transform="translate(258 1262) rotate(9)">
    <rect x={-45} y={-200} width={90} height={232} rx={45} fill={c.pele} stroke={INK} strokeWidth={SW} />
    <rect x={-22} y={-184} width={44} height={46} rx={18} fill={c.unha} />
    <path d="M-20 -70 q20 10 40 0" fill="none" stroke={c.peleS} strokeWidth={6} strokeLinecap="round" />
  </g>
);

const Celular: React.FC<{ t: number; tremor?: number; escuro?: number; children: React.ReactNode }> = ({ t, tremor = 0, escuro = 1, children }) => {
  if (useContext(ModoTexto)) return null;
  const c = DADOS.tema;
  const dx = tremor * Math.sin(t * 2 * Math.PI * 27);
  const dy = tremor * 0.6 * Math.cos(t * 2 * Math.PI * 23);
  const rot = -1.6 + 0.7 * Math.sin(t * 1.3) + tremor * 0.06 * Math.sin(t * 2 * Math.PI * 19);
  const by = 6 * Math.sin(t * 1.1);
  return (
    <div style={{ position: "absolute", inset: 0, transform: "scale(0.92)", transformOrigin: "540px 1920px", filter: escuro < 1 ? `brightness(${escuro})` : undefined }}>
      <div style={{ position: "absolute", inset: 0, transform: `translate(${dx}px, ${dy + by}px) rotate(${rot}deg)`, transformOrigin: `540px ${PY + PH * 0.8}px` }}>
        <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
          <MaoAtras c={c} />
          <g transform="translate(1080 0) scale(-1 1)">
            <MaoAtras c={c} />
          </g>
        </svg>
        <div style={{ position: "absolute", left: PX, top: PY, width: PW, height: PH, background: "#141416", borderRadius: 72, border: `10px solid ${INK}`, boxShadow: "0 26px 0 rgba(0,0,0,0.5)", padding: 16, boxSizing: "border-box" }}>
          <div style={{ width: TW, height: TH, borderRadius: 54, overflow: "hidden", background: "#0b0c12", position: "relative", fontFamily: F }}>
            {children}
            <div style={{ position: "absolute", left: TW / 2 - 70, top: 14, width: 140, height: 38, borderRadius: 19, background: "#000" }} />
          </div>
        </div>
        <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
          <MaoFrente c={c} />
          <g transform="translate(1080 0) scale(-1 1)">
            <MaoFrente c={c} />
          </g>
        </svg>
      </div>
    </div>
  );
};

// tela do celular: o episodio tocando
const TelaEp: React.FC<{ ep: EpVenda; q: number }> = ({ ep, q }) => {
  const s = TW / 1080;
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <div style={{ position: "absolute", left: 0, top: (TH - 1920 * s) / 2, width: 1080, height: 1920, transform: `scale(${s})`, transformOrigin: "0 0" }}>
        <EpQuadro ep={ep} q={q} />
      </div>
    </AbsoluteFill>
  );
};

// tela do celular: o perfil do aluno (so o numero que ele informou; posts e seguindo nao aparecem)
const Miniatura: React.FC<{ ep: EpVenda; q: number; w: number; h: number; zoom?: number }> = ({ ep, q, w, h, zoom = 1 }) => {
  const s = (w / 1080) * zoom;
  return (
    <div style={{ position: "relative", width: w, height: h, overflow: "hidden", background: "#222" }}>
      <div style={{ position: "absolute", left: (w - 1080 * s) / 2, top: (h - 1920 * s) / 2, width: 1080, height: 1920, transform: `scale(${s})`, transformOrigin: "0 0" }}>
        <EpQuadro ep={ep} q={q} />
      </div>
    </div>
  );
};

const TelaPerfil: React.FC<{ seguidores: number | null; destaque: number }> = ({ seguidores, destaque }) => {
  const cw = (TW - 6) / 3;
  const ch = 206;
  const nome = DADOS.perfil.replace(/^@/, "");
  return (
    <AbsoluteFill style={{ background: "#07080d" }}>
      <div style={{ position: "absolute", left: 28, top: 66, right: 20, color: "#fff", fontWeight: 800, fontSize: 34, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{nome} ▾</div>
      <div style={{ position: "absolute", left: 26, top: 122, width: 118, height: 118, borderRadius: 59, padding: 6, boxSizing: "border-box", background: `conic-gradient(${AMARELO}, ${VERMELHO}, #c13584, ${AMARELO})` }}>
        <div style={{ width: 106, height: 106, borderRadius: 53, overflow: "hidden", border: "4px solid #07080d", boxSizing: "border-box" }}>
          <Miniatura ep={EP0} q={EP0.fundo} w={98} h={98} zoom={2.4} />
        </div>
      </div>
      {seguidores !== null ? (
        <div style={{ position: "absolute", left: 170, right: 10, top: 132, textAlign: "center", transform: `scale(${1 + 0.22 * destaque})` }}>
          <div style={{ color: destaque > 0 ? AMARELO : "#fff", fontWeight: 800, fontSize: 46, lineHeight: 1, fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>{fmtSeg(seguidores)}</div>
          <div style={{ color: "#c9cdd8", fontWeight: 500, fontSize: 26, marginTop: 8 }}>seguidores</div>
        </div>
      ) : null}
      <div style={{ position: "absolute", left: 30, top: 254, right: 20, color: "#fff", fontWeight: 800, fontSize: 28, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{DADOS.serie}</div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 304, height: 3, background: "rgba(255,255,255,0.1)" }} />
      {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((j) => {
        const ep = DADOS.eps[j % DADOS.eps.length];
        return (
          <div key={j} style={{ position: "absolute", left: (j % 3) * (cw + 3), top: 312 + Math.floor(j / 3) * (ch + 3) }}>
            <Miniatura ep={ep} q={ep.grade[j] ?? ep.meio} w={cw} h={ch} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

// tela do celular: a sua serie (lugar vazio esperando o personagem de quem assiste)
const TelaSuaSerie: React.FC<{ t: number }> = ({ t }) => (
  <AbsoluteFill style={{ background: "linear-gradient(#141a2e, #07080d)" }}>
    <div style={{ position: "absolute", left: 0, right: 0, top: 80, textAlign: "center", color: AMARELO, fontWeight: 800, fontSize: 66, letterSpacing: -1 }}>A SUA SÉRIE</div>
    <div style={{ position: "absolute", left: 30, width: TW - 60, top: 180, height: 620, borderRadius: 34, border: "7px dashed rgba(255,255,255,0.55)", background: "rgba(255,255,255,0.04)", boxSizing: "border-box", overflow: "hidden" }}>
      <svg width={TW - 74} height={606} style={{ position: "absolute", left: 0, top: 0 }}>
        <g transform={`translate(${(TW - 74) / 2} 330)`} opacity={0.5}>
          <circle cx={0} cy={-90} r={78} fill="none" stroke="#fff" strokeWidth={8} strokeDasharray="16 14" />
          <path d="M-150 200 Q-150 20 0 20 Q150 20 150 200" fill="none" stroke="#fff" strokeWidth={8} strokeDasharray="16 14" />
        </g>
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 130, textAlign: "center", color: AMARELO, fontWeight: 800, fontSize: 230, lineHeight: 1, transform: `scale(${1 + 0.06 * Math.sin(t * 7)})`, WebkitTextStroke: `14px ${INK}`, paintOrder: "stroke fill" }}>?</div>
    </div>
  </AbsoluteFill>
);

// tela do celular no CTA: comentarios
const TelaComentarios: React.FC = () => (
  <AbsoluteFill style={{ background: "#121318" }}>
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <div key={i} style={{ position: "absolute", left: 30, top: 110 + i * 130, display: "flex", gap: 18, alignItems: "center" }}>
        <div style={{ width: 64, height: 64, borderRadius: 32, background: "#2a2d38" }} />
        <div>
          <div style={{ width: 150 + ((i * 57) % 90), height: 18, borderRadius: 9, background: "#2a2d38", marginBottom: 12 }} />
          <div style={{ width: 260 + ((i * 83) % 120), height: 22, borderRadius: 11, background: "#353947" }} />
        </div>
      </div>
    ))}
  </AbsoluteFill>
);

// ---------------- textos ----------------
const Legenda: React.FC<{ txt: string; t: number; a: number; fundo?: boolean }> = ({ txt, t, a, fundo }) => {
  const s = interpolate(t - a, [0, 4 / FPS], [0.86, 1], CL);
  const partes = txt.split("*");
  return (
    <div
      style={{
        position: "absolute",
        left: 110,
        width: 860,
        top: BASE_LEG,
        transform: `translateY(-100%) scale(${s})`,
        transformOrigin: "50% 100%",
        isolation: "isolate",
        textAlign: "center",
        textWrap: "balance",
        fontFamily: F,
        fontWeight: 800,
        fontSize: 74,
        lineHeight: 1.12,
        letterSpacing: -0.5,
        color: "#fff",
        WebkitTextStroke: `18px ${INK}`,
        paintOrder: "stroke fill",
        textShadow: "0 8px 0 rgba(0,0,0,0.6)",
        paddingBottom: fundo ? 22 : 0,
      }}
    >
      {fundo ? <div style={{ position: "absolute", left: -30, right: -30, top: -22, bottom: 0, background: "rgba(5,6,14,0.86)", borderRadius: 34, zIndex: -1 }} /> : null}
      {partes.map((p, i) => (
        <span key={i} style={{ color: i % 2 ? AMARELO : "#fff" }}>
          {p}
        </span>
      ))}
    </div>
  );
};

const Selo: React.FC<{ icone: string; numero: string; rotulo: string; cor: string; s?: number; y?: number }> = ({ icone, numero, rotulo, cor, s = 1, y = 250 }) => (
  <div style={{ position: "absolute", left: 60, right: 60, top: y, display: "flex", justifyContent: "center" }}>
    <div
      style={{
        transform: `rotate(-3deg) scale(${s})`,
        display: "flex",
        alignItems: "center",
        gap: 22,
        background: INK,
        border: `8px solid ${cor}`,
        borderRadius: 34,
        padding: "10px 34px 14px 26px",
        boxShadow: "0 12px 0 rgba(0,0,0,0.55)",
        fontFamily: F,
        whiteSpace: "nowrap",
      }}
    >
      <span style={{ fontFamily: EMO, fontSize: 70, lineHeight: 1 }}>{icone}</span>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <span style={{ color: "#fff", fontWeight: 800, fontSize: 92, lineHeight: 1, letterSpacing: -2, fontVariantNumeric: "tabular-nums" }}>{numero}</span>
        <span style={{ color: cor, fontWeight: 800, fontSize: 36, lineHeight: 1.1 }}>{rotulo}</span>
      </div>
    </div>
  </div>
);

const Check: React.FC<{ cor: string; tam: number }> = ({ cor, tam }) => (
  <svg width={tam} height={tam} viewBox="0 0 100 100" style={{ marginRight: 14, flexShrink: 0 }}>
    <path d="M14 54 L40 78 L88 22" fill="none" stroke={cor} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const Carimbo: React.FC<{ t: number; a: number; txt: string; cor: string; x: number; y: number; rot: number; tam?: number; check?: boolean }> = ({ t, a, txt, cor, x, y, rot, tam = 96, check }) => {
  if (t < a) return null;
  const k = t - a;
  // entra com um "pulo" pequeno: mesmo no maior tamanho o carimbo fica dentro da zona segura
  const s = interpolate(k, [0, 0.1, 0.2], [1.1, 0.95, 1], CL);
  const o = interpolate(k, [0, 0.06], [0, 1], CL);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        transform: `translate(-50%, -50%) rotate(${rot}deg) scale(${s})`,
        opacity: o,
        display: "flex",
        alignItems: "center",
        border: `12px solid ${cor}`,
        borderRadius: 26,
        padding: "6px 30px 12px",
        color: cor,
        background: "rgba(5,6,14,0.86)",
        fontFamily: F,
        fontWeight: 800,
        fontSize: tam,
        lineHeight: 1,
        letterSpacing: -2,
        whiteSpace: "nowrap",
        boxShadow: "0 12px 0 rgba(0,0,0,0.5)",
      }}
    >
      {check ? <Check cor={cor} tam={tam * 0.8} /> : null}
      {txt}
    </div>
  );
};

const cabe = (txt: string, larg: number, max: number) => Math.min(max, Math.floor(larg / (Math.max(1, txt.length) * 0.62)));

const Manchete: React.FC<{ t: number; l1: string; l2: string }> = ({ t, l1, l2 }) => {
  const p = 1 + 0.02 * Math.sin(t * 2 * Math.PI * 1.2);
  return (
    <div style={{ position: "absolute", left: 60, right: 60, top: 250, display: "flex", flexDirection: "column", alignItems: "center", gap: 10, fontFamily: F, fontWeight: 800, transform: `scale(${p})` }}>
      <div style={{ color: "#fff", fontSize: 58, lineHeight: 1.05, letterSpacing: -1, WebkitTextStroke: `14px ${INK}`, paintOrder: "stroke fill", whiteSpace: "nowrap" }}>{l1}</div>
      <div style={{ background: AMARELO, color: INK, fontSize: cabe(l2, 800, 64), lineHeight: 1, letterSpacing: -1, padding: "8px 22px 12px", borderRadius: 18, border: `7px solid ${INK}`, transform: "rotate(-2deg)", boxShadow: "0 8px 0 rgba(0,0,0,0.55)", whiteSpace: "nowrap" }}>{l2}</div>
    </div>
  );
};

// baloes de comentario com as palavras de voto do episodio, saindo do celular
// (fora da tela de voto, que fica no meio do celular: em cima do celular e sobre as maos)
const LUGARES: [number, number, number][] = [
  [290, 330, -6],
  [790, 390, 5],
  [270, 1100, 4],
  [810, 1150, -5],
  [300, 1200, -3],
  [780, 1060, 6],
];
const Baloes: React.FC<{ t: number; tempos: number[] }> = ({ t, tempos }) => {
  const esc = DADOS.escolhas;
  if (!esc || esc.length < 2) return null;
  return (
    <>
      {tempos.map((a, i) => {
        const k = t - W(a);
        if (k < 0) return null;
        const e = interpolate(k, [0, 0.12, 0.22], [0, 1.12, 1], CL);
        const [x, y, r] = LUGARES[i % LUGARES.length];
        const x0 = 540;
        const y0 = 880;
        const px = interpolate(e, [0, 1], [x0, x], CL);
        const py = interpolate(e, [0, 1], [y0, y], CL);
        const palavra = esc[i % 2];
        const fs = cabe(palavra, 230, 46);
        return (
          <div key={i} style={{ position: "absolute", left: px, top: py, transform: `translate(-50%, -50%) rotate(${r}deg) scale(${e})`, display: "flex", alignItems: "center", gap: 14, background: "#fff", borderRadius: 40, border: `6px solid ${INK}`, padding: "12px 26px 14px 14px", boxShadow: "0 10px 0 rgba(0,0,0,0.5)", fontFamily: F, fontWeight: 800, whiteSpace: "nowrap" }}>
            <div style={{ width: 46, height: 46, borderRadius: 23, background: [VERMELHO, AZUL, VERDE, AMARELO][i % 4], border: `4px solid ${INK}` }} />
            <span style={{ color: INK, fontSize: fs, lineHeight: 1 }}>{palavra}</span>
          </div>
        );
      })}
    </>
  );
};

// ---------------- trecho do episodio em tela cheia (nasce do tamanho da tela do celular) ----------------
const Trecho: React.FC<{ ep: EpVenda; q: number; k: number; abre?: boolean }> = ({ ep, q, k, abre }) => {
  if (useContext(ModoTexto)) return null;
  const e = abre ? ent(k, 0, 0.18) : 1;
  const s0 = (TW * 0.92) / 1080;
  const cy0 = 1920 + (PY + 26 + TH / 2 - 1920) * 0.92;
  const s = interpolate(e, [0, 1], [s0, 1]) * (1 + 0.03 * k);
  const cy = interpolate(e, [0, 1], [cy0, 960]);
  return (
    <AbsoluteFill style={{ background: "#05060e" }}>
      {/* em tela cheia a legenda queimada do episodio some (contorno de 20 px = legenda e letreiro grande do kit) */}
      <style>{".trecho-sem-legenda [style*='text-stroke: 20px'] { visibility: hidden !important; }"}</style>
      <div className="trecho-sem-legenda" style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `translate(0px, ${cy - 960}px) scale(${s})`, transformOrigin: "540px 960px", borderRadius: (1 - e) * 110, overflow: "hidden" }}>
        <EpQuadro ep={ep} q={q} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 1500, bottom: 0, opacity: e, background: "linear-gradient(rgba(5,6,14,0) 0%, rgba(5,6,14,0.75) 40%, rgba(5,6,14,0.85) 100%)" }} />
    </AbsoluteFill>
  );
};

const Raios: React.FC<{ t: number }> = ({ t }) => {
  if (useContext(ModoTexto)) return null;
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, opacity: 0.5 }}>
      <g transform={`translate(540 760) rotate(${t * 8})`}>
        {Array.from({ length: 22 }).map((_, i) => {
          const a = (i / 22) * Math.PI * 2;
          return <line key={i} x1={Math.cos(a) * 480} y1={Math.sin(a) * 480} x2={Math.cos(a) * 1300} y2={Math.sin(a) * 1300} stroke={i % 2 ? VERMELHO : AMARELO} strokeWidth={30} strokeLinecap="round" />;
        })}
      </g>
    </svg>
  );
};

const Seta: React.FC<{ p: number; t: number }> = ({ p, t }) => {
  const vai = 14 * Math.sin(t * 2 * Math.PI * 1.8);
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, opacity: p > 0 ? 1 : 0 }}>
      <g transform={`translate(${vai * 0.6} ${vai * 0.5})`}>
        <path d="M715 1250 Q840 1265 890 1385" fill="none" stroke={INK} strokeWidth={44} strokeLinecap="round" strokeDasharray={1} pathLength={1} strokeDashoffset={1 - p} />
        <path d="M715 1250 Q840 1265 890 1385" fill="none" stroke={AMARELO} strokeWidth={24} strokeLinecap="round" strokeDasharray={1} pathLength={1} strokeDashoffset={1 - p} />
        <g transform="translate(896 1400) rotate(28)" opacity={p > 0.95 ? 1 : 0}>
          <path d="M-56 -36 L0 30 L56 -36 Z" fill={AMARELO} stroke={INK} strokeWidth={12} strokeLinejoin="round" />
        </g>
      </g>
    </svg>
  );
};

// ---------------- CTA ----------------
const CenaCTA: React.FC<{ t: number; k: number; m: { palavra?: number; digita?: number; seta?: number } }> = ({ t, k, m }) => {
  const P = DADOS.palavra;
  const tP = W(m.palavra ?? 0);
  const tD = W(m.digita ?? 0);
  const tS = W(m.seta ?? 0);
  const km = t - tP;
  const sM = interpolate(k, [0, 0.1, 0.2], [0.4, 1.04, 1], CL) * (km < 0 ? 1 : interpolate(km, [0, 0.07, 0.18], [1.08, 0.97, 1], CL));
  const pulso = 1 + 0.03 * Math.max(0, Math.sin((t - tP - 0.4) * 2 * Math.PI * 1.1));
  const fs = Math.min(180, Math.floor(700 / (P.length * 0.72)));
  const letras = Math.max(0, Math.min(P.length, Math.floor((t - tD) * 12)));
  const seta = ent(t, tS, 0.3);
  const mt = useContext(ModoTexto);
  return (
    <>
      <Fundo t={t} brilho={0.3} />
      <Raios t={t} />
      <Celular t={t} escuro={0.5}>
        <TelaComentarios />
      </Celular>
      {mt ? null : <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 40%, rgba(7,8,15,0.35) 0%, rgba(7,8,15,0.7) 60%, rgba(7,8,15,0.5) 100%)" }} />}
      <div style={{ position: "absolute", left: 60, right: 60, top: 400, textAlign: "center", fontFamily: F, fontWeight: 800, fontSize: 124, color: "#fff", letterSpacing: -2, opacity: ent(k, 0, 0.18), WebkitTextStroke: `16px ${INK}`, paintOrder: "stroke fill" }}>
        Comenta
      </div>
      <div style={{ position: "absolute", left: 60, right: 60, top: 575, display: "flex", justifyContent: "center" }}>
        <div style={{ transform: `rotate(-3deg) scale(${sM * pulso})`, background: AMARELO, color: INK, border: `14px solid ${INK}`, borderRadius: 36, padding: "6px 44px 22px", fontFamily: F, fontWeight: 800, fontSize: fs, lineHeight: 1, letterSpacing: -4, boxShadow: "0 18px 0 rgba(0,0,0,0.6)", whiteSpace: "nowrap" }}>{P}</div>
      </div>
      <div style={{ position: "absolute", left: 100, right: 100, top: 860, textAlign: "center", textWrap: "balance", fontFamily: F, fontWeight: 800, fontSize: 62, lineHeight: 1.13, color: "#fff", opacity: ent(t, tP + 0.3, 0.25), WebkitTextStroke: `14px ${INK}`, paintOrder: "stroke fill" }}>
        que eu te mando <span style={{ color: AMARELO }}>no direct</span> <span style={{ fontFamily: EMO, WebkitTextStroke: "0px" }}>📩</span>
      </div>
      <div style={{ position: "absolute", left: 150, width: 640, top: 1090, height: 92, borderRadius: 46, background: "#16171d", border: `5px solid ${AMARELO}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 34px", boxSizing: "border-box", fontFamily: F, fontWeight: 800, opacity: ent(t, tD - 0.3, 0.2), boxShadow: "0 10px 0 rgba(0,0,0,0.55)" }}>
        <span style={{ color: "#fff", fontSize: 48, whiteSpace: "nowrap" }}>
          {letras ? P.slice(0, letras) : <span style={{ color: "#7d8494" }}>Comentar...</span>}
          {Math.floor(t * 3) % 2 === 0 ? <span style={{ color: AMARELO }}>|</span> : null}
        </span>
        <span style={{ color: AZUL, fontSize: 36 }}>Publicar</span>
      </div>
      <div style={{ position: "absolute", left: 130, top: 1215, fontFamily: F, fontWeight: 800, fontSize: 50, color: AMARELO, opacity: seta, WebkitTextStroke: `12px ${INK}`, paintOrder: "stroke fill", transform: "rotate(-4deg)", whiteSpace: "nowrap" }}>aqui nos comentários</div>
      <Seta p={seta} t={t} />
    </>
  );
};

// ---------------- cenas de cada bloco ----------------
const Cena: React.FC<{ i: number; t: number }> = ({ i, t }) => {
  const mt = useContext(ModoTexto);
  const b = BL[i];
  const k = t - INI[i];
  const fimFala = FIM_FALA[i];
  const mostraLeg = b.leg && (i === 0 ? t < fimFala : t >= INI[i] && t < fimFala);
  const leg = mostraLeg ? <Legenda txt={b.leg} t={t} a={i === 0 ? 0 : INI[i]} fundo={b.tipo === "views"} /> : null;
  const S = DADOS.seguidores;
  const D = DADOS.dias;
  const V = DADOS.views;
  switch (b.tipo) {
    case "gancho": {
      if (b.var === "seg" && S !== null) {
        return (
          <>
            <Fundo t={t} />
            <Celular t={t} tremor={k < 1.0 ? 2.5 : 0.8}>
              <TelaPerfil seguidores={S} destaque={interpolate(k, [0.9, 1.05, 1.3], [0, 1, 0.6], CL)} />
            </Celular>
            <Selo icone="👥" numero={fmtSeg(S)} rotulo="seguidores" cor={AMARELO} s={1 + 0.02 * Math.sin(t * 8)} />
            {D ? <Carimbo t={t} a={-1} txt={`EM ${diasTxt(D)}`} cor={VERMELHO} x={700} y={800} rot={-8} tam={86} /> : null}
            {leg}
          </>
        );
      }
      if (b.var === "views" && V !== null) {
        return (
          <>
            <Fundo t={t} />
            <Celular t={t} tremor={1}>
              <TelaEp ep={EP0} q={EP0.inicio + k * FPS} />
            </Celular>
            <Selo icone="▶️" numero={fmtViews(V)} rotulo="views num vídeo só" cor={AMARELO} s={1 + 0.02 * Math.sin(t * 8)} />
            {leg}
          </>
        );
      }
      return (
        <>
          <Fundo t={t} />
          <Celular t={t}>
            <TelaEp ep={EP0} q={EP0.inicio + k * FPS} />
          </Celular>
          {b.var === "dias" && D ? <Selo icone="📅" numero={diasTxt(D)} rotulo="desde o primeiro episódio" cor={AMARELO} /> : <Manchete t={t} l1="a minha série animada" l2={DADOS.serie} />}
          {leg}
        </>
      );
    }
    case "origem": {
      const q = k < 0.6 ? interpolate(k, [0, 0.6], [EP0.voto, EP0.inicio], CL) : EP0.inicio + (k - 0.6) * FPS;
      const L = (INI[i + 1] ?? DUR_VENDA / FPS) - INI[i];
      const n = D ? Math.round(rola(k, 0.8, Math.max(1.0, L - 0.4), 1, D)) : 1;
      return (
        <>
          <Fundo t={t} />
          <Celular t={t}>
            <TelaEp ep={EP0} q={q} />
          </Celular>
          <Selo icone="📅" numero={`DIA ${n}`} rotulo="desde o primeiro episódio" cor={AMARELO} />
          {leg}
        </>
      );
    }
    case "serie": {
      const corte = W(b.m.corte ?? b.ate);
      const segundo = t >= corte;
      const ep = segundo ? EP_ULT : EP0;
      const q = segundo ? EP_ULT.outro + (t - corte) * FPS : EP0.meio + k * FPS;
      const fs = cabe(DADOS.serie, 900, 104);
      return (
        <>
          <Trecho ep={ep} q={q} k={segundo ? t - corte : k} abre={!segundo} />
          {mt ? null : <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 620, background: "linear-gradient(rgba(5,6,14,0.97) 0%, rgba(5,6,14,0.95) 40%, rgba(5,6,14,0.8) 65%, rgba(5,6,14,0) 100%)" }} />}
          <div style={{ position: "absolute", left: 60, right: 60, top: 270, display: "flex", flexDirection: "column", alignItems: "center", gap: 14, fontFamily: F, fontWeight: 800, opacity: ent(k, 0.1, 0.2) }}>
            <div style={{ background: AMARELO, color: INK, fontSize: 44, padding: "6px 22px 10px", borderRadius: 14, border: `6px solid ${INK}`, transform: "rotate(-3deg)", whiteSpace: "nowrap" }}>A MINHA SÉRIE</div>
            <div style={{ color: "#fff", fontSize: fs, lineHeight: 1.05, letterSpacing: -2, WebkitTextStroke: `16px ${INK}`, paintOrder: "stroke fill", whiteSpace: "nowrap", transform: `scale(${interpolate(k, [0.1, 0.22, 0.32], [1.3, 0.96, 1], CL)})` }}>{DADOS.serie}</div>
          </div>
        </>
      );
    }
    case "views": {
      const ep = EP0;
      const q = (ep.grade[6] ?? ep.outro) + k * FPS;
      return (
        <>
          <Trecho ep={ep} q={q} k={k} />
          {mt ? null : <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 560, background: "linear-gradient(rgba(5,6,14,0.97) 0%, rgba(5,6,14,0.95) 45%, rgba(5,6,14,0.8) 65%, rgba(5,6,14,0) 100%)" }} />}
          {V !== null ? <Selo icone="▶️" numero={fmtViews(Math.round(rola(k, 0.1, 1.1, 0, V)))} rotulo="views no meu vídeo mais visto" cor={AMARELO} s={k > 1.1 ? 1 + 0.02 * Math.sin(t * 8) : 1} /> : null}
          {leg}
        </>
      );
    }
    case "voto":
      return (
        <>
          <Fundo t={t} />
          <Celular t={t}>
            <TelaEp ep={EP0} q={EP0.voto + k * FPS} />
          </Celular>
          <Baloes t={t} tempos={b.m.baloes ?? []} />
          {leg}
        </>
      );
    case "sua": {
      const ch = b.m.checks ?? [];
      return (
        <>
          <Fundo t={t} brilho={0.34} />
          <Celular t={t}>
            <TelaSuaSerie t={t} />
          </Celular>
          {ch[0] !== undefined ? <Carimbo t={t} a={W(ch[0])} txt="SEM APARECER" cor={VERDE} x={540} y={700} rot={-4} tam={66} check /> : null}
          {ch[1] !== undefined ? <Carimbo t={t} a={W(ch[1])} txt="SEM DESENHAR" cor={AMARELO} x={540} y={860} rot={3} tam={66} check /> : null}
          {ch[2] !== undefined ? <Carimbo t={t} a={W(ch[2])} txt="SEM EDITAR VÍDEO" cor={AZUL} x={540} y={1020} rot={-2} tam={66} check /> : null}
          {leg}
        </>
      );
    }
    case "cta":
      return <CenaCTA t={t} k={k} m={b.m} />;
    default:
      return null;
  }
};

export const VendaParceiro: React.FC<{ modoTexto?: boolean }> = ({ modoTexto = false }) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  let i = 0;
  for (let j = 0; j < BL.length; j++) if (t >= INI[j] || j === 0) i = j;
  return (
    <ModoTexto.Provider value={modoTexto}>
      <AbsoluteFill style={{ background: modoTexto ? "#000" : "#05060e", overflow: "hidden", fontFamily: F }}>
        <Cena i={i} t={t} />
      </AbsoluteFill>
    </ModoTexto.Provider>
  );
};
