import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { fontFamily } from "./fontes";

// Legenda de fala: uma cor por personagem, branco e sempre quem assiste.
export const CORES = {
  voce: "#ffffff",
  interfone: "#4fd8ff",
  homem: "#ff9a3d",
  grupo: "#7be08a",
  mae: "#ff8fc0",
  entregador: "#c9a6ff",
  capitao: "#ffd83d",
  marinheiro: "#7be08a",
  jonas: "#4fd8ff",
  // chaves genericas, para episodios novos (as de cima sao apelidos usados pelos exemplos)
  branco: "#ffffff",
  azul: "#4fd8ff",
  laranja: "#ff9a3d",
  verde: "#7be08a",
  rosa: "#ff8fc0",
  lilas: "#c9a6ff",
  amarelo: "#ffd83d",
};

export type Fala = { de: number; ate: number; quem: keyof typeof CORES; texto: string; tel?: string; y?: number };

export const Legenda: React.FC<{ falas: Fala[]; y?: number; quadro?: number }> = ({ falas, y = 1060, quadro }) => {
  const real = useCurrentFrame();
  const frame = quadro ?? real;
  const f = falas.find((x) => frame >= x.de && frame < x.ate);
  if (!f) return null;
  const s = interpolate(frame - f.de, [0, 4], [0.86, 1], { extrapolateRight: "clamp" });
  return (
    <div
      style={{
        position: "absolute",
        left: 110,
        width: 860,
        textWrap: "balance",
        top: f.y ?? y,
        transform: `translateY(-50%) scale(${s})`,
        textAlign: "center",
        fontFamily,
        fontWeight: 800,
        fontSize: 80,
        lineHeight: 1.12,
        letterSpacing: -0.5,
        color: CORES[f.quem],
        WebkitTextStroke: "20px #0d0c0a",
        paintOrder: "stroke fill",
        textShadow: "0 8px 0 rgba(0,0,0,0.6)",
      }}
    >
      {f.tel ? (
        <div
          style={{
            display: "inline-block",
            background: "#0d0c0a",
            color: CORES[f.quem],
            WebkitTextStroke: "0px",
            textShadow: "none",
            fontSize: 34,
            letterSpacing: 2,
            padding: "6px 20px 8px",
            borderRadius: 30,
            marginBottom: 14,
            border: `4px solid ${CORES[f.quem]}`,
          }}
        >
          {f.tel}
        </div>
      ) : null}
      <div>{f.texto}</div>
    </div>
  );
};

export const EtiquetaParte: React.FC<{ n: number }> = ({ n }) => (
  <div
    style={{
      position: "absolute",
      left: 92,
      top: 150,
      transform: "rotate(-4deg)",
      background: "#e0241b",
      color: "#fff",
      fontFamily,
      fontWeight: 800,
      fontSize: 54,
      padding: "8px 26px 10px",
      borderRadius: 14,
      border: "7px solid #0d0c0a",
      boxShadow: "0 8px 0 rgba(0,0,0,0.5)",
    }}
  >
    PARTE {n}
  </div>
);

// Etiqueta do alto a direita: relogio, capitulo ou outro texto curto do episodio. borda = cor da moldura.
export const EtiquetaDireita: React.FC<{ borda?: string; children: React.ReactNode }> = ({ borda = "#3a3f52", children }) => (
  <div
    style={{
      position: "absolute",
      right: 86,
      top: 156,
      background: "#0d0c0a",
      color: "#fff",
      fontFamily,
      fontWeight: 800,
      fontSize: 46,
      padding: "8px 24px 10px",
      borderRadius: 14,
      border: `5px solid ${borda}`,
    }}
  >
    {children}
  </div>
);
