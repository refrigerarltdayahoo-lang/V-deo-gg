import React from "react";
import { Easing } from "remotion";
import { fontFamily } from "./fontes";
import { TEMA_PORTEIRO, Tema } from "./Maos";

// Celular na mao esquerda, em primeiro plano. A conversa e o texto da cena (sem legenda por cima).
// ap = aparicao da mensagem, de 0 (invisivel) a 1 (inteira). Trecho entre *asteriscos* sai em vermelho.
export type Msg = { nome?: string; cor?: string; texto: string; meu?: boolean; ap: number };
// Mensagem com hora marcada: t = instante do roteiro em que ela chega; m = a mensagem, sem o "ap".
export type MsgNoTempo = { t: number; m: Omit<Msg, "ap"> };

const INK = "#0d0c0a";
const ease01 = (x: number) => Easing.inOut(Easing.cubic)(Math.max(0, Math.min(1, x)));

// 0 a 1 enquanto a janela [a, b) do roteiro esta aberta, com entrada e saida curtas. Serve para o "entra" do Celular.
export const janela = (T: number, a: number, b: number, ent = 0.23, sai = 0.16) =>
  T < a || T >= b ? 0 : Math.min(ease01((T - a) / ent), ease01((b - T) / sai));

// As ultimas "max" mensagens que ja chegaram no instante T, cada uma com o "ap" calculado (entra em 0,2 s).
export const visiveis = (lista: MsgNoTempo[], T: number, max: number): Msg[] =>
  lista
    .filter((x) => x.t <= T)
    .slice(-max)
    .map((x) => ({ ...x.m, ap: ease01((T - x.t) / 0.2) }));

// tema: cores da manga e da pele do braco que segura o aparelho (o mesmo tipo Tema usado em Maos).
export const Celular: React.FC<{ entra: number; titulo: string; sub: string; avatar: string; msgs: Msg[]; tema?: Tema }> = ({
  entra,
  titulo,
  sub,
  avatar,
  msgs,
  tema = TEMA_PORTEIRO,
}) => {
  if (entra <= 0.001) return null;
  const PELE = tema.pele;
  const MANGA = tema.manga;
  const dy = (1 - entra) * 1300;
  return (
    <div style={{ position: "absolute", inset: 0, transform: `translateY(${dy}px)` }}>
      {/* braco e dedos por tras do aparelho */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
        <path d="M-40 1920 L150 1560 L420 1700 L330 1920 Z" fill={MANGA} stroke={INK} strokeWidth={9} strokeLinejoin="round" />
      </svg>
      <div
        style={{
          position: "absolute",
          left: 200,
          top: 640,
          width: 680,
          height: 1180,
          transform: "rotate(-3deg)",
          background: "#141416",
          borderRadius: 74,
          border: `10px solid ${INK}`,
          boxShadow: "0 30px 0 rgba(0,0,0,0.45)",
          padding: 22,
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            width: "100%",
            height: "100%",
            borderRadius: 52,
            overflow: "hidden",
            background: "#0b141a",
            fontFamily,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div style={{ background: "#1f2c34", padding: "34px 28px 24px", display: "flex", alignItems: "center", gap: 20 }}>
            <div
              style={{
                width: 84,
                height: 84,
                borderRadius: 42,
                background: "#3b4a54",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 46,
              }}
            >
              {avatar}
            </div>
            <div>
              <div style={{ color: "#e9edef", fontWeight: 800, fontSize: 38, lineHeight: 1.1 }}>{titulo}</div>
              <div style={{ color: "#8696a0", fontWeight: 500, fontSize: 26, marginTop: 4 }}>{sub}</div>
            </div>
          </div>
          <div style={{ flex: 1, padding: "26px 22px", display: "flex", flexDirection: "column", gap: 22, justifyContent: "center" }}>
            {msgs.map((m, i) =>
              m.ap <= 0.001 ? null : (
                <div
                  key={i}
                  style={{
                    alignSelf: m.meu ? "flex-end" : "flex-start",
                    maxWidth: "94%",
                    background: m.meu ? "#005c4b" : "#1f2c34",
                    borderRadius: 26,
                    padding: "16px 22px 18px",
                    transform: `scale(${0.7 + 0.3 * m.ap})`,
                    transformOrigin: m.meu ? "100% 100%" : "0% 100%",
                    opacity: m.ap,
                  }}
                >
                  {m.nome ? <div style={{ color: m.cor ?? "#7be08a", fontWeight: 800, fontSize: 36, marginBottom: 4 }}>{m.nome}</div> : null}
                  <div style={{ color: "#e9edef", fontWeight: 500, fontSize: 50, lineHeight: 1.16 }}>
                    {m.texto.split("*").map((p, k) => (k % 2 ? <span key={k} style={{ color: "#ff6a5a", fontWeight: 800 }}>{p}</span> : <span key={k}>{p}</span>))}
                  </div>
                </div>
              ),
            )}
          </div>
        </div>
      </div>
      {/* polegar por cima da borda esquerda */}
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
        <g transform="translate(262 1806) rotate(62)">
          <rect x={-46} y={-170} width={92} height={300} rx={46} fill={PELE} stroke={INK} strokeWidth={9} />
          <rect x={-22} y={-152} width={44} height={46} rx={18} fill={tema.unha} />
        </g>
      </svg>
    </div>
  );
};
