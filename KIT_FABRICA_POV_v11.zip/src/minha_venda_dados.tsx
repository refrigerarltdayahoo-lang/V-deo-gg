// EXEMPLO de fábrica (série A Portaria, sem números). Gerado por parceiro/parceiro.py. Não edite à mão: mude
// parceiro/minhas_respostas.json e rode de novo o parceiro.py video.
import { DadosVenda } from "./venda_tipos";
import { Ep01 } from "./Ep01";

export const DADOS: DadosVenda = {
  perfil: "@seu.perfil",
  serie: "A Portaria",
  palavra: "MÉTODO",
  seguidores: null,
  segAprox: false,
  dias: null,
  views: null,
  viewsAprox: false,
  tema: {"manga": "#274f8f", "mangaS": "#1d3c6e", "pele": "#b97d4c", "peleS": "#96623a", "unha": "#dcae86"},
  escolhas: ["ABRIR", "ESPERAR"],
  eps: [
    { C: Ep01, total: 3523, inicio: 3, meio: 1625, outro: 2435, voto: 3394, fundo: 922, grade: [252, 762, 1290, 1763, 2183, 2700] },
  ],
  blocos: [
    { tipo: "gancho", var: "serie", de: 0.1, ate: 2.61, leg: "Olha a *série animada* que eu fiz!", m: {} },
    { tipo: "serie", var: "", de: 2.76, ate: 5.34, leg: "", m: {"corte": 5.59} },
    { tipo: "voto", var: "", de: 7.69, ate: 11.37, leg: "E quem decide o final são *vocês!*", m: {"baloes": [8.04, 8.46, 8.88, 9.3, 9.72, 10.14]} },
    { tipo: "sua", var: "", de: 12.02, ate: 15.91, leg: "E dá pra você criar a *sua série* assim, sem aparecer.", m: {"checks": [12.62, 13.27, 13.92]} },
    { tipo: "cta", var: "", de: 16.06, ate: 19.19, leg: "", m: {"palavra": 16.61, "digita": 17.06, "seta": 17.41} },
  ],
  base: 21.79,
};
