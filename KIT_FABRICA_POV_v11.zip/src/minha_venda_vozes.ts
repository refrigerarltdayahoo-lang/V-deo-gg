// Gerado por ep_audio.py: segundos extras que cada fala precisa alem do tempo previsto no roteiro.
export const EXTRAS: number[] = [];
