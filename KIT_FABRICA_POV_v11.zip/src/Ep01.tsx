import React from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";
import { Cam, bill, proj } from "./engine";
import { Portaria } from "./Portaria";
import { Maos, Pose } from "./Maos";
import { CORES, EtiquetaDireita, EtiquetaParte, Fala, Legenda } from "./Legenda";
import { Boneco, Expr } from "./Personagens";
import { Celular, Msg, janela, visiveis } from "./Celular";
import { CamId, Cftv } from "./Cftv";
import { Escolha } from "./Escolha";
import { EXTRAS } from "./vozes";

// Exemplo 1: "A Portaria" (suspense). Voce e o porteiro no turno da noite. 30 fps.
export const FPS = 30;
const BASE = 96;
const PRE = 0; // flash de abertura desligado: o episodio nao abre mostrando o que vem depois
// trechos do roteiro pulados: [inicio no tempo antigo, segundos negativos]
const SALTOS: { b: number; extra: number }[] = [{ b: 15.3, extra: -4.7 }];
// tempo de leitura das mensagens do celular: o roteiro para e a mensagem fica na tela.
// Regra: cada mensagem fica 1 s + 0,28 s por palavra, uma de cada vez.
const PAUSAS: { b: number; extra: number }[] = [{ b: 11.88, extra: 1.9 }, { b: 12.8, extra: 1.6 }, { b: 14.18, extra: 3.3 }, { b: 15.1, extra: 0.7 }, { b: 28.98, extra: 1.5 }, { b: 30.7, extra: 0.7 }, { b: 64.58, extra: 1.9 }, { b: 66.9, extra: 0.3 }, { b: 79.7, extra: 1.2 }];
const S = (s: number) => Math.round(s * FPS);
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const ease = (x: number) => Easing.inOut(Easing.cubic)(clamp(x));
const entre = (T: number, a: number, b: number) => T >= a && T < b;

// ---------- camera ----------
type Alvo = { t0: number; yaw: number; pitch: number; f: number; z: number; dur?: number };
const BANC = { yaw: 0.52, pitch: -0.48, f: 640, z: 0 };
const MESA = { yaw: 0.05, pitch: -0.78, f: 640, z: 0 };
const ALVOS: Alvo[] = [
  { t0: 0, ...BANC },
  { t0: 6.3, yaw: 0, pitch: -0.05, f: 720, z: 0.2, dur: 50 },
  { t0: 10.7, ...MESA },
  { t0: 23, yaw: 0.16, pitch: -0.1, f: 980, z: 0.2 },
  { t0: 27, ...MESA },
  { t0: 31, yaw: 0.16, pitch: -0.06, f: 860, z: 0.2, dur: 5 },
  { t0: 35, yaw: 0.16, pitch: 0.0, f: 1250, z: 0.25, dur: 70 },
  { t0: 41, ...BANC },
  { t0: 47, yaw: 0.16, pitch: 0.0, f: 1150, z: 0.25 },
  { t0: 54, yaw: 0.16, pitch: 0.02, f: 1200, z: 0.25 },
  { t0: 59.9, yaw: 0.14, pitch: -0.12, f: 1300, z: 0.25, dur: 18 },
  { t0: 63, ...MESA },
  { t0: 67, ...BANC, f: 700 },
  { t0: 73, yaw: 0.165, pitch: 0.11, f: 2000, z: 0.3 },
  { t0: 76, ...MESA },
  { t0: 80, ...BANC },
  { t0: 87, yaw: 0.165, pitch: 0.06, f: 1500, z: 0.3, dur: 5 },
];

const camAt = (frame: number, Tr: number): Cam => {
  const T = frame / FPS;
  let i = 0;
  for (let k = 0; k < ALVOS.length; k++) if (ALVOS[k].t0 <= T) i = k;
  const a = ALVOS[i];
  const p = i > 0 ? ALVOS[i - 1] : a;
  const k = ease((frame - S(a.t0)) / (a.dur ?? 7));
  const mix = (x: number, y: number) => x + (y - x) * k;
  const swayY = 0.012 * Math.sin(Tr * 1.3) + 0.006 * Math.sin(Tr * 2.9 + 1);
  const swayP = 0.009 * Math.sin(Tr * 1.7 + 0.5) + 0.005 * Math.sin(Tr * 3.3);
  const zoom = 1 + 0.0035 * (T - a.t0); // empurrao lento em todo plano
  return {
    pos: [0, 1.25, mix(p.z, a.z)],
    yaw: mix(p.yaw, a.yaw) + swayY,
    pitch: mix(p.pitch, a.pitch) + swayP,
    roll: 0.012 * Math.sin(Tr * 0.9),
    f: mix(p.f, a.f) * zoom,
  };
};

// ---------- falas ----------
const P = 1340; // legenda abaixo da porta
const TEL = "INTERFONE · 804";
const fala = (a: number, b: number, quem: Fala["quem"], texto: string, y?: number, tel?: string): Fala => ({ de: S(a), ate: S(b), quem, texto, y, tel });
const FALAS: Fala[] = [
  fala(0, 1.75, "voce", "Portaria, boa noite."),
  fala(1.8, 4.2, "interfone", "Hoje não deixa ninguém subir pro meu apartamento.", undefined, TEL),
  fala(4.3, 6.2, "voce", "Tudo bem, seu Álvaro. Ninguém sobe."),
  fala(6.3, 8.7, "interfone", "Ninguém. Nem se for eu.", P, TEL),
  fala(8.8, 10.6, "voce", "...Nem se for ele?", P),
  fala(20.3, 22.8, "voce", "A luz do oitavo tá piscando.", 1440),
  fala(23.2, 25, "entregador", "Entrega pro 502! Deixo aqui?", P),
  fala(25.1, 26.6, "voce", "Pode deixar.", P),
  fala(31.2, 34.6, "homem", "Boa noite! Esqueci a chave. Abre pra mim?", P),
  fala(35, 38, "voce", "Seu Álvaro...? O senhor acabou de me ligar lá de cima.", P),
  fala(38.1, 40.8, "homem", "Eu? Tô chegando do trabalho agora, rapaz.", P),
  fala(43, 46.8, "interfone", "Ele chegou, né? Não olha muito pra ele. Não abre.", undefined, TEL),
  fala(47.2, 49.7, "homem", "Com quem você tá falando?", P),
  fala(50.4, 53.7, "voce", "A câmera... não tem ninguém na câmera.", 1440),
  fala(54.2, 57, "interfone", "Ele vai dizer que tá chovendo. Olha pro chão.", 450, TEL),
  fala(57.2, 59.7, "homem", "Abre. Tá chovendo.", 450),
  fala(60.6, 62.9, "voce", "Não tá chovendo...", 1500),
  fala(67.2, 69.7, "voce", "Ele não tá em casa...? Então quem tá no 804?"),
  fala(70, 72.7, "interfone", "Não lê o grupo. Escuta só a mim.", undefined, TEL),
  fala(73.2, 75.7, "homem", "Rapaz. Quem tá na minha casa?", P),
  fala(80.2, 81.8, "voce", "...Eu já atendi."),
  fala(85, 86.9, "interfone", "Tô descendo. Não abre pra ele.", undefined, TEL),
  fala(87, 88.9, "homem", "Abre! Ele tá descendo! Abre essa porta!", P),
];

// ---------- tempo elastico: cada fala dura o que a voz durar ----------
// O roteiro vive no "tempo antigo" (T). Quando a voz precisa de mais tempo, o relogio do roteiro
// para no fim da fala ate a voz acabar; camera, gotas e tremor seguem no tempo real.
const CORTES = [...FALAS.map((f, i) => ({ b: f.ate / FPS, extra: EXTRAS[i] ?? 0 })), ...SALTOS, ...PAUSAS].sort((x, y) => x.b - y.b);
export const DUR_EP01 = Math.round((BASE + PRE + CORTES.reduce((s, c) => s + c.extra, 0)) * FPS);
const tempoAntigo = (Tr: number): number => {
  let acc = 0;
  for (const c of CORTES) {
    if (Tr < c.b + acc) return Tr - acc;
    if (c.extra > 0 && Tr < c.b + acc + c.extra) return c.b - 0.002;
    acc += c.extra; // negativo = pula um trecho do roteiro
  }
  return Tr - acc;
};

// ---------- celular ----------
const NEIDE = { nome: "Dona Neide 302", cor: "#f7a8d8" };
const SIND = { nome: "Síndico", cor: "#7be08a" };
const GRUPO: { t: number; m: Omit<Msg, "ap"> }[] = [
  { t: 10.85, m: { ...NEIDE, texto: "quem tá arrastando móvel uma hora dessas???" } },
  { t: 11.9, m: { ...SIND, texto: "Pessoal, respeitem o horário de silêncio." } },
  { t: 27.3, m: { ...NEIDE, texto: "tem alguém andando no teto do meu apto" } },
  { t: 29.0, m: { ...SIND, texto: "É o vento, Dona Neide." } },
  { t: 63.3, m: { ...NEIDE, texto: "o seu Álvaro do 804 não tinha viajado?" } },
  { t: 64.6, m: { ...SIND, texto: "Viajou. Volta dia 20." } },
];
const MAE: { t: number; m: Omit<Msg, "ap"> }[] = [
  { t: 13.05, m: { texto: "Filho, já jantou? Teu tio disse que aí de noite é tranquilo 🙏" } },
  { t: 14.2, m: { texto: "Tranquilo, mãe 😴", meu: true } },
  { t: 76.3, m: { texto: "Filho, teu tio mandou avisar: se o *804* interfonar de noite, *NÃO ATENDE.*" } },
];

export const Ep01: React.FC = () => {
  const quadroReal = useCurrentFrame();
  const TrAbs = quadroReal / FPS;
  const Tr = Math.max(0, TrAbs - PRE);
  const T = tempoAntigo(Tr);
  const frame = T * FPS;
  const cam = camAt(frame, Tr);

  // ---------- flash de abertura: o homem molhado no vidro, antes de tudo ----------
  if (TrAbs < PRE) {
    const k = TrAbs / PRE;
    const camT: Cam = { pos: [0, 1.25, 0.3], yaw: 0.165, pitch: 0.1, roll: 0.012 * Math.sin(TrAbs * 9), f: 1400 + 500 * k };
    const foraT = [
      bill(camT, "homem", [0.5, 0, 3.3], (
        <Boneco camisa="#5d6f86" calca="#23262f" pele="#c9a184" cabelo="#2a2320" expr="sorriso" t={TrAbs} molhado mao={1} />
      )),
    ];
    const p1 = clamp((TrAbs - 0.12) / 0.14);
    const p2 = clamp((TrAbs - 1.15) / 0.14);
    const tx: React.CSSProperties = { fontWeight: 800, WebkitTextStroke: "20px #0d0c0a", paintOrder: "stroke fill", textAlign: "center", lineHeight: 1.05 };
    return (
      <AbsoluteFill style={{ backgroundColor: "#060a18" }}>
        <Portaria cam={camT} st={{ ledOn: false, poste: 1, luz: 1, chamando: 0, t: TrAbs }} fora={foraT} />
        <AbsoluteFill style={{ background: "radial-gradient(ellipse 75% 62% at 50% 45%, rgba(0,0,0,0) 42%, rgba(3,5,14,0.82) 100%)" }} />
        <div style={{ position: "absolute", left: 0, right: 0, top: 1085, display: "flex", justifyContent: "center", opacity: p1 }}>
          <div style={{ fontFamily: "Inter POV", fontWeight: 800, fontSize: 38, letterSpacing: 2, color: "#4fd8ff", background: "#0d0c0a", border: "4px solid #4fd8ff", borderRadius: 30, padding: "6px 22px 8px" }}>INTERFONE · 804</div>
        </div>
        <div style={{ position: "absolute", left: 70, width: 940, top: 1165, whiteSpace: "nowrap", fontFamily: "Inter POV", ...tx, fontSize: 104, color: "#4fd8ff", opacity: p1, transform: `scale(${0.7 + 0.3 * p1})` }}>NINGUÉM SOBE.</div>
        <div style={{ position: "absolute", left: 70, width: 940, top: 1300, whiteSpace: "nowrap", fontFamily: "Inter POV", ...tx, fontSize: 104, color: "#fff", opacity: p2, transform: `scale(${0.7 + 0.3 * p2})` }}>NEM SE FOR EU.</div>
        <AbsoluteFill style={{ backgroundColor: "#fff", opacity: k > 0.9 ? (k - 0.9) * 8 : 0 }} />
      </AbsoluteFill>
    );
  }

  // ---------- estado da cena ----------
  const tocando = T < 0.55 || entre(T, 41, 42.6);
  const ledOn = tocando && Math.floor(frame / 5) % 2 === 0;
  const chamando = T < 1.75 ? interpolate(T, [0, 1.45, 1.75], [1, 1, 0]) : janela(T, 41, 42.7, 0.1, 0.15);
  const emLigacao = entre(T, 0.3, 10.6) || T >= 42.6;
  const pisca = (a: number, b: number, passo = 3) => entre(T, a, b) && Math.floor(frame / passo) % 2 === 0;
  const poste = pisca(7.2, 8.2) || pisca(30.3, 31) || pisca(86.2, 91, 4) ? 0.2 : 1;
  const luz = pisca(7.4, 7.7, 4) || pisca(30.7, 31, 2) || pisca(82.5, 82.8, 2) || pisca(88, 91, 5) ? 0.3 : 1;

  // ---------- quem esta do lado de fora ----------
  const fora: React.ReactNode[] = [];
  if (entre(T, 23, 27)) {
    const sai = ease((T - 26.5) / 0.5) * 2.4;
    fora.push(
      bill(cam, "entregador", [0.5 + sai, 0, 3.45], (
        <Boneco camisa="#d8362b" calca="#2a2f3d" pele="#8a5a36" cabelo="#1a1a1a" expr="neutro" t={Tr} bone="#d8362b" mochila mao={T < 24 ? 1 : 0} bate={T < 23.6} />
      )),
    );
  }
  if (T >= 31) {
    const z = T < 47 ? 3.75 : T < 54 ? 3.45 : 3.3;
    const expr: Expr = T >= 87 ? "grito" : T >= 73 ? "serio" : "sorriso";
    fora.push(
      bill(cam, "homem", [0.5, 0, z], (
        <Boneco camisa="#5d6f86" calca="#23262f" pele="#c9a184" cabelo="#2a2320" expr={expr} t={Tr} molhado mao={T >= 57 ? 1 : 0} bate={T >= 87 && T < 91} />
      )),
    );
  }

  // ---------- maos ----------
  const cftvOn = entre(T, 20, 23) || entre(T, 50, 54) || entre(T, 82, 85) || entre(T, 89, 91);
  const fim = T >= 91;
  const celGrupo = Math.max(janela(T, 10.8, 13.0), janela(T, 27, 30.9), janela(T, 63, 67.1));
  const celMae = Math.max(janela(T, 13.0, 15.3), janela(T, 76, 79.9));
  const celOn = celGrupo > 0 || celMae > 0;
  const sobe = clamp((cam.pitch + 0.42) / 0.36);
  const bob = 9 * Math.sin(Tr * 1.4);
  const pegaT = T < 11 ? T : T - 42.6;
  const pega = emLigacao ? interpolate(pegaT, [0, 0.4], [280, 0], { easing: Easing.out(Easing.cubic), extrapolateLeft: "clamp", extrapolateRight: "clamp" }) : 0;
  const esq: Pose | null = celOn ? null : { x: 250 - 20 * sobe, y: 1850 + bob * 0.3 + 40 * sobe, rot: 9, s: 1.5, sy: 0.5 };
  const dir: Pose = emLigacao
    ? { x: 900 + 10 * sobe, y: 1590 + pega + bob + 110 * sobe, rot: -24 + 2.5 * Math.sin(Tr * 1.1), s: 1.24 }
    : { x: 840 + 20 * sobe, y: 1850 - bob * 0.3 + 40 * sobe, rot: -9, s: 1.5, sy: 0.5 };
  const base = proj([0.86, 0.87, 0.5], cam);

  // ---------- cameras de seguranca ----------
  let camId: CamId = "corredor";
  let andar = "8";
  if (entre(T, 50, 54)) camId = "entrada";
  if (entre(T, 83.7, 85)) {
    camId = "elevador";
    andar = T < 84.15 ? "8" : T < 84.6 ? "7" : "6";
  }
  if (entre(T, 89, 91)) {
    camId = "elevador";
    andar = T < 89.6 ? "3" : T < 90.3 ? "2" : "1";
  }
  const cftvEntra = Math.max(janela(T, 20, 23, 0.14, 0.08), janela(T, 50, 54, 0.14, 0.08), janela(T, 82, 85, 0.14, 0.08), janela(T, 89, 91, 0.14, 0.01));
  const corredorLuz = entre(T, 20, 23) ? (Math.floor(frame / 4) % 3 === 0 ? 0.25 : 1) : entre(T, 82, 83.7) ? (pisca(82.4, 82.9, 2) ? 0.2 : 0.8) : 1;
  const aberta = T >= 82.6 ? 1 : 0;
  const olhos = janela(T, 83.1, 83.7, 0.08, 0.01);
  const zoomCam = entre(T, 82, 83.7) ? 1 + 1.7 * ease((T - 82.7) / 0.45) : 1 + 0.05 * clamp((T - 20) / 3);

  // batida no vidro: tela treme
  const tremor = entre(T, 87, 89) ? 7 * Math.sin(Tr * 38) : entre(T, 23, 23.6) ? 3 * Math.sin(Tr * 38) : 0;

  return (
    <AbsoluteFill style={{ backgroundColor: "#060a18" }}>
      <AbsoluteFill style={{ transform: `translate(${tremor}px, ${tremor * 0.4}px)` }}>
        <Portaria cam={cam} st={{ ledOn, poste, luz, chamando, t: Tr }} fora={fora} />
        {cftvOn || fim ? null : <Maos esq={esq} dir={dir} objetoDir={emLigacao ? "fone" : null} fioPara={emLigacao ? [base.x, base.y] : undefined} sombra />}
      </AbsoluteFill>
      <AbsoluteFill style={{ background: "linear-gradient(to bottom, rgba(3,5,16,0.62) 0%, rgba(3,5,16,0.18) 30%, rgba(3,5,16,0) 46%)" }} />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse 75% 62% at 50% 45%, rgba(0,0,0,0) 42%, rgba(3,5,14,0.82) 100%)" }} />
      <Celular entra={celGrupo} titulo="Cond. Jardim das Acácias" sub="Dona Neide, Síndico, você e mais 61" avatar="🏢" msgs={visiveis(GRUPO, T, 2)} />
      <Celular entra={celMae} titulo="Mãe ❤️" sub="online" avatar="👩" msgs={visiveis(MAE, T, 2)} />
      <Cftv entra={cftvEntra} cam={camId} frame={quadroReal} luz={corredorLuz} aberta={aberta} olhos={olhos} andar={andar} zoom={zoomCam} />
      {fim || cftvOn ? null : <EtiquetaParte n={1} />}
      {fim || cftvOn ? null : (
        <EtiquetaDireita>{`00:${String(14 + Math.floor(Tr / 30)).padStart(2, "0")}`}</EtiquetaDireita>
      )}
      <Legenda falas={FALAS} quadro={frame} />
      <Escolha q={Math.round(frame - S(91))} dur={S(5)} a="ABRIR" b="ESPERAR" sa="pro homem da porta" sb="o elevador chegar" ia="🚪" ib="⏳" />
    </AbsoluteFill>
  );
};

export const _CORES = CORES;
