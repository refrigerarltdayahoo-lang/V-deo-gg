import React from "react";
import { Composition } from "remotion";
import { DUR_EP01, Ep01, FPS } from "./Ep01";
import { DUR_JONAS01, Jonas01 } from "./Jonas01";
import { DUR_VENDA, VendaParceiro } from "./VendaParceiro";

// Registro dos episodios. Para um episodio novo sao duas linhas: o import do componente e da duracao (aqui em cima)
// e uma linha <Composition> (aqui embaixo), iguais as dos exemplos.
// MinhaVenda e o video de venda do modo parceiro: os dados vem de src/minha_venda_dados.tsx (parceiro/parceiro.py video).
export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Ep01" component={Ep01} durationInFrames={DUR_EP01} fps={FPS} width={1080} height={1920} />
    <Composition id="Jonas01" component={Jonas01} durationInFrames={DUR_JONAS01} fps={30} width={1080} height={1920} />
    <Composition id="MinhaVenda" component={VendaParceiro} durationInFrames={DUR_VENDA} fps={30} width={1080} height={1920} defaultProps={{ modoTexto: false }} />
  </>
);
