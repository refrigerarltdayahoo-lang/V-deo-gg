// Gerado por ep_audio.py: segundos extras que cada fala precisa alem do tempo previsto no roteiro.
export const EXTRAS: number[] = [0.2333, 0.7333, 0.7333, 0.2, 0.0, 0.0, 0.6333, 0.0, 0.0667, 2.4667, 1.1, 0.0, 0.0, 0.2667, 0.3333, 0.0, 0.0, 1.8, 0.6333, 0.1667, 0.0, 0.9, 2.7667];
