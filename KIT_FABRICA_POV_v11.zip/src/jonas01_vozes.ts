// Gerado por ep_audio.py: segundos extras que cada fala precisa alem do tempo previsto no roteiro.
export const EXTRAS: number[] = [0.6333, 0.7667, 0.0, 0.2, 0.0667, 0.3, 0.0, 0.0, 0.0, 0.0, 0.0, 0.7333, 0.2, 0.0, 0.0, 0.0, 0.0, 0.7, 1.1667];
