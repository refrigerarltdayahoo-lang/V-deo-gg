import React from "react";
import { W, H } from "./engine";

// Maos de quem assiste, em primeiro plano (espaco de tela). Desenho apontando para cima, pulso em (0,0).
const INK = "#15130f";
const SW = 9;

export type Tema = { manga: string; mangaS: string; pele: string; peleS: string; unha: string };
export const TEMA_PORTEIRO: Tema = { manga: "#274f8f", mangaS: "#1d3c6e", pele: "#b97d4c", peleS: "#96623a", unha: "#dcae86" };
export const TEMA_MARINHEIRO: Tema = { manga: "#8a6b45", mangaS: "#6b5133", pele: "#b97d4c", peleS: "#96623a", unha: "#dcae86" };

const Manga: React.FC<{ t: Tema }> = ({ t }) => (
  <g>
    <path d="M-150 1100 L-135 70 L135 70 L150 1100 Z" fill={t.manga} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
    <path d="M-60 1000 L-52 140" stroke={t.mangaS} strokeWidth={7} strokeLinecap="round" />
    <rect x={-148} y={30} width={296} height={70} rx={22} fill={t.mangaS} stroke={INK} strokeWidth={SW} />
  </g>
);

// Mao aberta vista de cima (dorso). O desenho base e a mao direita: polegar do lado de dentro (x negativo).
// sombra: sombra redonda embaixo da mao, para quando ela esta apoiada (bancada, mesa). Desligada por padrao.
export const MaoDeitada: React.FC<{ espelho?: boolean; t?: Tema; sombra?: boolean }> = ({ espelho, t = TEMA_PORTEIRO, sombra = false }) => (
  <g transform={espelho ? "scale(-1 1)" : undefined}>
    {sombra ? <ellipse cx={10} cy={-120} rx={210} ry={250} fill="#000" opacity={0.28} /> : null}
    <Manga t={t} />
    {[
      [-78, 150],
      [-26, 185],
      [26, 172],
      [78, 132],
    ].map(([x, h], i) => (
      <g key={i}>
        <rect x={x - 24} y={-150 - h} width={48} height={h + 40} rx={24} fill={t.pele} stroke={INK} strokeWidth={SW} />
        <rect x={x - 13} y={-150 - h + 10} width={26} height={30} rx={11} fill={t.unha} />
      </g>
    ))}
    <g transform="translate(-110 2) rotate(-34)">
      <rect x={-28} y={-78} width={56} height={92} rx={28} fill={t.pele} stroke={INK} strokeWidth={SW} />
      <rect x={-13} y={-69} width={26} height={26} rx={11} fill={t.unha} />
    </g>
    <rect x={-108} y={-175} width={216} height={230} rx={62} fill={t.pele} stroke={INK} strokeWidth={SW} />
    <path d="M-78 -150 q0 -20 0 -22 M-26 -152 v-22 M26 -152 v-22 M78 -150 v-20" stroke={t.peleS} strokeWidth={6} strokeLinecap="round" />
    <path d="M-60 -60 q60 -22 120 0" fill="none" stroke={t.peleS} strokeWidth={5} strokeLinecap="round" />
  </g>
);

// Angulo do objeto em relacao ao antebraco e ponto (local) da ponta de baixo do fone, de onde sai o fio.
export const FONE_ROT = 52;
export const FONE_PONTA: [number, number] = [-251, 120];

export type Objeto = "fone" | "gravetos" | "punho";

// Mao fechada segurando alguma coisa atravessada na palma.
// desenho: desenho proprio do objeto (SVG), no lugar dos objetos prontos. Coordenadas locais da mao:
//   pulso em (0,0), centro da palma em (0,-60), y para baixo, cerca de 210 de largura. O desenho fica
//   entre a palma e os dedos, que fecham por cima dele. Use objeto="punho" junto com o desenho.
// rot: angulo dos dedos e do objeto em graus (padrao: 52 para o fone, 8 para os gravetos, 80 para o punho).
export const MaoFechada: React.FC<{ objeto: Objeto; espelho?: boolean; t?: Tema; desenho?: React.ReactNode; rot?: number }> = ({ objeto, espelho, t = TEMA_PORTEIRO, desenho, rot }) => (
  <g transform={espelho ? "scale(-1 1)" : undefined}>
    <Manga t={t} />
    <rect x={-104} y={-170} width={208} height={225} rx={58} fill={t.pele} stroke={INK} strokeWidth={SW} />
    <g transform={`rotate(${rot ?? (objeto === "fone" ? FONE_ROT : objeto === "gravetos" ? 8 : 80)} 0 -60)`}>
      {desenho ? <g transform={espelho ? "scale(-1 1)" : undefined}>{desenho}</g> : null}
      {objeto === "fone" ? (
        <g transform="translate(-55 -60) rotate(-6)">
          <rect x={-48} y={-330} width={96} height={640} rx={44} fill="#2b2b31" stroke={INK} strokeWidth={SW} />
          <rect x={-62} y={-350} width={124} height={150} rx={50} fill="#383840" stroke={INK} strokeWidth={SW} />
          <rect x={-62} y={185} width={124} height={140} rx={50} fill="#383840" stroke={INK} strokeWidth={SW} />
          <g fill="#111">
            <circle cx={-18} cy={-290} r={6} />
            <circle cx={18} cy={-290} r={6} />
            <circle cx={0} cy={-262} r={6} />
            <circle cx={-18} cy={-234} r={6} />
            <circle cx={18} cy={-234} r={6} />
          </g>
        </g>
      ) : null}
      {objeto === "gravetos"
        ? [
            [-96, 250],
            [-58, 290],
            [-20, 120],
            [18, 270],
          ].map(([x, h], i) => (
            <rect key={i} x={x} y={-150 - h} width={24} height={h + 60} rx={8} fill={i === 2 ? "#e9d9a8" : "#c9a66b"} stroke={INK} strokeWidth={7} />
          ))
        : null}
      {[-150, -98, -46, 6].map((y, i) => (
        <rect key={i} x={-128 + i * 4} y={y} width={176 - i * 6} height={50} rx={25} fill={t.pele} stroke={INK} strokeWidth={SW} />
      ))}
      <g transform="translate(92 -70) rotate(-12)">
        <rect x={-27} y={-120} width={54} height={160} rx={27} fill={t.pele} stroke={INK} strokeWidth={SW} />
      </g>
    </g>
  </g>
);

export type Pose = { x: number; y: number; rot: number; s: number; sy?: number };

// Converte um ponto local da mao para a tela.
export const pontoDaMao = (p: [number, number], h: Pose): [number, number] => {
  const a = (h.rot * Math.PI) / 180;
  const x = p[0] * h.s;
  const y = p[1] * h.s * (h.sy ?? 1);
  return [h.x + x * Math.cos(a) - y * Math.sin(a), h.y + x * Math.sin(a) + y * Math.cos(a)];
};

// Fio espiral entre dois pontos da tela.
export const Fio: React.FC<{ de: [number, number]; para: [number, number] }> = ({ de, para }) => {
  const dx = para[0] - de[0];
  const dy = para[1] - de[1];
  const len = Math.hypot(dx, dy);
  const nx = -dy / len;
  const ny = dx / len;
  const voltas = Math.max(8, Math.round(len / 46));
  let d = `M${de[0].toFixed(1)} ${de[1].toFixed(1)}`;
  const N = voltas * 8;
  for (let i = 1; i <= N; i++) {
    const t = i / N;
    const amp = 15 * Math.sin(t * voltas * Math.PI * 2);
    const cx = de[0] - 330; // barriga do fio para a esquerda, por cima da bancada
    const cy = de[1] - 300;
    const bx = (1 - t) * (1 - t) * de[0] + 2 * (1 - t) * t * cx + t * t * para[0];
    const by = (1 - t) * (1 - t) * de[1] + 2 * (1 - t) * t * cy + t * t * para[1];
    d += `L${(bx + nx * amp).toFixed(1)} ${(by + ny * amp).toFixed(1)}`;
  }
  return <path d={d} fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />;
};

// As duas maos de quem assiste. Sem objeto por padrao: as duas aparecem abertas.
export const Maos: React.FC<{
  esq: Pose | null; // posicao da mao esquerda na tela (null esconde a mao)
  dir: Pose | null; // posicao da mao direita na tela (null esconde a mao)
  tema?: Tema; // cores da manga e da pele
  objetoDir?: Objeto | null; // objeto pronto na mao direita: "fone", "gravetos" ou "punho" (mao fechada vazia). Padrao: null (mao aberta)
  desenhoDir?: React.ReactNode; // desenho proprio (SVG) do objeto da mao direita. A mao fecha em volta dele
  rotDir?: number; // angulo, em graus, dos dedos e do objeto da mao direita
  esqPunho?: boolean; // mao esquerda fechada (segurando corda)
  desenhoEsq?: React.ReactNode; // desenho proprio (SVG) do objeto da mao esquerda. A mao fecha em volta dele
  rotEsq?: number; // angulo, em graus, dos dedos e do objeto da mao esquerda
  fioPara?: [number, number]; // ponto da tela onde termina o fio do fone (so com objetoDir="fone")
  corda?: boolean; // corda grossa atravessando a tela, por tras dos punhos
  sombra?: boolean; // sombra redonda embaixo da mao aberta, para mao apoiada em bancada ou mesa. Padrao: false
}> = ({ esq, dir, tema = TEMA_PORTEIRO, objetoDir = null, desenhoDir, rotDir, esqPunho, desenhoEsq, rotEsq, fioPara, corda, sombra = false }) => {
  const objD: Objeto | null = objetoDir ?? (desenhoDir ? "punho" : null);
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
      {fioPara && dir && objD === "fone" ? <Fio de={pontoDaMao(FONE_PONTA, dir)} para={fioPara} /> : null}
      {corda && esq && dir ? (
        <g>
          <path d={`M-60 ${esq.y - 420} L${esq.x} ${esq.y - 110} L${dir.x} ${dir.y - 110} L1140 ${dir.y - 520}`} fill="none" stroke={INK} strokeWidth={46} strokeLinecap="round" strokeLinejoin="round" />
          <path d={`M-60 ${esq.y - 420} L${esq.x} ${esq.y - 110} L${dir.x} ${dir.y - 110} L1140 ${dir.y - 520}`} fill="none" stroke="#cdb27a" strokeWidth={30} strokeLinecap="round" strokeLinejoin="round" />
        </g>
      ) : null}
      {esq ? (
        <g transform={`translate(${esq.x} ${esq.y}) rotate(${esq.rot}) scale(${esq.s} ${esq.s * (esq.sy ?? 1)})`}>
          {esqPunho || desenhoEsq ? <MaoFechada objeto="punho" espelho t={tema} desenho={desenhoEsq} rot={rotEsq} /> : <MaoDeitada espelho t={tema} sombra={sombra} />}
        </g>
      ) : null}
      {dir ? (
        <g transform={`translate(${dir.x} ${dir.y}) rotate(${dir.rot}) scale(${dir.s} ${dir.s * (dir.sy ?? 1)})`}>
          {objD ? <MaoFechada objeto={objD} t={tema} desenho={desenhoDir} rot={rotDir} /> : <MaoDeitada t={tema} sombra={sombra} />}
        </g>
      ) : null}
    </svg>
  );
};
