import React from "react";
import { fontFamily } from "./fontes";

// Monitor das cameras em tela cheia (o espectador se inclina para olhar). Uma camera por vez.
const INK = "#0d0c0a";
const SX = 50;
const SY = 250;
const SW = 980;
const SH = 1310;

const Corredor: React.FC<{ luz: number; aberta: number; olhos: number }> = ({ luz, aberta, olhos }) => (
  <g>
    <polygon points="0,0 980,0 600,430 380,430" fill="#39443f" />
    <polygon points="0,1310 980,1310 600,720 380,720" fill="#4a5750" />
    <polygon points="0,0 380,430 380,720 0,1310" fill="#5b6a62" />
    <polygon points="980,0 600,430 600,720 980,1310" fill="#54625a" />
    <rect x={380} y={430} width={220} height={290} fill="#65756c" />
    {/* portas laterais */}
    <polygon points="70,290 215,390 215,930 70,1190" fill="#3b4741" stroke={INK} strokeWidth={5} />
    <polygon points="268,424 338,440 338,790 268,860" fill="#3b4741" stroke={INK} strokeWidth={4} />
    <polygon points="910,290 765,390 765,930 910,1190" fill="#37423c" stroke={INK} strokeWidth={5} />
    <polygon points="712,424 642,440 642,790 712,860" fill="#37423c" stroke={INK} strokeWidth={4} />
    {/* porta do 804 no fundo */}
    <rect x={438} y={498} width={104} height={222} fill={aberta > 0.5 ? "#050706" : "#2d3832"} stroke={INK} strokeWidth={5} />
    {aberta > 0.5 ? <polygon points="438,498 472,514 472,736 438,720" fill="#2d3832" stroke={INK} strokeWidth={4} /> : <circle cx={528} cy={612} r={5} fill="#c9ccd2" />}
    {olhos > 0.01 ? (
      <g opacity={olhos}>
        <circle cx={497} cy={575} r={6.5} fill="#ffffff" />
        <circle cx={519} cy={575} r={6.5} fill="#ffffff" />
      </g>
    ) : null}
    <rect x={452} y={448} width={76} height={38} rx={6} fill="#0d0c0a" />
    <text x={490} y={477} fontSize={30} fontWeight={800} textAnchor="middle" fill="#e9f5e9" fontFamily={fontFamily}>
      804
    </text>
    {/* linhas de quina */}
    <path d="M0 0 L380 430 M980 0 L600 430 M0 1310 L380 720 M980 1310 L600 720 M380 430 H600 V720 H380 Z" fill="none" stroke={INK} strokeWidth={5} />
    {/* luminarias */}
    <ellipse cx={490} cy={205} rx={130} ry={28} fill={luz > 0.5 ? "#f3fff0" : "#59665f"} stroke={INK} strokeWidth={4} />
    <ellipse cx={490} cy={352} rx={62} ry={12} fill={luz > 0.5 ? "#f3fff0" : "#59665f"} stroke={INK} strokeWidth={3} />
    <polygon points="380,720 600,720 720,1310 260,1310" fill="#e9ffe6" opacity={0.1 * luz} />
    <rect x={0} y={0} width={SW} height={SH} fill="#020403" opacity={0.62 * (1 - luz)} />
  </g>
);

const Entrada: React.FC = () => (
  <g>
    <rect x={0} y={0} width={SW} height={760} fill="#4d5a53" />
    <polygon points="0,760 980,760 1100,1310 -120,1310" fill="#6b776f" />
    {[1, 2, 3, 4, 5, 6].map((i) => (
      <line key={i} x1={i * 140} y1={760} x2={i * 172 - 110} y2={1310} stroke="#55615a" strokeWidth={4} />
    ))}
    <line x1={-40} y1={930} x2={1020} y2={930} stroke="#55615a" strokeWidth={4} />
    <line x1={-80} y1={1120} x2={1060} y2={1120} stroke="#55615a" strokeWidth={4} />
    {/* porta de vidro com a luz da portaria la dentro */}
    <rect x={250} y={270} width={480} height={490} fill="#c5d6c0" stroke={INK} strokeWidth={10} />
    <line x1={490} y1={270} x2={490} y2={760} stroke={INK} strokeWidth={8} />
    <rect x={300} y={560} width={380} height={70} rx={8} fill="#5b4a36" stroke={INK} strokeWidth={5} />
    <rect x={300} y={196} width={380} height={50} rx={8} fill="#0d0c0a" />
    <text x={490} y={232} fontSize={30} fontWeight={800} textAnchor="middle" fill="#e9f5e9" fontFamily={fontFamily}>
      ED. JARDIM DAS ACÁCIAS
    </text>
    {/* poste e poça de luz: calcada vazia */}
    <ellipse cx={470} cy={1000} rx={380} ry={150} fill="#eaffea" opacity={0.3} />
    <rect x={850} y={560} width={22} height={560} fill="#1d2420" />
    <rect x={0} y={0} width={SW} height={SH} fill="#020403" opacity={0.12} />
    <rect x={24} y={168} width={500} height={62} rx={10} fill="#000" opacity={0.7} />
    <text x={44} y={212} fontSize={38} fontWeight={800} fill="#ff5a4a" fontFamily={fontFamily}>
      0 PESSOAS NA PORTA
    </text>
  </g>
);

const Elevador: React.FC<{ andar: string }> = ({ andar }) => (
  <g>
    <rect x={0} y={0} width={SW} height={SH} fill="#55625b" />
    <polygon points="0,1150 980,1150 980,1310 0,1310" fill="#414d47" />
    <rect x={230} y={400} width={520} height={750} fill="#2f3a35" stroke={INK} strokeWidth={10} />
    <rect x={250} y={420} width={236} height={730} fill="#8b9a92" stroke={INK} strokeWidth={6} />
    <rect x={494} y={420} width={236} height={730} fill="#84938b" stroke={INK} strokeWidth={6} />
    <rect x={360} y={170} width={260} height={170} rx={16} fill="#0a0a0a" stroke={INK} strokeWidth={8} />
    <text x={470} y={302} fontSize={150} fontWeight={800} textAnchor="middle" fill="#ff5a3c" fontFamily={fontFamily}>
      {andar}
    </text>
    <polygon points="548,232 598,232 573,286" fill="#ff5a3c" />
    <rect x={790} y={700} width={70} height={130} rx={10} fill="#22292a" stroke={INK} strokeWidth={5} />
    <circle cx={825} cy={765} r={16} fill="#ff5a3c" />
  </g>
);

export type CamId = "corredor" | "entrada" | "elevador";

export const Cftv: React.FC<{
  entra: number;
  cam: CamId;
  frame: number;
  luz?: number;
  aberta?: number;
  olhos?: number;
  andar?: string;
  zoom?: number;
}> = ({ entra, cam, frame, luz = 1, aberta = 0, olhos = 0, andar = "8", zoom = 1 }) => {
  if (entra <= 0.001) return null;
  const rotulo = cam === "corredor" ? "CAM 3 · CORREDOR 8º ANDAR" : cam === "entrada" ? "CAM 1 · ENTRADA" : "CAM 4 · ELEVADOR";
  const seg = 7 + Math.floor(frame / 30);
  const hora = `00:${String(14 + Math.floor(seg / 60)).padStart(2, "0")}:${String(seg % 60).padStart(2, "0")}`;
  const barra = (frame * 23) % (SH + 200) - 100;
  return (
    <div style={{ position: "absolute", inset: 0, opacity: Math.min(1, entra * 1.6), transform: `scale(${0.92 + 0.08 * entra})` }}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: "absolute", inset: 0 }}>
        <defs>
          <clipPath id="tela">
            <rect x={0} y={0} width={SW} height={SH} rx={26} />
          </clipPath>
          <pattern id="scan" width={8} height={8} patternUnits="userSpaceOnUse">
            <rect x={0} y={0} width={8} height={3} fill="#000" opacity={0.22} />
          </pattern>
        </defs>
        <rect x={0} y={0} width={1080} height={1920} fill="#07080c" />
        <rect x={18} y={196} width={1044} height={1500} rx={44} fill="#1b1b20" stroke={INK} strokeWidth={10} />
        <g transform={`translate(${SX} ${SY})`} clipPath="url(#tela)">
          {cam === "corredor" ? (
            <g transform={`translate(490 600) scale(${zoom}) translate(-490 -600)`}>
              <Corredor luz={luz} aberta={aberta} olhos={olhos} />
            </g>
          ) : null}
          {cam === "entrada" ? <Entrada /> : null}
          {cam === "elevador" ? <Elevador andar={andar} /> : null}
          <rect x={0} y={0} width={SW} height={SH} fill="#0f3a1f" opacity={0.2} />
          <rect x={0} y={0} width={SW} height={SH} fill="url(#scan)" />
          <rect x={0} y={barra} width={SW} height={46} fill="#fff" opacity={0.06} />
          <rect x={24} y={24} width={620} height={62} rx={10} fill="#000" opacity={0.62} />
          <text x={44} y={68} fontSize={38} fontWeight={800} fill="#eafff0" fontFamily={fontFamily}>
            {rotulo}
          </text>
          <rect x={700} y={98} width={256} height={58} rx={10} fill="#000" opacity={0.62} />
          <text x={828} y={140} fontSize={36} fontWeight={800} textAnchor="middle" fill="#eafff0" fontFamily={fontFamily}>
            {hora}
          </text>
          {Math.floor(frame / 15) % 2 === 0 ? <circle cx={910} cy={56} r={15} fill="#ff2a2a" /> : null}
          <text x={870} y={70} fontSize={34} fontWeight={800} textAnchor="end" fill="#eafff0" fontFamily={fontFamily}>
            REC
          </text>
        </g>
        <rect x={SX} y={SY} width={SW} height={SH} rx={26} fill="none" stroke={INK} strokeWidth={10} />
        <circle cx={540} cy={1636} r={9} fill="#3dff7a" />
        <rect x={380} y={1696} width={320} height={224} fill="#141418" stroke={INK} strokeWidth={10} />
      </svg>
    </div>
  );
};
