import React from "react";

// Bonecos 2D em centimetros, origem nos pes, y para cima negativo. Cabeca grande para a expressao ler de longe.
const INK = "#15130f";
const SW = 2.6;

export type Expr = "sorriso" | "serio" | "grito" | "neutro" | "susto" | "dormindo";

export const Boneco: React.FC<{
  camisa: string;
  calca: string;
  pele: string;
  cabelo: string;
  expr: Expr;
  t: number;
  molhado?: boolean;
  mao?: number; // 0 a 1: braco erguido, palma no vidro
  bate?: boolean;
  bone?: string; // cor do bone
  mochila?: boolean;
  capuz?: boolean;
  tunica?: boolean; // roupa longa de epoca, cobre as pernas
  barba?: string; // cor da barba
  faixa?: string; // cor da faixa na testa
  sentado?: boolean; // sentado de frente: o corpo desce 22 cm, joelhos a frente do tronco. O assento fica a 42 cm do chao
}> = ({ camisa, calca, pele, cabelo, expr, t, molhado, mao = 0, bate, bone, mochila, capuz, tunica, barba, faixa, sentado }) => {
  const bx = bate ? 3 * Math.sin(t * 38) : 0;
  const by = bate ? 2 * Math.cos(t * 38) : 0;
  const hx = 44 + bx;
  const hy = -150 + by + (1 - mao) * 70;
  // Sentado, tudo acima das pernas desce junto. Os pes continuam no chao (origem do desenho).
  const corpo = sentado ? "translate(0 22)" : undefined;
  return (
    <g strokeLinejoin="round" strokeLinecap="round">
      {molhado ? <ellipse cx={0} cy={2} rx={58} ry={9} fill="#3d6ea8" opacity={0.75} /> : null}
      <g transform={corpo}>
      {mochila ? (
        <g>
          <rect x={-112} y={-192} width={84} height={96} rx={8} fill="#e3261c" stroke={INK} strokeWidth={SW} />
          <text x={-72} y={-152} fontSize={11.5} fontWeight={800} textAnchor="middle" fill="#fff" fontFamily="Inter POV, Arial, sans-serif">
            ACEITO
          </text>
          <text x={-72} y={-136} fontSize={8.6} fontWeight={800} textAnchor="middle" fill="#ffe14a" fontFamily="Inter POV, Arial, sans-serif">
            VALE-COXINHA
          </text>
          <rect x={-102} y={-120} width={60} height={5} rx={2} fill="#9c120c" />
        </g>
      ) : null}
      </g>
      {/* pernas e pes (sentado: so as canelas, do joelho ao chao) */}
      <rect x={-19} y={sentado ? -40 : -64} width={16} height={sentado ? 38 : 62} rx={6} fill={calca} stroke={INK} strokeWidth={SW} />
      <rect x={3} y={sentado ? -40 : -64} width={16} height={sentado ? 38 : 62} rx={6} fill={calca} stroke={INK} strokeWidth={SW} />
      <ellipse cx={-13} cy={-1} rx={12} ry={5} fill="#1c1c20" stroke={INK} strokeWidth={SW} />
      <ellipse cx={13} cy={-1} rx={12} ry={5} fill="#1c1c20" stroke={INK} strokeWidth={SW} />
      <g transform={corpo}>
      {/* braco esquerdo caido */}
      <rect x={-38} y={-122} width={14} height={56} rx={7} fill={camisa} stroke={INK} strokeWidth={SW} />
      <circle cx={-31} cy={-63} r={7} fill={pele} stroke={INK} strokeWidth={SW} />
      {/* tronco */}
      <rect x={-25} y={-126} width={50} height={68} rx={13} fill={camisa} stroke={INK} strokeWidth={SW} />
      {tunica ? (
        <g>
          <path d={sentado ? "M-26 -74 L-30 -30 Q0 -24 30 -30 L26 -74 Z" : "M-26 -74 L-30 -8 Q0 -2 30 -8 L26 -74 Z"} fill={camisa} stroke={INK} strokeWidth={SW} />
          <rect x={-26} y={-82} width={52} height={8} rx={3} fill="#3a2a1a" />
        </g>
      ) : null}
      {mochila ? <path d="M-14 -124 L-8 -66 M14 -124 L8 -66" stroke="#9c120c" strokeWidth={4} /> : null}
      {/* sentado: coxas vistas de frente (encurtadas), por cima da barra do tronco */}
      {sentado && !tunica ? (
        <g>
          <rect x={-23} y={-78} width={21} height={24} rx={9} fill={calca} stroke={INK} strokeWidth={SW} />
          <rect x={2} y={-78} width={21} height={24} rx={9} fill={calca} stroke={INK} strokeWidth={SW} />
        </g>
      ) : null}
      {/* braco direito: caido ou erguido ate o vidro */}
      <path d={`M24 -116 L${hx} ${hy + 8}`} stroke={INK} strokeWidth={17} fill="none" />
      <path d={`M24 -116 L${hx} ${hy + 8}`} stroke={camisa} strokeWidth={12} fill="none" />
      <g transform={`translate(${hx} ${hy})`}>
        {mao > 0.5 ? (
          <g transform="scale(1.45)">
            <circle r={19} fill="#cfe6ff" opacity={0.2} />
            {[-9, -3, 3, 9].map((x, i) => (
              <rect key={i} x={x - 2.6} y={-22 + Math.abs(x) * 0.25} width={5.2} height={16} rx={2.6} fill={pele} stroke={INK} strokeWidth={1.8} />
            ))}
            <rect x={-12} y={-10} width={24} height={20} rx={8} fill={pele} stroke={INK} strokeWidth={SW} />
            <rect x={-17} y={-6} width={7} height={13} rx={3.5} fill={pele} stroke={INK} strokeWidth={1.8} />
          </g>
        ) : (
          <circle r={7} fill={pele} stroke={INK} strokeWidth={SW} />
        )}
      </g>
      {/* cabeca */}
      {capuz ? <path d="M-37 -132 Q-41 -203 0 -203 Q41 -203 37 -132 Z" fill={camisa} stroke={INK} strokeWidth={SW} /> : null}
      <rect x={-7} y={-134} width={14} height={12} fill={pele} stroke={INK} strokeWidth={SW} />
      <circle cx={-31} cy={-160} r={6} fill={pele} stroke={INK} strokeWidth={SW} />
      <circle cx={31} cy={-160} r={6} fill={pele} stroke={INK} strokeWidth={SW} />
      <rect x={-31} y={-194} width={62} height={66} rx={27} fill={pele} stroke={INK} strokeWidth={SW} />
      {bone ? (
        <g>
          <path d="M-31 -172 Q-31 -200 0 -200 Q31 -200 31 -172 Z" fill={bone} stroke={INK} strokeWidth={SW} />
          <path d="M-6 -173 Q20 -168 42 -170 Q40 -178 20 -180 Z" fill={bone} stroke={INK} strokeWidth={SW} />
        </g>
      ) : (
        <path
          d={molhado ? "M-31 -166 Q-33 -198 0 -198 Q33 -198 31 -166 L26 -176 L20 -160 L13 -177 L5 -163 L-3 -178 L-12 -162 L-20 -177 Z" : "M-31 -168 Q-33 -199 0 -199 Q33 -199 31 -168 Q8 -184 -31 -168 Z"}
          fill={cabelo}
          stroke={INK}
          strokeWidth={SW}
        />
      )}
      {faixa ? <rect x={-31} y={-184} width={62} height={9} rx={3} fill={faixa} stroke={INK} strokeWidth={1.6} /> : null}
      {/* olhos */}
      <circle cx={-12} cy={-158} r={8.6} fill="#fff" stroke={INK} strokeWidth={2} />
      <circle cx={12} cy={-158} r={8.6} fill="#fff" stroke={INK} strokeWidth={2} />
      <circle cx={-12} cy={expr === "serio" ? -156 : -158} r={expr === "grito" || expr === "susto" ? 2.6 : 3.6} fill={INK} />
      <circle cx={12} cy={expr === "serio" ? -156 : -158} r={expr === "grito" || expr === "susto" ? 2.6 : 3.6} fill={INK} />
      {expr === "serio" ? (
        <g>
          <path d="M-22 -168 h20 v6 h-20 z M2 -168 h20 v6 h-20 z" fill={pele} stroke="none" />
          <path d="M-22 -168 L-3 -162 M22 -168 L3 -162" stroke={INK} strokeWidth={3} />
        </g>
      ) : null}
      {expr === "grito" ? <path d="M-22 -172 L-4 -171 M22 -172 L4 -171" stroke={INK} strokeWidth={2.6} /> : null}
      {expr === "susto" ? (
        <g>
          <path d="M-22 -170 Q-13 -176 -4 -172 M22 -170 Q13 -176 4 -172" stroke={INK} strokeWidth={2.6} fill="none" />
          <path d="M-12 -139 q4 -5 8 0 q4 5 8 0 q4 -5 8 0" stroke={INK} strokeWidth={2.8} fill="none" />
          <path d="M27 -186 q6 9 0 13 q-6 -4 0 -13 z" fill="#8fc4ff" stroke={INK} strokeWidth={1.4} />
        </g>
      ) : null}
      {barba ? <path d="M-29 -158 Q-32 -116 0 -112 Q32 -116 29 -158 Q22 -140 0 -142 Q-22 -140 -29 -158 Z" fill={barba} stroke={INK} strokeWidth={2.2} /> : null}
      {/* boca */}
      {expr === "sorriso" ? (
        <g>
          <path d="M-18 -144 Q0 -124 18 -144 Q0 -137 -18 -144 Z" fill="#fff" stroke={INK} strokeWidth={2} />
          <path d="M-9 -139 v5 M-3 -137.6 v6 M3 -137.6 v6 M9 -139 v5" stroke={INK} strokeWidth={1.2} />
        </g>
      ) : null}
      {expr === "serio" ? <path d="M-11 -139 Q0 -142 11 -139" stroke={INK} strokeWidth={2.8} fill="none" /> : null}
      {expr === "neutro" ? <path d="M-9 -140 Q0 -136 9 -140" stroke={INK} strokeWidth={2.6} fill="none" /> : null}
      {expr === "grito" ? (
        <g>
          <ellipse cx={0} cy={-138} rx={11} ry={9} fill="#3a0d0d" stroke={INK} strokeWidth={2} />
          <rect x={-7} y={-146} width={14} height={4} rx={1.5} fill="#fff" />
        </g>
      ) : null}
      {expr === "dormindo" ? (
        <g>
          <rect x={-23} y={-169} width={46} height={22} rx={8} fill={pele} />
          <path d="M-20 -157 Q-12 -151 -4 -157 M4 -157 Q12 -151 20 -157" stroke={INK} strokeWidth={2.8} fill="none" />
          <ellipse cx={0} cy={-138} rx={4} ry={3} fill="#3a0d0d" />
        </g>
      ) : null}
      {/* agua escorrendo */}
      {molhado
        ? [0, 1, 2, 3, 4, 5].map((i) => {
            const ph = (t * 0.9 + i * 0.37) % 1;
            const x = -34 + i * 13.5;
            return <ellipse key={i} cx={x} cy={-190 + ph * 180} rx={1.6} ry={3.4} fill="#8fc4ff" opacity={1 - ph * 0.6} />;
          })
        : null}
      </g>
    </g>
  );
};
